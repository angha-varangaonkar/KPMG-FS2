# WRICEF 166 – Overall Production Report (OEE in Adhesive) — v7

Consolidated package for both syntax targets. Pick the one that matches
your system:

- `classic/` – classic ABAP syntax (`TABLES`, `PERFORM`/`FORM`, `SELECT ... INTO`)
- `s4hana2022/` – S/4HANA 2022 modern syntax (inline `DATA()`, `VALUE#`, local class)

Both implement identical business logic. See each folder's own `README.md`,
`docs/field_mapping.md`, and `docs/assumptions.md` for full detail.

## What makes this "v6"

v1 was a literal first-pass translation of the FS with several placeholders
(commented-out logic, guessed Z-table/field names, a BAPI call missing a key
parameter, per-row `SELECT SINGLE` instead of bulk retrieval, ratios not
scaled to percentages, negative running-hours on overnight shifts). v2 fixed
the code-level issues that didn't need external confirmation. v3 replaced two
guessed DDIC structures with the real ones confirmed via SE11: workcenter
exclusion uses `ZPP_WORK_CENTER` (`LOEKZ = 'X'` as the exclusion signal, since
that table has no dedicated exclude flag and there's no `ZPP_WORKCENTER_EXCLUDE`
table), and Rejected Qty sums `AFRU-ZZRQUAN1..ZZRQUAN6` (not the non-existent
`ZZQUAN1..6`). v4 resolved R3's grouping — a plain per-workcenter cumulative
sum, no calendar-month bucket. v5 removed the placeholder Plant
`AUTHORITY-CHECK` rather than shipping a guessed object.

**v6 closes out the three remaining business-logic questions:**

1. **STD QTY formula** — confirmed as the FS's literal 3-line text:
   `val1 = BMSCH/VGE04`, `val2 = Order Qty × VGE04/BMSCH`,
   `STD QTY = val1 × val2`. This is unchanged from earlier versions — it
   algebraically equals Order Qty whenever `BMSCH`/`VGE04` resolve and are
   nonzero, and that's now confirmed as the intended behavior, not a bug.
2. **Breakdown time (`AFRU-ISERH`) unit** — no longer a hardcoded `/60`.
   `ISERH` is converted to hours using its own unit field `AFRU-ZEIER`
   (data element `DZEIER`) via the standard function module
   `UNIT_CONVERSION_SIMPLE`, so it's correct regardless of what unit a
   given confirmation's `ISERH` is actually stored in.
3. **AFKO order dates** — confirmed as the FS states them literally:
   `Order Start Date = AFKO-GLTRP`, `Order End Date = AFKO-GSTRP`.

**v7 removes a redundant validation in `AT SELECTION-SCREEN`.** `S_WERKS` and
`S_DATUM` are declared `OBLIGATORY` on their `SELECT-OPTIONS`, so the
standard selection-screen framework already blocks execution and shows its
own error if either is left empty. The extra manual `IF ... IS INITIAL`
checks with custom `MESSAGE` text were dead weight duplicating that
built-in behavior, so they've been removed from both packages.

## Still open before transport

Only two items remain, and neither is resolvable from the code alone:

1. **Plant AUTHORITY-CHECK.** Not implemented — confirm the correct
   authorization object with your security team:
   - Check whether this project already has a custom `Z` authorization
     object used by other PP Z-reports (ask Basis, or browse SU21 filtered
     to a custom object class) — reuse it for consistency if so.
   - Otherwise, run an authorization trace (`STAUTHTRACE`/`ST01`) against a
     comparable standard transaction restricted by plant — e.g. `CO11N` or
     `COOIS` — to see exactly which object/field fires, or check SU24 for
     those transactions' assigned objects.
   - Once confirmed, add an `AUTHORITY-CHECK` in `AT SELECTION-SCREEN` in
     both packages.
2. **Not yet syntax-checked or unit-tested against a live system.** Run SE38
   syntax check / ATC and test against real confirmations before
   transporting beyond a dev/unit-test client. In particular, verify
   `AFRU-ZEIER` exists under that name in your system and that
   `UNIT_CONVERSION_SIMPLE`'s exception handling behaves as expected against
   real T006/ZEIER values — this package is a corrected code review, not a
   substitute for that testing.
3. Text elements (001, 002) still need to be maintained in SE38 before
   activation.

Full detail on every item above is in each variant's `docs/assumptions.md`.
