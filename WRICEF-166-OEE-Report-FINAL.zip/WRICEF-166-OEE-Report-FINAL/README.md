# WRICEF 166 – Overall Production Report (OEE in Adhesive) — v3

Consolidated package for both syntax targets. Pick the one that matches
your system:

- `classic/` – classic ABAP syntax (`TABLES`, `PERFORM`/`FORM`, `SELECT ... INTO`)
- `s4hana2022/` – S/4HANA 2022 modern syntax (inline `DATA()`, `VALUE#`, local class)

Both implement identical business logic. See each folder's own `README.md`,
`docs/field_mapping.md`, and `docs/assumptions.md` for full detail.

## v3 — what makes this "final" vs. earlier drafts

v1 was a literal first-pass translation of the FS with several placeholders
(commented-out logic, guessed Z-table/field names, a BAPI call missing a key
parameter, per-row `SELECT SINGLE` instead of bulk retrieval, ratios not
scaled to percentages, negative running-hours on overnight shifts). v2 fixed
the code-level issues that didn't require external confirmation. **v3 closes
the two remaining unknowns using your actual system's DDIC** (confirmed via
SE11 screenshots):

- **Workcenter exclusion**: the FS refers to "ZPP_WORKCENTER_EXCLUDE," but no
  such table exists in your system. The real table is `ZPP_WORK_CENTER`,
  keyed by `WERKS`+`ARBPL`, used to link a workcenter to a fixed asset — it
  has no dedicated exclude flag. **Per your confirmation, a workcenter is
  excluded when `ZPP_WORK_CENTER-LOEKZ = 'X'`** (the standard SAP
  deletion/blocked indicator), not merely by having a row in the table.
- **Rejected Qty**: the FS refers to "AFRU-ZZQUAN1..6," which don't exist.
  The real fields are `AFRU-ZZRQUAN1..ZZRQUAN6` ("Reusable Scrap Quantity
  1-6"), confirmed from your AFRU append structure.

## Still open before transport (business sign-off, not code)

These can't be resolved from the code alone — they need the functional
consultant / Basis / security team:

1. **STD QTY formula.** The FS's own two-step formula (`BMSCH/VGE04` times
   `Order Qty×VGE04/BMSCH`) algebraically cancels out to just Order Qty.
   Implemented literally, flagged inline — confirm the intended formula.
2. **ISERH (breakdown time) unit** — assumed minutes; some systems store
   this in seconds.
3. **R3 "Monthly Summary" granularity** — implemented as calendar month;
   confirm that's the intended bucket.
4. **AFKO GLTRP/GSTRP labeling** — the FS's "start"/"end" labels are the
   reverse of SAP's usual convention; mapped literally per the FS text.
5. **Plant authorization object** — `M_MATE_WRK`/`ACTVT 03` is a
   placeholder; confirm the object your security team actually requires.
6. **Text elements** (001, 002) need to be maintained in SE38 before
   activation.
7. **Not yet syntax-checked or unit-tested against a live system.** Run
   SE38 syntax check / ATC and test against real confirmations before
   transporting beyond a dev/unit-test client — this package is a
   corrected code review, not a substitute for that testing.

Full detail on every item above is in each variant's `docs/assumptions.md`.
