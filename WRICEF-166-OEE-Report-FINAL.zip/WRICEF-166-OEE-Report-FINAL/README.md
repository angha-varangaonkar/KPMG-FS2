# WRICEF 166 – Overall Production Report (OEE in Adhesive) — v5

Consolidated package for both syntax targets. Pick the one that matches
your system:

- `classic/` – classic ABAP syntax (`TABLES`, `PERFORM`/`FORM`, `SELECT ... INTO`)
- `s4hana2022/` – S/4HANA 2022 modern syntax (inline `DATA()`, `VALUE#`, local class)

Both implement identical business logic. See each folder's own `README.md`,
`docs/field_mapping.md`, and `docs/assumptions.md` for full detail.

## What makes this "v5" vs. earlier drafts

v1 was a literal first-pass translation of the FS with several placeholders
(commented-out logic, guessed Z-table/field names, a BAPI call missing a key
parameter, per-row `SELECT SINGLE` instead of bulk retrieval, ratios not
scaled to percentages, negative running-hours on overnight shifts). v2 fixed
the code-level issues that didn't require external confirmation. v3 closed
two DDIC unknowns using the real system structures (confirmed via SE11
screenshots):

- **Workcenter exclusion**: the FS refers to "ZPP_WORKCENTER_EXCLUDE," but no
  such table exists. The real table is `ZPP_WORK_CENTER`, keyed by
  `WERKS`+`ARBPL`, used to link a workcenter to a fixed asset — it has no
  dedicated exclude flag. A workcenter is excluded when
  `ZPP_WORK_CENTER-LOEKZ = 'X'` (the standard SAP deletion/blocked
  indicator), per business confirmation.
- **Rejected Qty**: the FS refers to "AFRU-ZZQUAN1..6," which don't exist.
  The real fields are `AFRU-ZZRQUAN1..ZZRQUAN6` ("Reusable Scrap Quantity
  1-6"), confirmed from the AFRU append structure.

v4 resolved the R3 "Monthly Summary" grouping: per business confirmation,
the FS's Detailed-FS instruction for R3 — "Show workcenter wise Cumulative
sum of Capacity utilization" — doesn't mention a month bucket at all.
"Monthly Summary" is only the radio button's label, not a grouping key. R3
is now a straight per-workcenter (`WERKS`+`ARBPL`) cumulative sum of
Capacity Utilization % across whatever date range is selected on the
screen — no calendar-month bucketing.

**v5 removes the placeholder Plant `AUTHORITY-CHECK`.** The FS marks Plant
as a mandatory authorization object, but the object used in earlier drafts
(`M_MATE_WRK`, a material-master authorization object) was a guess that
didn't really fit a confirmation/production-order report, and guessing
wrong here is worse than having no check at all — a wrong object can either
block legitimate users or silently pass everyone. **No `AUTHORITY-CHECK` is
implemented right now.** See "Still open" below for how to get the right
one before transport.

## Still open before transport (business sign-off, not code)

These can't be resolved from the code alone — they need the functional
consultant / Basis / security team:

1. **STD QTY formula.** The FS's own two-step formula (`BMSCH/VGE04` times
   `Order Qty×VGE04/BMSCH`) algebraically cancels out to just Order Qty.
   Implemented literally, flagged inline — confirm the intended formula
   with the functional consultant named on the FS (Dipesh Panwala).
2. **ISERH (breakdown time) unit** — assumed minutes; verify empirically
   (enter a known breakdown duration in CO11N, check the raw AFRU-ISERH
   value in SE16N) or via the field's domain/data element in SE11.
3. **AFKO GLTRP/GSTRP labeling** — the FS's "start"/"end" labels are the
   reverse of SAP's usual convention; mapped literally per the FS text.
4. **Plant AUTHORITY-CHECK.** Not implemented. Confirm the correct object
   with your security team:
   - Check whether this project already has a custom `Z` authorization
     object used by other PP Z-reports (ask Basis, or browse SU21 filtered
     to a custom object class) — reuse it for consistency if so.
   - Otherwise, run an authorization trace (`STAUTHTRACE`/`ST01`) against a
     comparable standard transaction restricted by plant — e.g. `CO11N` or
     `COOIS` — to see exactly which object/field fires, or check SU24 for
     those transactions' assigned objects.
   - Once confirmed, add an `AUTHORITY-CHECK` in `AT SELECTION-SCREEN` in
     both packages.
5. **Text elements** (001, 002) need to be maintained in SE38 before
   activation.
6. **Not yet syntax-checked or unit-tested against a live system.** Run
   SE38 syntax check / ATC and test against real confirmations before
   transporting beyond a dev/unit-test client — this package is a
   corrected code review, not a substitute for that testing.

Full detail on every item above is in each variant's `docs/assumptions.md`.
