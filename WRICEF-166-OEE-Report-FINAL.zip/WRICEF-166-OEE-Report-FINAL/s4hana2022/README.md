# WRICEF 166 – Overall Production Report (OEE in Adhesive) — S/4HANA 2022

S/4HANA 2022-compatible ABAP implementation, generated from the Functional
Specification `Copy of WRICEF ID 166-Overall production report for SFG FG and
moulding sperately.xlsx`. Same business logic as the classic-syntax version;
syntax modernized to current ABAP style.

## What changed vs. the classic version (syntax only)

- **No `TABLES` statement.** Obsolete in modern ABAP — select-options
  reference DDIC fields directly via `TYPE`.
- **Modern Open SQL** — `SELECT ... INTO TABLE @DATA(...)` / inline
  `@DATA(...)` host variables, `FOR ALL ENTRIES` for bulk retrieval.
- **Inline declarations** (`DATA(...)`) throughout instead of upfront `DATA:`
  blocks for local work areas.
- **Constructor expressions** — `VALUE #( ... )` to build structures in one
  statement instead of field-by-field `MOVE`.
- **Encapsulated in a local class** (`lcl_report`) rather than `PERFORM`
  subroutines.
- **`NEW`** instead of `CREATE OBJECT`.
- Table-expression lookups (`itab[ key = value ]`) instead of `READ TABLE ...
  INTO` for the monthly-summary accumulation.

## v2-v5 changes (code review fixes — same as the classic version)

Bulk (`FOR ALL ENTRIES`) data retrieval instead of one `SELECT SINGLE`/BAPI
call per confirmation line; routing base qty/machine time (`BMSCH`/`VGE04`)
resolved via `PLKO`+`PLPO` so the correct routing alternative *and* operation
are used (v1's BAPI call never passed `VORNR`); Manhours no longer skipped
when the routing lookup fails; percentages expressed on a 0-100 scale;
Running Hours computed from full date+time timestamps so overnight
confirmations don't go negative; Start Date/End Date columns added; UOM
sourced from `AFRU-GMEIN` (not `MEINS`, which standard AFRU does not have).
**v3 replaces the two guessed Z-structures with the real ones confirmed via
SE11**: workcenter exclusion uses `ZPP_WORK_CENTER` with `LOEKZ = 'X'` as the
exclusion signal (there is no `ZPP_WORKCENTER_EXCLUDE` table), and Rejected
Qty sums `AFRU-ZZRQUAN1..ZZRQUAN6` (not `ZZQUAN1..6`). **v4 resolves R3's
grouping**: a plain per-workcenter cumulative sum, no calendar-month bucket.
**v5 removes the placeholder Plant `AUTHORITY-CHECK`** rather than shipping a
guessed object — see "Still worth doing" below. Full detail is in the
report's header comment and in `docs/assumptions.md`.

## Contents

- `zsrc/ZPP_OEE_ADHESIVE_REPORT.abap` – main report program (S/4HANA 2022 syntax)
- `docs/field_mapping.md` – field-by-field source-to-target mapping
- `docs/assumptions.md` – open items to confirm before transport

## Still worth doing before deploying

Same open items as the classic version — the syntax rewrite doesn't change
any business-logic ambiguity:

1. Get sign-off on the intended STD QTY formula (see `docs/assumptions.md` #1).
2. Confirm the `ISERH` unit and `AFKO` start/end field labeling
   (assumptions.md #4, #6).
3. **Add a Plant `AUTHORITY-CHECK`.** None is implemented right now —
   confirm the correct object with your security team (check for an
   existing custom Z auth object first, or trace a comparable transaction
   like `CO11N`/`COOIS` with `STAUTHTRACE`/SU24) and add it in
   `AT SELECTION-SCREEN`.
4. Add text elements (001, 002) via SE38 → Goto → Text Elements.
5. This has not been syntax-checked against a live S/4HANA 2022 system —
   run it through ATC (ABAP Test Cockpit) and SE38 syntax check before
   transport; table field lists (e.g. which AFRU/CAUFV fields exist in your
   specific release) should be verified against your system's DDIC.

## Note on architecture

This stays a classic ABAP report with `cl_salv_table` for output, matching
the original FS's "Report" object type. If your team is standardizing on
CDS views + Fiori Elements / Analytics for new S/4HANA reporting, the
`docs/field_mapping.md` table still gives you the source-field lineage
needed to build this as a CDS-based analytical query instead.
