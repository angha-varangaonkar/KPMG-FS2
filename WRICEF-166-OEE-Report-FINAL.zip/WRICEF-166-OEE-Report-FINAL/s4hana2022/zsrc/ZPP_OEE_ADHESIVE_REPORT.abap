*&---------------------------------------------------------------------*
*& Report ZPP_OEE_ADHESIVE_REPORT
*&---------------------------------------------------------------------*
*& WRICEF ID  : 166
*& Object Name: Report for OEE in Adhesive
*& Module     : PP
*& Target     : S/4HANA 2022 (ABAP 7.56 / modern syntax)
*& Version    : 2 - corrected per code review, see docs/assumptions.md
*&
*& Purpose:
*&   Single selection-screen driven report offering three mutually
*&   exclusive output views (radio buttons), per the FS:
*&     R1 - Moulding Report            (all routing types)
*&     R2 - SFG and FG Production      (routing type PLNTY = '2' only)
*&     R3 - Monthly Summary            (workcenter-wise cumulative
*&                                      Capacity Utilization %)
*&
*& Version 2 changes vs. v1 - same fixes as the classic-syntax sibling
*& program in this package; see its header comment / docs/assumptions.md
*& for the full writeup. Summary:
*&   - Bulk (FOR ALL ENTRIES) retrieval instead of one SELECT SINGLE
*&     per confirmation line.
*&   - BMSCH/VGE04 resolved via PLKO (PLNAL -> ZAEHL) + PLPO filtered
*&     by ZAEHL and AFRU-VORNR, so the correct routing alternative AND
*&     operation are used (v1's BAPI call never passed VORNR).
*&   - MANHOURS no longer depends on the routing lookup succeeding.
*&   - A%/Q%/P%/OEE%/CAPACITY UTILIZATION % now on a 0-100 scale.
*&   - RUNNING HRS combines ISDD+ISDZ / IEDD+IEDZ via timestamps so an
*&     overnight confirmation doesn't yield a negative duration.
*&   - Added Start Date / End Date (AFRU-ISDD/IEDD) columns.
*&   - UOM sourced from AFRU-GMEIN (not AFRU-MEINS, which standard
*&     AFRU does not have - verify against your DDIC).
*&   - Workcenter exclusion and rejected-qty logic use the actual DDIC
*&     structures confirmed via SE11: ZPP_WORK_CENTER (not
*&     ZPP_WORKCENTER_EXCLUDE, which doesn't exist - ZPP_WORK_CENTER
*&     is keyed by WERKS+ARBPL and links a workcenter to a fixed
*&     asset; a workcenter is excluded when its LOEKZ = 'X', per
*&     business confirmation, not merely by having a row there), and
*&     AFRU-ZZRQUAN1..ZZRQUAN6 ("Reusable Scrap Quantity 1-6", not
*&     ZZQUAN1..6) for rejected quantity.
*&   - Added an AUTHORITY-CHECK on Plant (placeholder object
*&     M_MATE_WRK / ACTVT 03 - confirm with your security team).
*&
*& Still open / needs functional consultant sign-off (see
*& docs/assumptions.md): STD QTY formula ambiguity, ISERH unit,
*& R3 monthly-bucket granularity, AFKO GLTRP/GSTRP start/end naming.
*& Not yet syntax-checked / unit-tested against a live system - run
*& ATC and SE38 syntax check, and verify field lists against your
*& release's DDIC, before transport.
*&---------------------------------------------------------------------*
REPORT zpp_oee_adhesive_report.

*&---------------------------------------------------------------------*
*& Output structure - one line per Confirmation (AFRU-ERSDA/RUECK/RMZHL)
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_output,
         werks            TYPE afru-werks,            "Plant Code
         datum            TYPE afru-ersda,             "Confirmation entry date
         matnr            TYPE mara-matnr,             "Material Code
         maktx            TYPE makt-maktx,             "Description
         arbpl            TYPE crhd-arbpl,             "Workcentre Name
         ktext            TYPE crtx-ktext,             "Workcenter Description
         aufnr            TYPE afru-aufnr,             "Production Order
         auart            TYPE caufv-auart,            "Order Type
         matkl            TYPE mara-matkl,             "Material Group
         ntgew            TYPE mara-ntgew,             "Net Weight
         gamng            TYPE caufv-gamng,            "Order Qty
         gmnga            TYPE afru-gmnga,             "Confirm Qty
         meins            TYPE afru-gmein,             "UOM (AFRU-GMEIN, see header note)
         tot_tonnage      TYPE p LENGTH 13 DECIMALS 3,  "Total Tonnage
         std_qty          TYPE p LENGTH 13 DECIMALS 3,  "Std Qty
         manhours         TYPE p LENGTH 13 DECIMALS 3,  "Manhours
         start_date       TYPE afru-isdd,              "Start Date
         end_date         TYPE afru-iedd,              "End Date
         start_time       TYPE afru-isdz,              "Start Time
         end_time         TYPE afru-iedz,              "End Time
         running_hrs      TYPE p LENGTH 9 DECIMALS 4,   "Running Hrs
         a_pct            TYPE p LENGTH 7 DECIMALS 2,   "Availability %
         q_pct            TYPE p LENGTH 7 DECIMALS 2,   "Quality %
         p_pct            TYPE p LENGTH 7 DECIMALS 2,   "Performance %
         oee_pct          TYPE p LENGTH 7 DECIMALS 2,   "OEE %
         rejected_qty     TYPE p LENGTH 13 DECIMALS 3,  "Rejected Qty
         breakdown_time   TYPE p LENGTH 9 DECIMALS 4,   "Breakdown Time (hrs)
         cap_util_pct     TYPE p LENGTH 7 DECIMALS 2,   "Capacity Utilization %
         verid            TYPE afpo-verid,             "Production Version
         stlal            TYPE caufv-stlal,            "Alternative BOM
         order_start_date TYPE afko-gltrp,             "Order Start Date
         order_end_date   TYPE afko-gstrp,             "Order End Date
         vornr            TYPE afru-vornr,             "Phase / Operation
         cancelled        TYPE afru-stzhl,             "Cancelled
         reversed         TYPE afru-stokz,             "Reversed
         rueck            TYPE afru-rueck,             "Confirmation Number
         rmzhl            TYPE afru-rmzhl,             "Confirmation Counter
         setup_machine    TYPE afru-ism02,             "Setup Machine (confirmed)
         std_manhours     TYPE p LENGTH 13 DECIMALS 3,  "Std Man Hours
       END OF ty_output.

TYPES: ty_output_t TYPE STANDARD TABLE OF ty_output WITH EMPTY KEY.

TYPES: BEGIN OF ty_monthly,
         arbpl        TYPE crhd-arbpl,
         month        TYPE spmon,
         cap_util_sum TYPE p LENGTH 9 DECIMALS 4,
       END OF ty_monthly.

TYPES: ty_monthly_t TYPE STANDARD TABLE OF ty_monthly WITH EMPTY KEY.

DATA: gt_output          TYPE ty_output_t,
      gt_monthly_summary TYPE ty_monthly_t.

*&---------------------------------------------------------------------*
*& Local class definition - must precede its use in the event blocks
*& below; implementation is at the bottom of the program.
*&---------------------------------------------------------------------*
CLASS lcl_report DEFINITION.

  PUBLIC SECTION.
    METHODS: build_production_data
      IMPORTING iv_plnty_filter        TYPE plnty
      RETURNING VALUE(rt_output)       TYPE ty_output_t.

    METHODS: build_monthly_summary
      IMPORTING it_output              TYPE ty_output_t
      RETURNING VALUE(rt_monthly)      TYPE ty_monthly_t.

    CLASS-METHODS: display_alv
      CHANGING ct_table TYPE STANDARD TABLE.

ENDCLASS.

*&---------------------------------------------------------------------*
*& Selection Screen (per FS "Selection Screen" block)
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

SELECT-OPTIONS: s_werks FOR afru-werks OBLIGATORY,     "Plant Code - MANDATORY
                s_matnr FOR mara-matnr,                 "Material Code - range
                s_datum FOR afru-ersda OBLIGATORY,      "Date - MANDATORY
                s_arbpl FOR afru-arbpl.                 "Workcenter

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.

PARAMETERS: p_r1 RADIOBUTTON GROUP rb1 DEFAULT 'X' USER-COMMAND rbc, "Moulding Report
            p_r2 RADIOBUTTON GROUP rb1,                              "SFG and FG Production
            p_r3 RADIOBUTTON GROUP rb1.                              "Monthly Summary

SELECTION-SCREEN END OF BLOCK b2.

*&---------------------------------------------------------------------*
*& Text symbols (maintain via SE38 Goto > Text Elements):
*&   001 Selection Criteria
*&   002 Report Type
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& AT SELECTION-SCREEN - basic validation + plant authorization
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN.
  IF s_werks[] IS INITIAL.
    MESSAGE 'Plant is mandatory' TYPE 'E'.
  ENDIF.
  IF s_datum[] IS INITIAL.
    MESSAGE 'Date range is mandatory' TYPE 'E'.
  ENDIF.

* Plant as an authorization object (FS: mandatory). M_MATE_WRK /
* ACTVT 03 is a placeholder - confirm the correct object with your
* security team and adjust if a different one applies.
  LOOP AT s_werks INTO DATA(ls_werks_chk).
    AUTHORITY-CHECK OBJECT 'M_MATE_WRK'
      ID 'WERKS' FIELD ls_werks_chk-low
      ID 'ACTVT' FIELD '03'.
    IF sy-subrc <> 0.
      MESSAGE 'You are not authorized for this Plant' TYPE 'E'.
    ENDIF.
  ENDLOOP.

*&---------------------------------------------------------------------*
*& START-OF-SELECTION
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  CASE abap_true.
    WHEN p_r1.
      gt_output = NEW lcl_report( )->build_production_data( iv_plnty_filter = space ).
    WHEN p_r2.
      gt_output = NEW lcl_report( )->build_production_data( iv_plnty_filter = '2' ).
    WHEN p_r3.
      gt_output = NEW lcl_report( )->build_production_data( iv_plnty_filter = space ).
      gt_monthly_summary = NEW lcl_report( )->build_monthly_summary( gt_output ).
  ENDCASE.

*&---------------------------------------------------------------------*
*& END-OF-SELECTION - render ALV
*&---------------------------------------------------------------------*
END-OF-SELECTION.

  IF p_r3 = abap_true.
    lcl_report=>display_alv( CHANGING ct_table = gt_monthly_summary ).
  ELSE.
    lcl_report=>display_alv( CHANGING ct_table = gt_output ).
  ENDIF.

*&---------------------------------------------------------------------*
*& Local class implementation - extraction / derivation / display logic
*&---------------------------------------------------------------------*
CLASS lcl_report IMPLEMENTATION.

  METHOD build_production_data.

    TYPES:
      BEGIN OF ty_afru,
        werks   TYPE afru-werks,
        ersda   TYPE afru-ersda,
        aufnr   TYPE afru-aufnr,
        arbid   TYPE afru-arbid,
        rueck   TYPE afru-rueck,
        rmzhl   TYPE afru-rmzhl,
        vornr   TYPE afru-vornr,
        gmnga   TYPE afru-gmnga,
        gmein   TYPE afru-gmein,
        ism02   TYPE afru-ism02,
        ism04   TYPE afru-ism04,
        isdd    TYPE afru-isdd,
        iedd    TYPE afru-iedd,
        isdz    TYPE afru-isdz,
        iedz    TYPE afru-iedz,
        iserh   TYPE afru-iserh,
        zzrquan1 TYPE afru-zzrquan1,
        zzrquan2 TYPE afru-zzrquan2,
        zzrquan3 TYPE afru-zzrquan3,
        zzrquan4 TYPE afru-zzrquan4,
        zzrquan5 TYPE afru-zzrquan5,
        zzrquan6 TYPE afru-zzrquan6,
        stzhl   TYPE afru-stzhl,
        stokz   TYPE afru-stokz,
      END OF ty_afru,

      BEGIN OF ty_caufv,
        aufnr  TYPE caufv-aufnr,
        plnbez TYPE caufv-plnbez,
        gamng  TYPE caufv-gamng,
        auart  TYPE caufv-auart,
        plnty  TYPE caufv-plnty,
        plnnr  TYPE caufv-plnnr,
        plnal  TYPE caufv-plnal,
        stlal  TYPE caufv-stlal,
      END OF ty_caufv,

      BEGIN OF ty_crhd,
        objid TYPE crhd-objid,
        arbpl TYPE crhd-arbpl,
        werks TYPE crhd-werks,
      END OF ty_crhd,

      BEGIN OF ty_excl,
        werks TYPE zpp_work_center-werks,
        arbpl TYPE zpp_work_center-arbpl,
      END OF ty_excl,
      ty_excl_t TYPE STANDARD TABLE OF ty_excl WITH EMPTY KEY,

      BEGIN OF ty_crtx,
        objid TYPE crtx-objid,
        ktext TYPE crtx-ktext,
      END OF ty_crtx,

      BEGIN OF ty_mara,
        matnr TYPE mara-matnr,
        matkl TYPE mara-matkl,
        ntgew TYPE mara-ntgew,
      END OF ty_mara,

      BEGIN OF ty_makt,
        matnr TYPE makt-matnr,
        maktx TYPE makt-maktx,
      END OF ty_makt,

      BEGIN OF ty_afpo,
        aufnr TYPE afpo-aufnr,
        verid TYPE afpo-verid,
      END OF ty_afpo,

      BEGIN OF ty_afko,
        aufnr TYPE afko-aufnr,
        gstrp TYPE afko-gstrp,
        gltrp TYPE afko-gltrp,
      END OF ty_afko,

      BEGIN OF ty_plko,
        plnty TYPE plko-plnty,
        plnnr TYPE plko-plnnr,
        plnal TYPE plko-plnal,
        zaehl TYPE plko-zaehl,
      END OF ty_plko,

      BEGIN OF ty_plpo,
        plnty TYPE plpo-plnty,
        plnnr TYPE plpo-plnnr,
        zaehl TYPE plpo-zaehl,
        vornr TYPE plpo-vornr,
        bmsch TYPE plpo-bmsch,
        vge04 TYPE plpo-vge04,
      END OF ty_plpo,
      ty_plpo_t TYPE STANDARD TABLE OF ty_plpo WITH EMPTY KEY.

    " Step 1/2: Plant + Date from selection screen against AFRU-WERKS / ERSDA
    SELECT werks, ersda, aufnr, arbid, rueck, rmzhl, vornr, gmnga, gmein,
           ism02, ism04, isdd, iedd, isdz, iedz, iserh,
           zzrquan1, zzrquan2, zzrquan3, zzrquan4, zzrquan5, zzrquan6,
           stzhl, stokz
      FROM afru
      WHERE werks IN @s_werks
        AND ersda IN @s_datum
        AND arbpl IN @s_arbpl
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_afru).

    CHECK lt_afru IS NOT INITIAL.

    SELECT aufnr, plnbez, gamng, auart, plnty, plnnr, plnal, stlal
      FROM caufv
      FOR ALL ENTRIES IN @lt_afru
      WHERE aufnr = @lt_afru-aufnr
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_caufv).

    IF iv_plnty_filter IS NOT INITIAL.
      DELETE lt_caufv WHERE plnty <> iv_plnty_filter.
    ENDIF.

    IF s_matnr[] IS NOT INITIAL.
      DELETE lt_caufv WHERE plnbez NOT IN s_matnr.
    ENDIF.

    CHECK lt_caufv IS NOT INITIAL.

    SELECT objid, arbpl, werks
      FROM crhd
      FOR ALL ENTRIES IN @lt_afru
      WHERE objid = @lt_afru-arbid
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_crhd).

    " --- Workcenter exclusion (FS seq 4): ZPP_WORK_CENTER is keyed by
    "     WERKS + ARBPL (confirmed via SE11) but has no dedicated
    "     "exclude" flag - it links a workcenter to a fixed asset
    "     (VERWE/ANLN1/ZANLN). Per business confirmation, a workcenter
    "     is treated as excluded when its ZPP_WORK_CENTER-LOEKZ
    "     (deletion/blocked indicator) = 'X', not merely by having a
    "     row here. ---
    DATA(lt_excl) = VALUE ty_excl_t( ).
    IF lt_crhd IS NOT INITIAL.
      SELECT werks, arbpl
        FROM zpp_work_center
        FOR ALL ENTRIES IN @lt_crhd
        WHERE werks = @lt_crhd-werks
          AND arbpl = @lt_crhd-arbpl
          AND loekz = 'X'
        INTO CORRESPONDING FIELDS OF TABLE @lt_excl.
    ENDIF.

    SELECT objid, ktext
      FROM crtx
      FOR ALL ENTRIES IN @lt_crhd
      WHERE objid = @lt_crhd-objid
        AND spras = @sy-langu
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_crtx).

    SELECT matnr, matkl, ntgew
      FROM mara
      FOR ALL ENTRIES IN @lt_caufv
      WHERE matnr = @lt_caufv-plnbez
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_mara).

    SELECT matnr, maktx
      FROM makt
      FOR ALL ENTRIES IN @lt_caufv
      WHERE matnr = @lt_caufv-plnbez
        AND spras = @sy-langu
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_makt).

    SELECT aufnr, verid
      FROM afpo
      FOR ALL ENTRIES IN @lt_caufv
      WHERE aufnr = @lt_caufv-aufnr
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_afpo).

    SELECT aufnr, gstrp, gltrp
      FROM afko
      FOR ALL ENTRIES IN @lt_caufv
      WHERE aufnr = @lt_caufv-aufnr
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_afko).

    " --- Routing base qty (BMSCH) / machine time (VGE04): the FS says
    "     to pass PLNTY, PLNNR, PLNAL and VORNR. PLNAL is not itself a
    "     field on PLPO, so resolve it to PLKO's internal group counter
    "     (ZAEHL) first, then read PLPO by that counter AND the
    "     confirmed operation (AFRU-VORNR). v1's BAPI call never passed
    "     VORNR, risking the wrong operation's values. ---
    SELECT plnty, plnnr, plnal, zaehl
      FROM plko
      FOR ALL ENTRIES IN @lt_caufv
      WHERE plnty = @lt_caufv-plnty
        AND plnnr = @lt_caufv-plnnr
        AND plnal = @lt_caufv-plnal
      INTO CORRESPONDING FIELDS OF TABLE @DATA(lt_plko).

    DATA(lt_plpo) = VALUE ty_plpo_t( ).
    IF lt_plko IS NOT INITIAL.
      SELECT plnty, plnnr, zaehl, vornr, bmsch, vge04
        FROM plpo
        FOR ALL ENTRIES IN @lt_plko
        WHERE plnty = @lt_plko-plnty
          AND plnnr = @lt_plko-plnnr
          AND zaehl = @lt_plko-zaehl
        INTO CORRESPONDING FIELDS OF TABLE @lt_plpo.
    ENDIF.

    SORT lt_caufv BY aufnr.
    SORT lt_crhd  BY objid.
    SORT lt_crtx  BY objid.
    SORT lt_mara  BY matnr.
    SORT lt_makt  BY matnr.
    SORT lt_afpo  BY aufnr.
    SORT lt_afko  BY aufnr.
    SORT lt_plko  BY plnty plnnr plnal.
    SORT lt_plpo  BY plnty plnnr zaehl vornr.

    LOOP AT lt_afru INTO DATA(ls_afru).

      READ TABLE lt_crhd INTO DATA(ls_crhd) WITH KEY objid = ls_afru-arbid BINARY SEARCH.
      IF sy-subrc <> 0.
        CLEAR ls_crhd.
      ENDIF.

      " --- Exclude workcenters where ZPP_WORK_CENTER-LOEKZ = 'X' ---
      READ TABLE lt_excl TRANSPORTING NO FIELDS
        WITH KEY werks = ls_crhd-werks
                 arbpl = ls_crhd-arbpl.
      IF sy-subrc = 0.
        CONTINUE.
      ENDIF.

      " --- Order header (CAUFV) via AFRU-AUFNR; the PLNTY filter /
      "     material-range exclusion were already applied to lt_caufv ---
      READ TABLE lt_caufv INTO DATA(ls_caufv) WITH KEY aufnr = ls_afru-aufnr BINARY SEARCH.
      IF sy-subrc <> 0.
        CONTINUE.
      ENDIF.

      READ TABLE lt_mara INTO DATA(ls_mara) WITH KEY matnr = ls_caufv-plnbez BINARY SEARCH.
      IF sy-subrc <> 0.
        CLEAR ls_mara.
      ENDIF.

      READ TABLE lt_makt INTO DATA(ls_makt) WITH KEY matnr = ls_caufv-plnbez BINARY SEARCH.
      IF sy-subrc <> 0.
        CLEAR ls_makt.
      ENDIF.

      READ TABLE lt_crtx INTO DATA(ls_crtx) WITH KEY objid = ls_crhd-objid BINARY SEARCH.
      IF sy-subrc <> 0.
        CLEAR ls_crtx.
      ENDIF.

      READ TABLE lt_afpo INTO DATA(ls_afpo) WITH KEY aufnr = ls_caufv-aufnr BINARY SEARCH.
      IF sy-subrc <> 0.
        CLEAR ls_afpo.
      ENDIF.

      READ TABLE lt_afko INTO DATA(ls_afko) WITH KEY aufnr = ls_caufv-aufnr BINARY SEARCH.
      IF sy-subrc <> 0.
        CLEAR ls_afko.
      ENDIF.

      DATA(ls_output) = VALUE ty_output(
        werks            = ls_afru-werks
        datum            = ls_afru-ersda
        matnr            = ls_caufv-plnbez
        maktx            = ls_makt-maktx
        arbpl            = ls_crhd-arbpl
        ktext            = ls_crtx-ktext
        aufnr            = ls_afru-aufnr
        auart            = ls_caufv-auart
        matkl            = ls_mara-matkl
        ntgew            = ls_mara-ntgew
        gamng            = ls_caufv-gamng
        gmnga            = ls_afru-gmnga
        meins            = ls_afru-gmein
        verid            = ls_afpo-verid
        stlal            = ls_caufv-stlal
        order_start_date = ls_afko-gltrp
        order_end_date   = ls_afko-gstrp
        vornr            = ls_afru-vornr
        cancelled        = ls_afru-stzhl
        reversed         = ls_afru-stokz
        rueck            = ls_afru-rueck
        rmzhl            = ls_afru-rmzhl
        setup_machine    = ls_afru-ism02
        start_date       = ls_afru-isdd
        end_date         = ls_afru-iedd
        start_time       = ls_afru-isdz
        end_time         = ls_afru-iedz ).

      " --- Total tonnage = Confirmed Qty * Net Weight / 1000 (per FS) ---
      ls_output-tot_tonnage = ( ls_output-gmnga * ls_output-ntgew ) / 1000.

      " --- Running hours: combine date+time so a confirmation that
      "     runs past midnight doesn't produce a negative duration ---
      DATA(lv_seconds) = CONV p( 0 ).
      IF ls_afru-isdd IS NOT INITIAL AND ls_afru-iedd IS NOT INITIAL.
        CONVERT DATE ls_afru-isdd TIME ls_afru-isdz
          INTO TIME STAMP DATA(lv_start_ts) TIME ZONE sy-zonlo.
        CONVERT DATE ls_afru-iedd TIME ls_afru-iedz
          INTO TIME STAMP DATA(lv_end_ts) TIME ZONE sy-zonlo.
        TRY.
            cl_abap_tstmp=>subtract(
              EXPORTING tstmp1   = lv_end_ts
                        tstmp2   = lv_start_ts
              IMPORTING rseconds = lv_seconds ).
          CATCH cx_root.
            lv_seconds = 0.
        ENDTRY.
        ls_output-running_hrs = lv_seconds / 3600.
      ENDIF.

      " --- Manhours = (ISM02 + ISM04) / 60 - independent of routing
      "     data, so it's calculated regardless of whether BMSCH/VGE04
      "     resolve ---
      ls_output-manhours = ( ls_afru-ism02 + ls_afru-ism04 ) / 60.

      " --- Rejected Qty = sum of AFRU-ZZRQUAN1..ZZRQUAN6 (Reusable
      "     Scrap Quantity 1-6) ---
      ls_output-rejected_qty = ls_afru-zzrquan1 + ls_afru-zzrquan2
                              + ls_afru-zzrquan3 + ls_afru-zzrquan4
                              + ls_afru-zzrquan5 + ls_afru-zzrquan6.

      " --- Breakdown time = AFRU-ISERH / 60 (minutes -> hours; confirm
      "     actual unit - see docs/assumptions.md #4) ---
      ls_output-breakdown_time = ls_afru-iserh / 60.

      " --- STD QTY / Std Man Hours / P%: need routing base qty (BMSCH)
      "     and machine time (VGE04) for the confirmed operation ---
      READ TABLE lt_plko INTO DATA(ls_plko)
        WITH KEY plnty = ls_caufv-plnty
                 plnnr = ls_caufv-plnnr
                 plnal = ls_caufv-plnal
        BINARY SEARCH.

      DATA(ls_plpo) = VALUE ty_plpo( ).
      IF sy-subrc = 0.
        READ TABLE lt_plpo INTO ls_plpo
          WITH KEY plnty = ls_plko-plnty
                   plnnr = ls_plko-plnnr
                   zaehl = ls_plko-zaehl
                   vornr = ls_afru-vornr
          BINARY SEARCH.
      ENDIF.

      DATA(lv_a_ratio) = CONV p( 0 ).
      DATA(lv_q_ratio) = CONV p( 0 ).
      DATA(lv_p_ratio) = CONV p( 0 ).

      IF ls_plpo-vge04 <> 0 AND ls_plpo-bmsch <> 0.

        " FS logic (as literally stated) is two derivations multiplied
        " together - see docs/assumptions.md #1: algebraically this
        " always resolves to Order Qty regardless of the routing
        " values. Implemented literally pending confirmation from the
        " functional consultant.
        DATA(lv_val1) = ls_plpo-bmsch / ls_plpo-vge04.
        DATA(lv_val2) = ( ls_output-gamng * ls_plpo-vge04 ) / ls_plpo-bmsch.
        ls_output-std_qty = lv_val1 * lv_val2.

        " --- Std Man Hours = Order Qty * ISM04 / BMSCH ---
        ls_output-std_manhours = ( ls_output-gamng * ls_afru-ism04 ) / ls_plpo-bmsch.

        " --- P% = Actual PC/min / Std PC/min ---
        "     Actual PC/min = Confirmed Qty / ISM04 (confirmed machine time)
        "     Std PC/min    = BMSCH / VGE04
        IF ls_afru-ism04 <> 0.
          lv_p_ratio = ( ls_output-gmnga / ls_afru-ism04 ) / lv_val1.
          ls_output-p_pct = lv_p_ratio * 100.
        ENDIF.
      ENDIF.

      " --- A% = (Runtime - Breakdown) / Runtime ---
      IF ls_output-running_hrs <> 0.
        lv_a_ratio = ( ls_output-running_hrs - ls_output-breakdown_time )
                     / ls_output-running_hrs.
        ls_output-a_pct = lv_a_ratio * 100.
      ENDIF.

      " --- Q% = Confirmed Qty / (Confirmed Qty + Rejected Qty) ---
      IF ( ls_output-gmnga + ls_output-rejected_qty ) <> 0.
        lv_q_ratio = ls_output-gmnga / ( ls_output-gmnga + ls_output-rejected_qty ).
        ls_output-q_pct = lv_q_ratio * 100.
      ENDIF.

      " --- OEE% = A% * Q% * P% (on the underlying ratios, then scaled
      "     to a percentage once) ---
      ls_output-oee_pct = lv_a_ratio * lv_q_ratio * lv_p_ratio * 100.

      " --- Capacity Utilization % = Confirmed Qty / Std Qty ---
      IF ls_output-std_qty <> 0.
        ls_output-cap_util_pct = ( ls_output-gmnga / ls_output-std_qty ) * 100.
      ENDIF.

      INSERT ls_output INTO TABLE rt_output.

    ENDLOOP.

  ENDMETHOD.

  METHOD build_monthly_summary.

    " Radio Button 3: "Show workcenter wise cumulative sum of Capacity
    " Utilization" (per FS Detailed FS tab). Monthly bucket = YYYYMM
    " derived from confirmation date - see docs/assumptions.md point 5.
    LOOP AT it_output INTO DATA(ls_output).

      DATA(lv_month) = CONV spmon( ls_output-datum(6) ).

      ASSIGN rt_monthly[ arbpl = ls_output-arbpl
                          month = lv_month ] TO FIELD-SYMBOL(<ls_summary>).

      IF sy-subrc = 0.
        <ls_summary>-cap_util_sum = <ls_summary>-cap_util_sum
                                     + ls_output-cap_util_pct.
      ELSE.
        INSERT VALUE ty_monthly(
          arbpl        = ls_output-arbpl
          month        = lv_month
          cap_util_sum = ls_output-cap_util_pct ) INTO TABLE rt_monthly.
      ENDIF.

    ENDLOOP.

    SORT rt_monthly BY arbpl month.

  ENDMETHOD.

  METHOD display_alv.

    IF ct_table IS INITIAL.
      RETURN.
    ENDIF.

    TRY.
        cl_salv_table=>factory(
          IMPORTING r_salv_table = DATA(lo_salv)
          CHANGING  t_table      = ct_table ).

        lo_salv->get_functions( )->set_all( abap_true ).
        lo_salv->get_columns( )->set_optimize( abap_true ).
        lo_salv->display( ).

      CATCH cx_salv_msg INTO DATA(lx_salv).
        MESSAGE lx_salv->get_text( ) TYPE 'E'.
    ENDTRY.

  ENDMETHOD.

ENDCLASS.
