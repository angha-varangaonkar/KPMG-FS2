# Field Mapping — WRICEF 166 (v3)

Source: "Detailed FS" tab of the original spreadsheet.

| Output Field | Source | Logic |
|---|---|---|
| PLANT CODE | AFRU-WERKS | Selection screen plant |
| DATE | AFRU-ERSDA | Confirmation entry date |
| MATERIAL CODE | CAUFV-PLNBEZ | Via AFRU-AUFNR → CAUFV-AUFNR |
| DESCRIPTION | MAKT-MAKTX | CAUFV-PLNBEZ → MARA/MAKT, language EN |
| WORKCENTRE NAME | CRHD-ARBPL | AFRU-ARBID → CRHD-OBJID; excludes rows where ZPP_WORK_CENTER-LOEKZ = 'X' for that WERKS+ARBPL |
| WORKCENTER DES | CRTX-KTEXT | CRHD-OBJID → CRTX-OBJID |
| PRODUCTION ORDER | AFRU-AUFNR | Direct |
| ORDER TYPE | CAUFV-AUART | Via CAUFV-AUFNR |
| MATERIAL GROUP | MARA-MATKL | Via CAUFV-PLNBEZ → MARA-MATNR |
| NET WEIGHT | MARA-NTGEW | Via CAUFV-PLNBEZ → MARA-MATNR |
| ORDER QTY | CAUFV-GAMNG | Via AFRU-AUFNR → CAUFV-AUFNR |
| CONFIRM QTY | AFRU-GMNGA | Direct |
| UOM | AFRU-GMEIN | Direct (v1 used AFRU-MEINS, which standard AFRU does not have) |
| TOTAL TONNAGE | Calculated | Confirmed Qty × Net Weight / 1000 |
| STD QTY | PLKO + PLPO (BMSCH, VGE04) | PLNAL → PLKO-ZAEHL → PLPO filtered by ZAEHL + AFRU-VORNR. See assumptions.md #1 — formula ambiguity flagged |
| MANHOURS | AFRU-ISM02 + AFRU-ISM04 | Sum / 60 |
| START DATE | AFRU-ISDD | Direct |
| END DATE | AFRU-IEDD | Direct |
| START TIME | AFRU-ISDZ | Direct |
| END TIME | AFRU-IEDZ | Direct |
| RUNNING HRS | (ISDD+ISDZ) to (IEDD+IEDZ) | Full timestamp difference, in hours (avoids negative values on overnight confirmations) |
| A% | Runtime, Breakdown Time | (Runtime − Breakdown Time) / Runtime, × 100 |
| Q% | AFRU-GMNGA, ZZRQUAN1-6 | Confirmed Qty / (Confirmed Qty + Rejected Qty), × 100 |
| P% | Actual vs Std PC/min | (Confirmed Qty / AFRU-ISM04) / (BMSCH / VGE04), × 100 |
| OEE % | Calculated | A% × Q% × P% (computed on the underlying ratios, scaled to % once) |
| REJECTED QTY | AFRU-ZZRQUAN1..ZZRQUAN6 | Sum of custom append fields ("Reusable Scrap Quantity 1-6") |
| BREAKDOWN TIME | AFRU-ISERH | / 60 (minutes → hours) |
| CAPACITY UTILIZATION % | Calculated | Confirmed Qty / STD Qty, × 100 |
| Production version | AFPO-VERID | Via CAUFV-AUFNR → AFPO-AUFNR |
| Alternative BOM | CAUFV-STLAL | Direct |
| Order Start Date | AFKO-GLTRP | Via CAUFV-AUFNR → AFKO-AUFNR |
| Order End Date | AFKO-GSTRP | Via CAUFV-AUFNR → AFKO-AUFNR |
| Phases/Operation | AFRU-VORNR | Direct |
| Cancelled | AFRU-STZHL | Direct |
| Reversed | AFRU-STOKZ | Direct |
| Confirmation Number | AFRU-RUECK | Direct |
| Confirmation Counter | AFRU-RMZHL | Direct |
| Setup Machine | AFRU-ISM02 | Direct |
| Std Man Hours | Order Qty, AFRU-ISM04, BMSCH | Order Qty × ISM04 / BMSCH |

## Radio button variants

- **R1 – Moulding Report**: no routing-type restriction.
- **R2 – SFG and FG Production**: identical logic, filtered to `CAUFV-PLNTY = '2'` only
  (per FS note: "Only PLNTY=2, rest logic same").
- **R3 – Monthly Summary**: aggregates R1's output by Workcenter + Month, summing
  Capacity Utilization %.

## What changed vs. v1 / v2

See the report's header comment and `docs/assumptions.md` for the full
list of corrections (bulk data retrieval, routing-alternative/operation
matching via PLKO+PLPO, percentage scaling, running-hours timestamp
handling, GMEIN vs MEINS, authorization check). v3 additionally replaces
the two guessed DDIC structures with the real ones confirmed via SE11:
`ZPP_WORK_CENTER` (with `LOEKZ = 'X'` as the exclusion signal) instead of
the non-existent `ZPP_WORKCENTER_EXCLUDE`, and `AFRU-ZZRQUAN1..6`
instead of the non-existent `AFRU-ZZQUAN1..6`. The FS mapping itself is
unchanged — only the underlying source fields/tables were corrected.
