# Assumptions & Open Questions — WRICEF 166 (v6)

Almost everything from the original FS ambiguity list has now been resolved
by business confirmation or real DDIC lookups. What's left below still
needs sign-off from your security/Basis team before this program is
transported beyond a dev/unit-test client.

## Resolved by business confirmation / real DDIC (v3–v6)

- **STD QTY formula** — confirmed as the FS's literal 3-line text:
  `val1 = BMSCH/VGE04`, `val2 = Order Qty × VGE04/BMSCH`,
  `STD QTY = val1 × val2`. Implemented exactly this way. Algebraically this
  always equals Order Qty whenever `BMSCH`/`VGE04` resolve and are nonzero
  (and comes out to 0 when the routing/operation lookup fails) — that's
  confirmed as intended, not something to silently "fix".
- **Breakdown time (`AFRU-ISERH`) unit** — no longer a hardcoded `/60`
  assuming minutes. `ISERH` is now converted to hours using its own unit
  field `AFRU-ZEIER` (data element `DZEIER`) via the standard function
  module `UNIT_CONVERSION_SIMPLE` (converting to `'STD'` = hours). This is
  correct regardless of what unit a given confirmation's `ISERH` happens to
  be stored in. If `UNIT_CONVERSION_SIMPLE` can't resolve the unit (e.g. it's
  initial or not in T006), the code falls back to using `ISERH` as-is
  (treated as already hours) rather than silently showing zero.
- **Order dates** — confirmed as the FS states them literally:
  `Order Start Date = AFKO-GLTRP`, `Order End Date = AFKO-GSTRP`. (Note this
  is the reverse of SAP's usual GSTRP=start/GLTRP=finish convention, but
  that's confirmed as the intended mapping here, not an error to correct.)
- **Workcenter exclusion** uses the real table `ZPP_WORK_CENTER` (there is
  no `ZPP_WORKCENTER_EXCLUDE` in this system). It's keyed by `WERKS`+`ARBPL`
  but its purpose is linking a workcenter to a fixed asset (`VERWE`,
  `ANLN1`, `ZANLN`) — it has no dedicated "exclude" flag. A workcenter is
  excluded when `ZPP_WORK_CENTER-LOEKZ = 'X'` (the standard deletion/
  blocked indicator), per confirmation — not merely by having a row there.
- **Rejected Qty** sums `AFRU-ZZRQUAN1..ZZRQUAN6` ("Reusable Scrap Quantity
  1-6"), confirmed as the real append fields. `AFRU-ZZQUAN1..6` do not
  exist. (AFRU also carries `ZZMQUAN1..ZZMQUAN6`/`ZZMACH1..6`/`ZZREASON` —
  a per-reason-code machine-stoppage-time detail — which isn't used here
  since the FS's BREAKDOWN TIME column only asks for the single `ISERH`
  value; available if a future enhancement wants a stoppage-reason
  breakdown instead of/in addition to the single total.)
- **R3 (Monthly Summary) granularity** — resolved: the FS's Detailed-FS
  instruction for R3 ("Show workcenter wise Cumulative sum of Capacity
  utilization") doesn't mention a month bucket at all; "Monthly Summary" is
  only the radio button's label. R3 is a straight per-workcenter
  (`WERKS`+`ARBPL`) cumulative sum of Capacity Utilization % across
  whatever date range is selected — no time-period bucketing.

## Resolved in v2 (code-level fixes, no external confirmation needed)

- BMSCH/VGE04 resolved via `PLKO` (translating `CAUFV-PLNAL` to the
  internal group counter `ZAEHL`) + `PLPO` filtered by that counter and
  `AFRU-VORNR`, so the value used is tied to the correct routing
  alternative and the confirmed operation (v1's BAPI call never passed
  `VORNR`).
- MANHOURS no longer depends on the routing lookup succeeding.
- A%, Q%, P%, OEE%, and Capacity Utilization % are on a 0-100 scale (v1
  stored raw 0-1 ratios with no `*100`).
- RUNNING HRS combines `ISDD+ISDZ` / `IEDD+IEDZ` into timestamps before
  subtracting, so a confirmation spanning midnight doesn't go negative.
- Added `AFRU-ISDD` / `AFRU-IEDD` as their own Start Date / End Date
  columns (the FS lists these separately from Start/End Time).
- UOM sourced from `AFRU-GMEIN` — standard AFRU does not carry a `MEINS`
  field; `GMEIN` is the field tied to `GMNGA`.
- Data retrieval is bulk (`FOR ALL ENTRIES`) instead of one `SELECT
  SINGLE` (and one BAPI call) per confirmation line.

## Still open

1. **Text elements** (001 "Selection Criteria", 002 "Report Type") must be
   maintained in SE38 before activation — placeholder names only in source.

2. **Plant AUTHORITY-CHECK.** No `AUTHORITY-CHECK` is implemented at all —
   it was removed rather than shipped with a guessed object, since
   `M_MATE_WRK` (used in an earlier draft) is a material-master object and
   only loosely fit a confirmation/production-order report. The FS marks
   Plant as a mandatory authorization object, so before transport: confirm
   the correct object with your security team (check for an existing
   custom `Z` auth object used by other PP Z-reports first; failing that,
   run an authorization trace — `STAUTHTRACE`/`ST01` — against a
   comparable standard transaction like `CO11N`/`COOIS` restricted by
   plant, or check SU24 for those transactions' assigned objects), then
   add an `AUTHORITY-CHECK` in `AT SELECTION-SCREEN`.

3. **Not yet syntax-checked or unit-tested against a live system.** Run
   SE38 syntax check / ATC before transporting beyond a dev/unit-test
   client. In particular:
   - Verify `AFRU-ZEIER` exists under that name in your system, and that
     `UNIT_CONVERSION_SIMPLE`'s exception handling behaves as expected
     against real T006/ZEIER values.
   - This is a code review / correction pass, not a substitute for testing
     against real confirmation data.
