# Assumptions & Open Questions — WRICEF 166 (v3)

Most items from v1 have been resolved in code, and v3 replaces the two
guessed DDIC structures with the real ones confirmed via SE11
screenshots. What's left below still needs sign-off from the functional
consultant / your security and Basis teams before this program is
transported beyond a dev/unit-test client.

## Resolved in v3 - confirmed against real DDIC (SE11)

- **Workcenter exclusion** now uses the real table `ZPP_WORK_CENTER`
  (there is no `ZPP_WORKCENTER_EXCLUDE` in this system). It's keyed by
  `WERKS`+`ARBPL` but its purpose is linking a workcenter to a fixed
  asset (`VERWE`, `ANLN1`, `ZANLN`) — it has no dedicated "exclude"
  flag. **Per your confirmation, a workcenter is excluded when
  `ZPP_WORK_CENTER-LOEKZ = 'X'`** (the standard deletion/blocked
  indicator), not merely by having a row in the table — using mere
  existence would likely have excluded most/all workcenters, since
  every workcenter with an asset link would have a row here.
- **Rejected Qty** now sums `AFRU-ZZRQUAN1..ZZRQUAN6` ("Reusable Scrap
  Quantity 1-6"), confirmed as the real append fields on this system's
  AFRU. The originally assumed `AFRU-ZZQUAN1..6` do not exist.

## Resolved in v2 (see the report's header comment for detail)
- BMSCH/VGE04 are now resolved via `PLKO` (to translate `CAUFV-PLNAL`
  into the internal group counter `ZAEHL`) + `PLPO` filtered by that
  counter and `AFRU-VORNR`, so the value used is tied to the correct
  routing alternative and the confirmed operation. v1's BAPI call never
  passed `VORNR`.
- MANHOURS no longer depends on the routing lookup succeeding.
- A%, Q%, P%, OEE%, and Capacity Utilization % are now on a 0-100 scale
  (v1 stored raw 0-1 ratios with no `*100`).
- RUNNING HRS now combines `ISDD+ISDZ` / `IEDD+IEDZ` into timestamps
  before subtracting, so a confirmation spanning midnight no longer
  produces a negative value.
- Added `AFRU-ISDD` / `AFRU-IEDD` as their own Start Date / End Date
  columns (the FS lists these separately from Start/End Time; v1 only
  had the time columns).
- UOM now sourced from `AFRU-GMEIN` — standard AFRU does not carry a
  `MEINS` field; `GMEIN` is the field tied to `GMNGA`. **Verify this
  against your system's DDIC** in case a custom append adds `MEINS`.
- Data retrieval is now bulk (`FOR ALL ENTRIES`) instead of one
  `SELECT SINGLE` (and one BAPI call) per confirmation line.
- Added an `AUTHORITY-CHECK` on Plant. **Confirm the correct
  authorization object with your security team** - `M_MATE_WRK` /
  `ACTVT 03` is a placeholder, not a confirmed requirement.

## Still open

1. **STD QTY formula ambiguity.** The FS states two derivations and says
   to multiply them:
   - `val1 = BMSCH / VGE04`
   - `val2 = Order Qty × VGE04 / BMSCH`
   - `STD QTY = val1 × val2`

   Algebraically, `val1 × val2` simplifies to `Order Qty` regardless of
   the routing values, which suggests the FS intends something else
   (perhaps `val1 × Order Qty`, i.e. the standard rate applied to the
   order quantity). Implemented literally in the code, with a comment
   at the point of calculation. **Please confirm intended formula
   before go-live** — this is a business-logic decision, not something
   that should be silently "corrected" in code.

2. ~~ZPP_WORKCENTER_EXCLUDE structure~~ — **Resolved in v3**: real table
   is `ZPP_WORK_CENTER`, exclusion driven by `LOEKZ = 'X'`. See above.

3. ~~AFRU-ZZQUAN1 through ZZQUAN6~~ — **Resolved in v3**: real fields are
   `ZZRQUAN1..ZZRQUAN6`. See above. Note: AFRU also carries
   `ZZMQUAN1..ZZMQUAN6` ("Time in Min 1-6") paired with `ZZMACH1..6`
   ("Machine Stoppage Reason Code 1-6") and a free-text `ZZREASON`
   ("Reason For Machine Stoppage") — a per-reason-code breakdown-time
   detail. The FS's BREAKDOWN TIME column only asks for the single
   `AFRU-ISERH` value, so these aren't used here, but they exist if a
   future enhancement wants breakdown time broken out by stoppage
   reason instead of (or in addition to) the single ISERH total.

4. **Breakdown time unit.** FS says "Break time when user enter in CO11N"
   for `BREAKDOWN TIME`, mapped to `AFRU-ISERH`. Divided by 60 here
   assuming `ISERH` is stored in minutes; confirm the actual unit in
   your system (some configurations store it in seconds).

5. **Monthly Summary (R3) granularity.** The FS only says "Show
   workcenter wise cumulative sum of Capacity utilization" without
   specifying the time bucket. Implemented as calendar month (`YYYYMM`
   from confirmation date) — confirm this matches the intended "Monthly
   summary" behavior.

6. **Order dates.** FS lists `Order Start date` = `AFKO-GLTRP` and
   `Order end Date` = `AFKO-GSTRP`. Note these are basic-start/basic-finish
   fields in AFKO; naming in the FS ("start"/"end") is reversed relative to
   SAP's usual GSTRP=start / GLTRP=finish convention — mapped literally per
   the FS text, please double check against your actual requirement.

7. **Text elements** (001 "Selection Criteria", 002 "Report Type") must be
   maintained in SE38 before activation — placeholder names only in source.

8. **Not yet syntax-checked or unit-tested against a live system.** Run
   SE38 syntax check / ATC, and verify every assumed field name (in
   particular the ones flagged above) against your system's DDIC before
   transporting beyond a dev/unit-test client. This is a code review /
   correction pass, not a substitute for testing against real data.
