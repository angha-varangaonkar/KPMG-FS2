*&---------------------------------------------------------------------*
*& Report ZPP_OEE_ADHESIVE_REPORT
*&---------------------------------------------------------------------*
*& WRICEF ID  : 166
*& Object Name: Report for OEE in Adhesive
*& Module     : PP
*& Version    : 2 - corrected per code review, see docs/assumptions.md
*&
*& Purpose:
*&   Single selection-screen driven report offering three mutually
*&   exclusive output views (radio buttons), per the FS:
*&     R1 - Moulding Report            (all routing types)
*&     R2 - SFG and FG Production      (routing type PLNTY = '2' only)
*&     R3 - Monthly Summary            (workcenter-wise cumulative
*&                                      Capacity Utilization %)
*&
*& Version 2 changes vs. v1 (full detail in docs/assumptions.md):
*&   - Bulk (FOR ALL ENTRIES) data retrieval instead of SELECT SINGLE
*&     inside the confirmation LOOP - avoids one DB round-trip per
*&     confirmation line, which did not scale for a real date range.
*&   - Routing base qty / machine time (BMSCH/VGE04) now resolved via
*&     PLKO (CAUFV-PLNAL -> internal group counter ZAEHL) and PLPO
*&     filtered by that counter AND the confirmed operation
*&     (AFRU-VORNR). The FS says to pass PLNTY, PLNNR, PLNAL and
*&     VORNR - the v1 BAPI call never passed VORNR, so it risked
*&     reading the wrong operation's routing values.
*&   - MANHOURS ((ISM02+ISM04)/60) is no longer skipped when the
*&     routing lookup fails - it does not depend on routing data.
*&   - A% / Q% / P% / OEE% / CAPACITY UTILIZATION % are now expressed
*&     on a 0-100 scale to match their "%" column names (v1 stored
*&     raw 0-1 ratios with no *100).
*&   - RUNNING HRS now combines ISDD+ISDZ and IEDD+IEDZ into full
*&     timestamps before subtracting, so a confirmation that runs
*&     past midnight no longer produces a negative running time.
*&   - Added AFRU-ISDD / AFRU-IEDD as their own Start Date / End Date
*&     columns per the FS - v1 only carried Start/End TIME.
*&   - UOM is now sourced from AFRU-GMEIN. Standard AFRU does not
*&     have a MEINS field (v1 referenced AFRU-MEINS); GMEIN is the
*&     field that carries the unit for GMNGA. Verify against your
*&     system's DDIC if you have a custom append that adds MEINS.
*&   - Workcenter exclusion and rejected-qty logic now use the actual
*&     DDIC structures confirmed against your system (SE11):
*&       * ZPP_WORK_CENTER (not ZPP_WORKCENTER_EXCLUDE - that table
*&         doesn't exist; ZPP_WORK_CENTER is the real Z-table keyed
*&         by WERKS+ARBPL, used to link a workcenter to a fixed
*&         asset). It has no dedicated "exclude" flag, so a
*&         workcenter is treated as excluded when ZPP_WORK_CENTER-
*&         LOEKZ = 'X' (the standard SAP deletion/blocked indicator),
*&         per your confirmation - not merely by having a row there.
*&       * AFRU-ZZRQUAN1..ZZRQUAN6 ("Reusable Scrap Quantity 1-6") are
*&         the real rejected-qty append fields - not AFRU-ZZQUAN1..6,
*&         which don't exist on this system's AFRU.
*&   - No AUTHORITY-CHECK on Plant is implemented (removed pending
*&     confirmation of the correct object - see "Still open" below).
*&     The FS marks Plant as a mandatory authorization object; add the
*&     check once your security team confirms the object/field.
*&   - R3 (Monthly Summary) no longer buckets by calendar month. Per
*&     business confirmation, the FS's Detailed-FS instruction for R3
*&     ("Show workcenter wise Cumulative sum of Capacity utilization")
*&     doesn't mention a month bucket at all - "Monthly Summary" is
*&     only the radio button's label. R3 is now a straight per-
*&     workcenter (WERKS+ARBPL) cumulative sum of Capacity
*&     Utilization % across whatever date range is selected.
*&   - STD QTY formula CONFIRMED by business as the FS's literal 3-line
*&     text: val1 = BMSCH/VGE04, val2 = OrderQty*VGE04/BMSCH,
*&     STD QTY = val1*val2. This is unchanged from earlier versions -
*&     algebraically it always equals Order Qty when BMSCH/VGE04 are
*&     both resolved and nonzero (and 0 when the routing lookup fails),
*&     which is intended, not a bug.
*&   - ISERH (breakdown time) is now converted to hours using its own
*&     unit field AFRU-ZEIER (data element DZEIER) via
*&     UNIT_CONVERSION_SIMPLE, instead of a hardcoded /60. This is
*&     correct regardless of whether ISERH happens to be stored in
*&     minutes, seconds, or hours for a given confirmation.
*&   - AFKO-GLTRP/GSTRP "start"/"end" naming CONFIRMED by business as
*&     the FS states it (order_start_date = GLTRP, order_end_date =
*&     GSTRP) - this is unchanged from earlier versions.
*&
*& Still open / needs functional consultant sign-off before go-live
*& (see docs/assumptions.md for the full writeup):
*&   - Plant AUTHORITY-CHECK - not implemented; the FS requires it but
*&     the correct auth object/field depends on your authorization
*&     concept. Confirm via SU21/SU24/STAUTHTRACE with your security
*&     team, then add an AUTHORITY-CHECK in AT SELECTION-SCREEN.
*&   - This has not been syntax-checked or unit-tested against a live
*&     system. Run SE38 syntax check / ATC and test against real data
*&     before transporting beyond a dev/unit-test client. UNIT_CONVERSION_
*&     SIMPLE's exception handling in particular should be verified
*&     against real T006/ZEIER values in your system.
*&---------------------------------------------------------------------*
REPORT zpp_oee_adhesive_report.

*&---------------------------------------------------------------------*
*& Tables used (per FS "Selection parameters" table) - needed so the
*& SELECT-OPTIONS below can reference DDIC fields directly.
*&---------------------------------------------------------------------*
TABLES: afru, caufv, afpo, mara, makt.

*&---------------------------------------------------------------------*
*& Output structure - one line per Confirmation (AFRU-ERSDA/RUECK/RMZHL)
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_output,
         werks            TYPE afru-werks,           "Plant Code
         datum            TYPE afru-ersda,           "Confirmation entry date
         matnr            TYPE mara-matnr,           "Material Code
         maktx            TYPE makt-maktx,           "Description
         arbpl            TYPE crhd-arbpl,           "Workcentre Name
         ktext            TYPE crtx-ktext,           "Workcenter Description
         aufnr            TYPE afru-aufnr,           "Production Order
         auart            TYPE caufv-auart,          "Order Type
         matkl            TYPE mara-matkl,           "Material Group
         ntgew            TYPE mara-ntgew,           "Net Weight
         gamng            TYPE caufv-gamng,          "Order Qty
         gmnga            TYPE afru-gmnga,           "Confirm Qty
         meins            TYPE afru-gmein,           "UOM (AFRU-GMEIN, see header note)
         tot_tonnage      TYPE p LENGTH 13 DECIMALS 3, "Total Tonnage
         std_qty          TYPE p LENGTH 13 DECIMALS 3, "Std Qty
         manhours         TYPE p LENGTH 13 DECIMALS 3, "Manhours
         start_date       TYPE afru-isdd,            "Start Date
         end_date         TYPE afru-iedd,            "End Date
         start_time       TYPE afru-isdz,            "Start Time
         end_time         TYPE afru-iedz,            "End Time
         running_hrs      TYPE p LENGTH 9 DECIMALS 4,  "Running Hrs
         a_pct            TYPE p LENGTH 7 DECIMALS 2,  "Availability %
         q_pct            TYPE p LENGTH 7 DECIMALS 2,  "Quality %
         p_pct            TYPE p LENGTH 7 DECIMALS 2,  "Performance %
         oee_pct          TYPE p LENGTH 7 DECIMALS 2,  "OEE %
         rejected_qty     TYPE p LENGTH 13 DECIMALS 3, "Rejected Qty
         breakdown_time   TYPE p LENGTH 9 DECIMALS 4,  "Breakdown Time (hrs)
         cap_util_pct     TYPE p LENGTH 7 DECIMALS 2,  "Capacity Utilization %
         verid            TYPE afpo-verid,          "Production Version
         stlal            TYPE caufv-stlal,         "Alternative BOM
         order_start_date TYPE afko-gltrp,          "Order Start Date
         order_end_date   TYPE afko-gstrp,           "Order End Date
         vornr            TYPE afru-vornr,          "Phase / Operation
         cancelled        TYPE afru-stzhl,          "Cancelled
         reversed         TYPE afru-stokz,          "Reversed
         rueck            TYPE afru-rueck,          "Confirmation Number
         rmzhl            TYPE afru-rmzhl,          "Confirmation Counter
         setup_machine    TYPE afru-ism02,          "Setup Machine (confirmed)
         std_manhours     TYPE p LENGTH 13 DECIMALS 3, "Std Man Hours
       END OF ty_output.

DATA: gt_output TYPE STANDARD TABLE OF ty_output,
      gs_output TYPE ty_output.

DATA: BEGIN OF gs_monthly,
        werks        TYPE afru-werks,
        arbpl        TYPE crhd-arbpl,
        ktext        TYPE crtx-ktext,
        cap_util_sum TYPE p LENGTH 9 DECIMALS 4,
      END OF gs_monthly.

DATA: gt_monthly_summary LIKE STANDARD TABLE OF gs_monthly.

*&---------------------------------------------------------------------*
*& Selection Screen (per FS "Selection Screen" block)
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

SELECT-OPTIONS: s_werks FOR afru-werks OBLIGATORY,   "Plant Code - MANDATORY
                s_matnr FOR mara-matnr,               "Material Code - range
                s_datum FOR afru-ersda OBLIGATORY,    "Date - MANDATORY
                s_arbpl FOR afru-arbpl.               "Workcenter

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.

PARAMETERS: p_r1 RADIOBUTTON GROUP rb1 DEFAULT 'X' USER-COMMAND rbc, "Moulding Report
            p_r2 RADIOBUTTON GROUP rb1,                              "SFG and FG Production
            p_r3 RADIOBUTTON GROUP rb1.                              "Monthly Summary

SELECTION-SCREEN END OF BLOCK b2.

*&---------------------------------------------------------------------*
*& Text symbols (maintain via SE38 Goto > Text Elements):
*&   001 Selection Criteria
*&   002 Report Type
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& AT SELECTION-SCREEN
*&---------------------------------------------------------------------*
*& S_WERKS and S_DATUM are already declared OBLIGATORY on the
*& SELECT-OPTIONS statements, so the standard selection-screen
*& framework already blocks execution and shows its own "Enter a
*& value" error if either is left empty - no need to re-check
*& IS INITIAL here as well.
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN.

* No AUTHORITY-CHECK on Plant is implemented here. The FS marks Plant
* as a mandatory authorization object, but the correct object/field to
* check depends on your system's authorization concept - confirm it
* with your security team (see docs/assumptions.md) and add an
* AUTHORITY-CHECK in this event block before transport.

*&---------------------------------------------------------------------*
*& START-OF-SELECTION
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  CASE 'X'.
    WHEN p_r1.
      PERFORM build_production_data USING space. "all routing types
    WHEN p_r2.
      PERFORM build_production_data USING '2'.   "PLNTY = '2' only (FS: SFG/FG)
    WHEN p_r3.
      PERFORM build_production_data USING space.
      PERFORM build_monthly_summary.
  ENDCASE.

*&---------------------------------------------------------------------*
*& END-OF-SELECTION - render ALV
*&---------------------------------------------------------------------*
END-OF-SELECTION.

  IF p_r3 = 'X'.
    PERFORM display_alv_monthly.
  ELSE.
    PERFORM display_alv_detail.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  BUILD_PRODUCTION_DATA
*&---------------------------------------------------------------------*
*&  Core extraction & derivation logic, per FS "Detailed FS" tab.
*&  IV_PLNTY_FILTER = '2' restricts routing type for the SFG/FG view
*&  (Radio Button 2); blank = no restriction (Moulding view / Radio 1).
*&
*&  Bulk-select pattern: read AFRU once for the whole selection, then
*&  pull every dependent table with FOR ALL ENTRIES and resolve each
*&  confirmation line via sorted internal tables + BINARY SEARCH,
*&  instead of one SELECT SINGLE per confirmation (v1's approach).
*&---------------------------------------------------------------------*
FORM build_production_data USING iv_plnty_filter TYPE plnty.

  TYPES:
    BEGIN OF ty_afru,
      werks   TYPE afru-werks,
      ersda   TYPE afru-ersda,
      aufnr   TYPE afru-aufnr,
      arbid   TYPE afru-arbid,
      rueck   TYPE afru-rueck,
      rmzhl   TYPE afru-rmzhl,
      vornr   TYPE afru-vornr,
      gmnga   TYPE afru-gmnga,
      gmein   TYPE afru-gmein,
      ism02   TYPE afru-ism02,
      ism04   TYPE afru-ism04,
      isdd    TYPE afru-isdd,
      iedd    TYPE afru-iedd,
      isdz    TYPE afru-isdz,
      iedz    TYPE afru-iedz,
      iserh   TYPE afru-iserh,
      zeier   TYPE afru-zeier,     "Unit for ISERH (data element DZEIER)
      zzrquan1 TYPE afru-zzrquan1,
      zzrquan2 TYPE afru-zzrquan2,
      zzrquan3 TYPE afru-zzrquan3,
      zzrquan4 TYPE afru-zzrquan4,
      zzrquan5 TYPE afru-zzrquan5,
      zzrquan6 TYPE afru-zzrquan6,
      stzhl   TYPE afru-stzhl,
      stokz   TYPE afru-stokz,
    END OF ty_afru,

    BEGIN OF ty_caufv,
      aufnr  TYPE caufv-aufnr,
      plnbez TYPE caufv-plnbez,
      gamng  TYPE caufv-gamng,
      auart  TYPE caufv-auart,
      plnty  TYPE caufv-plnty,
      plnnr  TYPE caufv-plnnr,
      plnal  TYPE caufv-plnal,
      stlal  TYPE caufv-stlal,
    END OF ty_caufv,

    BEGIN OF ty_crhd,
      objid TYPE crhd-objid,
      arbpl TYPE crhd-arbpl,
      werks TYPE crhd-werks,
    END OF ty_crhd,

    BEGIN OF ty_excl,
      werks TYPE zpp_work_center-werks,
      arbpl TYPE zpp_work_center-arbpl,
    END OF ty_excl,

    BEGIN OF ty_crtx,
      objid TYPE crtx-objid,
      ktext TYPE crtx-ktext,
    END OF ty_crtx,

    BEGIN OF ty_mara,
      matnr TYPE mara-matnr,
      matkl TYPE mara-matkl,
      ntgew TYPE mara-ntgew,
    END OF ty_mara,

    BEGIN OF ty_makt,
      matnr TYPE makt-matnr,
      maktx TYPE makt-maktx,
    END OF ty_makt,

    BEGIN OF ty_afpo,
      aufnr TYPE afpo-aufnr,
      verid TYPE afpo-verid,
    END OF ty_afpo,

    BEGIN OF ty_afko,
      aufnr TYPE afko-aufnr,
      gstrp TYPE afko-gstrp,
      gltrp TYPE afko-gltrp,
    END OF ty_afko,

    BEGIN OF ty_plko,
      plnty TYPE plko-plnty,
      plnnr TYPE plko-plnnr,
      plnal TYPE plko-plnal,
      zaehl TYPE plko-zaehl,
    END OF ty_plko,

    BEGIN OF ty_plpo,
      plnty TYPE plpo-plnty,
      plnnr TYPE plpo-plnnr,
      zaehl TYPE plpo-zaehl,
      vornr TYPE plpo-vornr,
      bmsch TYPE plpo-bmsch,
      vge04 TYPE plpo-vge04,
    END OF ty_plpo.

  DATA: lt_afru  TYPE STANDARD TABLE OF ty_afru,
        lt_caufv TYPE STANDARD TABLE OF ty_caufv,
        lt_crhd  TYPE STANDARD TABLE OF ty_crhd,
        lt_excl  TYPE STANDARD TABLE OF ty_excl,
        lt_crtx  TYPE STANDARD TABLE OF ty_crtx,
        lt_mara  TYPE STANDARD TABLE OF ty_mara,
        lt_makt  TYPE STANDARD TABLE OF ty_makt,
        lt_afpo  TYPE STANDARD TABLE OF ty_afpo,
        lt_afko  TYPE STANDARD TABLE OF ty_afko,
        lt_plko  TYPE STANDARD TABLE OF ty_plko,
        lt_plpo  TYPE STANDARD TABLE OF ty_plpo.

  DATA: ls_afru  TYPE ty_afru,
        ls_caufv TYPE ty_caufv,
        ls_crhd  TYPE ty_crhd,
        ls_crtx  TYPE ty_crtx,
        ls_mara  TYPE ty_mara,
        ls_makt  TYPE ty_makt,
        ls_afpo  TYPE ty_afpo,
        ls_afko  TYPE ty_afko,
        ls_plko  TYPE ty_plko,
        ls_plpo  TYPE ty_plpo.

  DATA: lv_a_ratio  TYPE p LENGTH 13 DECIMALS 6,
        lv_q_ratio  TYPE p LENGTH 13 DECIMALS 6,
        lv_p_ratio  TYPE p LENGTH 13 DECIMALS 6,
        lv_val1     TYPE p LENGTH 13 DECIMALS 6,
        lv_val2     TYPE p LENGTH 13 DECIMALS 6,
        lv_start_ts TYPE timestamp,
        lv_end_ts   TYPE timestamp,
        lv_seconds  TYPE p LENGTH 8 DECIMALS 0,
        lv_excluded TYPE abap_bool,
        lv_iserh_hrs TYPE p LENGTH 9 DECIMALS 4.

  REFRESH gt_output.

* Step 1/2: Plant + Date from selection screen against AFRU-WERKS / ERSDA
  SELECT werks ersda aufnr arbid rueck rmzhl vornr gmnga gmein
         ism02 ism04 isdd iedd isdz iedz iserh zeier
         zzrquan1 zzrquan2 zzrquan3 zzrquan4 zzrquan5 zzrquan6
         stzhl stokz
    FROM afru
    INTO CORRESPONDING FIELDS OF TABLE lt_afru
    WHERE werks IN s_werks
      AND ersda IN s_datum
      AND arbpl IN s_arbpl.

  IF lt_afru IS INITIAL.
    MESSAGE 'No data found' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  SELECT aufnr plnbez gamng auart plnty plnnr plnal stlal
    FROM caufv
    INTO CORRESPONDING FIELDS OF TABLE lt_caufv
    FOR ALL ENTRIES IN lt_afru
    WHERE aufnr = lt_afru-aufnr.

  IF iv_plnty_filter IS NOT INITIAL.
    DELETE lt_caufv WHERE plnty <> iv_plnty_filter.
  ENDIF.

  IF s_matnr[] IS NOT INITIAL.
    DELETE lt_caufv WHERE plnbez NOT IN s_matnr.
  ENDIF.

  IF lt_caufv IS INITIAL.
    MESSAGE 'No production orders found for the selection.' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  SELECT objid arbpl werks
    FROM crhd
    INTO CORRESPONDING FIELDS OF TABLE lt_crhd
    FOR ALL ENTRIES IN lt_afru
    WHERE objid = lt_afru-arbid.

* --- Workcenter exclusion (FS seq 4): ZPP_WORK_CENTER is keyed by
*     WERKS + ARBPL (confirmed via SE11) but has no dedicated
*     "exclude" flag - it links a workcenter to a fixed asset
*     (VERWE/ANLN1/ZANLN). Per business confirmation, a workcenter is
*     treated as excluded when its ZPP_WORK_CENTER-LOEKZ (deletion/
*     blocked indicator) = 'X', not merely by having a row here. ---
  IF lt_crhd IS NOT INITIAL.
    SELECT werks arbpl
      FROM zpp_work_center
      INTO CORRESPONDING FIELDS OF TABLE lt_excl
      FOR ALL ENTRIES IN lt_crhd
      WHERE werks = lt_crhd-werks
        AND arbpl = lt_crhd-arbpl
        AND loekz = 'X'.
  ENDIF.

  SELECT objid ktext
    FROM crtx
    INTO CORRESPONDING FIELDS OF TABLE lt_crtx
    FOR ALL ENTRIES IN lt_crhd
    WHERE objid = lt_crhd-objid
      AND spras = sy-langu.

  SELECT matnr matkl ntgew
    FROM mara
    INTO CORRESPONDING FIELDS OF TABLE lt_mara
    FOR ALL ENTRIES IN lt_caufv
    WHERE matnr = lt_caufv-plnbez.

  SELECT matnr maktx
    FROM makt
    INTO CORRESPONDING FIELDS OF TABLE lt_makt
    FOR ALL ENTRIES IN lt_caufv
    WHERE matnr = lt_caufv-plnbez
      AND spras = sy-langu.

  SELECT aufnr verid
    FROM afpo
    INTO CORRESPONDING FIELDS OF TABLE lt_afpo
    FOR ALL ENTRIES IN lt_caufv
    WHERE aufnr = lt_caufv-aufnr.

  SELECT aufnr gstrp gltrp
    FROM afko
    INTO CORRESPONDING FIELDS OF TABLE lt_afko
    FOR ALL ENTRIES IN lt_caufv
    WHERE aufnr = lt_caufv-aufnr.

* --- Routing base qty (BMSCH) / machine time (VGE04): the FS says to
*     pass PLNTY, PLNNR, PLNAL and VORNR. PLNAL is not itself a field
*     on PLPO, so resolve it to PLKO's internal group counter (ZAEHL)
*     first, then read PLPO by that counter AND the confirmed
*     operation (AFRU-VORNR). This is what v1's BAPI call omitted
*     (no VORNR passed), risking the wrong operation's values. ---
  SELECT plnty plnnr plnal zaehl
    FROM plko
    INTO CORRESPONDING FIELDS OF TABLE lt_plko
    FOR ALL ENTRIES IN lt_caufv
    WHERE plnty = lt_caufv-plnty
      AND plnnr = lt_caufv-plnnr
      AND plnal = lt_caufv-plnal.

  IF lt_plko IS NOT INITIAL.
    SELECT plnty plnnr zaehl vornr bmsch vge04
      FROM plpo
      INTO CORRESPONDING FIELDS OF TABLE lt_plpo
      FOR ALL ENTRIES IN lt_plko
      WHERE plnty = lt_plko-plnty
        AND plnnr = lt_plko-plnnr
        AND zaehl = lt_plko-zaehl.
  ENDIF.

  SORT lt_caufv BY aufnr.
  SORT lt_crhd  BY objid.
  SORT lt_crtx  BY objid.
  SORT lt_mara  BY matnr.
  SORT lt_makt  BY matnr.
  SORT lt_afpo  BY aufnr.
  SORT lt_afko  BY aufnr.
  SORT lt_plko  BY plnty plnnr plnal.
  SORT lt_plpo  BY plnty plnnr zaehl vornr.

  LOOP AT lt_afru INTO ls_afru.

    CLEAR: gs_output, ls_crhd, ls_crtx, ls_caufv, ls_mara, ls_makt,
           ls_afpo, ls_afko, ls_plko, ls_plpo,
           lv_a_ratio, lv_q_ratio, lv_p_ratio, lv_val1, lv_val2.

    READ TABLE lt_crhd INTO ls_crhd WITH KEY objid = ls_afru-arbid BINARY SEARCH.

*   --- Exclude workcenters where ZPP_WORK_CENTER-LOEKZ = 'X' ---
    lv_excluded = abap_false.
    READ TABLE lt_excl TRANSPORTING NO FIELDS
      WITH KEY werks = ls_crhd-werks
               arbpl = ls_crhd-arbpl.
    IF sy-subrc = 0.
      lv_excluded = abap_true.
    ENDIF.
    IF lv_excluded = abap_true.
      CONTINUE.
    ENDIF.

*   --- Order header (CAUFV) via AFRU-AUFNR); also applies the
*       Radio Button 2 (PLNTY filter) / material-range exclusions
*       already applied to lt_caufv above ---
    READ TABLE lt_caufv INTO ls_caufv WITH KEY aufnr = ls_afru-aufnr BINARY SEARCH.
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

    READ TABLE lt_mara INTO ls_mara WITH KEY matnr = ls_caufv-plnbez BINARY SEARCH.
    READ TABLE lt_makt INTO ls_makt WITH KEY matnr = ls_caufv-plnbez BINARY SEARCH.
    READ TABLE lt_crtx INTO ls_crtx WITH KEY objid = ls_crhd-objid BINARY SEARCH.
    READ TABLE lt_afpo INTO ls_afpo WITH KEY aufnr = ls_caufv-aufnr BINARY SEARCH.
    READ TABLE lt_afko INTO ls_afko WITH KEY aufnr = ls_caufv-aufnr BINARY SEARCH.

*   --- Header fields ---
    gs_output-werks            = ls_afru-werks.
    gs_output-datum            = ls_afru-ersda.
    gs_output-matnr            = ls_caufv-plnbez.
    gs_output-maktx            = ls_makt-maktx.
    gs_output-arbpl            = ls_crhd-arbpl.
    gs_output-ktext            = ls_crtx-ktext.
    gs_output-aufnr            = ls_afru-aufnr.
    gs_output-auart            = ls_caufv-auart.
    gs_output-matkl            = ls_mara-matkl.
    gs_output-ntgew            = ls_mara-ntgew.
    gs_output-gamng            = ls_caufv-gamng.
    gs_output-gmnga            = ls_afru-gmnga.
    gs_output-meins            = ls_afru-gmein.
    gs_output-verid            = ls_afpo-verid.
    gs_output-stlal            = ls_caufv-stlal.
    gs_output-order_start_date = ls_afko-gltrp.
    gs_output-order_end_date   = ls_afko-gstrp.
    gs_output-vornr            = ls_afru-vornr.
    gs_output-cancelled        = ls_afru-stzhl.
    gs_output-reversed         = ls_afru-stokz.
    gs_output-rueck            = ls_afru-rueck.
    gs_output-rmzhl            = ls_afru-rmzhl.
    gs_output-setup_machine    = ls_afru-ism02.
    gs_output-start_date       = ls_afru-isdd.
    gs_output-end_date         = ls_afru-iedd.
    gs_output-start_time       = ls_afru-isdz.
    gs_output-end_time         = ls_afru-iedz.

*   --- Total tonnage = Confirmed Qty * Net Weight / 1000 (per FS) ---
    gs_output-tot_tonnage = ( gs_output-gmnga * gs_output-ntgew ) / 1000.

*   --- Running hours: combine date+time so a confirmation that runs
*       past midnight doesn't produce a negative duration ---
    CLEAR: lv_start_ts, lv_end_ts, lv_seconds.
    IF ls_afru-isdd IS NOT INITIAL AND ls_afru-iedd IS NOT INITIAL.
      CONVERT DATE ls_afru-isdd TIME ls_afru-isdz
        INTO TIME STAMP lv_start_ts TIME ZONE sy-zonlo.
      CONVERT DATE ls_afru-iedd TIME ls_afru-iedz
        INTO TIME STAMP lv_end_ts TIME ZONE sy-zonlo.
      TRY.
          cl_abap_tstmp=>subtract(
            EXPORTING tstmp1   = lv_end_ts
                      tstmp2   = lv_start_ts
            IMPORTING rseconds = lv_seconds ).
        CATCH cx_root.
          lv_seconds = 0.
      ENDTRY.
      gs_output-running_hrs = lv_seconds / 3600.
    ENDIF.

*   --- Manhours = (ISM02 + ISM04) / 60 - independent of routing data,
*       so it is calculated regardless of whether BMSCH/VGE04 resolve ---
    gs_output-manhours = ( ls_afru-ism02 + ls_afru-ism04 ) / 60.

*   --- Rejected Qty = sum of AFRU-ZZRQUAN1..ZZRQUAN6 (Reusable Scrap
*       Quantity 1-6) ---
    gs_output-rejected_qty = ls_afru-zzrquan1 + ls_afru-zzrquan2
                            + ls_afru-zzrquan3 + ls_afru-zzrquan4
                            + ls_afru-zzrquan5 + ls_afru-zzrquan6.

*   --- Breakdown time = AFRU-ISERH, converted to hours using its own
*       unit field AFRU-ZEIER (data element DZEIER) rather than a
*       hardcoded /60 - so this is correct regardless of whether a
*       given confirmation's ISERH happens to be stored in minutes,
*       seconds, or hours. ---
    CLEAR lv_iserh_hrs.
    CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
      EXPORTING
        input                = ls_afru-iserh
        unit_in              = ls_afru-zeier
        unit_out             = 'STD'
      IMPORTING
        output               = lv_iserh_hrs
      EXCEPTIONS
        conversion_not_found = 1
        division_by_zero     = 2
        input_invalid        = 3
        output_invalid       = 4
        overflow              = 5
        type_invalid          = 6
        units_missing         = 7
        unit_in_not_found     = 8
        unit_out_not_found    = 9
        OTHERS                = 10.

    IF sy-subrc = 0.
      gs_output-breakdown_time = lv_iserh_hrs.
    ELSE.
*     Unit missing/not found in T006 - fall back to the raw value
*     (treat as already hours) rather than silently show zero.
      gs_output-breakdown_time = ls_afru-iserh.
    ENDIF.

*   --- STD QTY / Std Man Hours / P%: need routing base qty (BMSCH)
*       and machine time (VGE04) for the confirmed operation ---
    READ TABLE lt_plko INTO ls_plko
      WITH KEY plnty = ls_caufv-plnty
               plnnr = ls_caufv-plnnr
               plnal = ls_caufv-plnal
      BINARY SEARCH.

    IF sy-subrc = 0.
      READ TABLE lt_plpo INTO ls_plpo
        WITH KEY plnty = ls_plko-plnty
                 plnnr = ls_plko-plnnr
                 zaehl = ls_plko-zaehl
                 vornr = ls_afru-vornr
        BINARY SEARCH.
    ENDIF.

    IF ls_plpo-vge04 <> 0 AND ls_plpo-bmsch <> 0.

*     FS logic (as literally stated) is two derivations multiplied
*     together - see docs/assumptions.md #1: algebraically this
*     always resolves to Order Qty regardless of the routing values.
*     Implemented literally pending confirmation from the functional
*     consultant.
      lv_val1 = ls_plpo-bmsch / ls_plpo-vge04.
      lv_val2 = ( gs_output-gamng * ls_plpo-vge04 ) / ls_plpo-bmsch.
      gs_output-std_qty = lv_val1 * lv_val2.

*     --- Std Man Hours = Order Qty * ISM04 / BMSCH ---
      gs_output-std_manhours = ( gs_output-gamng * ls_afru-ism04 ) / ls_plpo-bmsch.

*     --- P% = Actual PC/min / Std PC/min ---
*         Actual PC/min = Confirmed Qty / ISM04 (confirmed machine time)
*         Std PC/min    = BMSCH / VGE04
      IF ls_afru-ism04 <> 0.
        lv_p_ratio = ( gs_output-gmnga / ls_afru-ism04 ) / lv_val1.
        gs_output-p_pct = lv_p_ratio * 100.
      ENDIF.
    ENDIF.

*   --- A% = (Runtime - Breakdown) / Runtime ---
    IF gs_output-running_hrs <> 0.
      lv_a_ratio = ( gs_output-running_hrs - gs_output-breakdown_time )
                   / gs_output-running_hrs.
      gs_output-a_pct = lv_a_ratio * 100.
    ENDIF.

*   --- Q% = Confirmed Qty / (Confirmed Qty + Rejected Qty) ---
    IF ( gs_output-gmnga + gs_output-rejected_qty ) <> 0.
      lv_q_ratio = gs_output-gmnga / ( gs_output-gmnga + gs_output-rejected_qty ).
      gs_output-q_pct = lv_q_ratio * 100.
    ENDIF.

*   --- OEE% = A% * Q% * P% (computed on the underlying ratios, then
*       scaled to a percentage once, so it isn't off by a factor of
*       100^2) ---
    gs_output-oee_pct = lv_a_ratio * lv_q_ratio * lv_p_ratio * 100.

*   --- Capacity Utilization % = Confirmed Qty / Std Qty ---
    IF gs_output-std_qty <> 0.
      gs_output-cap_util_pct = ( gs_output-gmnga / gs_output-std_qty ) * 100.
    ENDIF.

    APPEND gs_output TO gt_output.

  ENDLOOP.

  IF gt_output IS INITIAL.
    MESSAGE 'No data found for the selection.' TYPE 'S' DISPLAY LIKE 'E'.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  BUILD_MONTHLY_SUMMARY
*&---------------------------------------------------------------------*
*&  Radio Button 3: per the FS's literal Detailed-FS instruction -
*&  "Show workcenter wise Cumulative sum of Capacity utilization" -
*&  this is a straight per-workcenter (WERKS+ARBPL) cumulative sum of
*&  Capacity Utilization % across whatever date range was selected on
*&  the screen. "Monthly Summary" is only the radio button's label;
*&  the detailed logic line doesn't mention a month bucket at all, so
*&  no time-period grouping is applied - confirmed per business
*&  clarification, see docs/assumptions.md point 5.
*&---------------------------------------------------------------------*
FORM build_monthly_summary.

  DATA: ls_summary LIKE LINE OF gt_monthly_summary.

  REFRESH gt_monthly_summary.

  LOOP AT gt_output INTO gs_output.

    READ TABLE gt_monthly_summary INTO ls_summary
      WITH KEY werks = gs_output-werks
               arbpl = gs_output-arbpl.

    IF sy-subrc = 0.
      ls_summary-cap_util_sum = ls_summary-cap_util_sum
                                 + gs_output-cap_util_pct.
      MODIFY gt_monthly_summary FROM ls_summary
        INDEX sy-tabix.
    ELSE.
      CLEAR ls_summary.
      ls_summary-werks        = gs_output-werks.
      ls_summary-arbpl        = gs_output-arbpl.
      ls_summary-ktext        = gs_output-ktext.
      ls_summary-cap_util_sum = gs_output-cap_util_pct.
      APPEND ls_summary TO gt_monthly_summary.
    ENDIF.

  ENDLOOP.

  SORT gt_monthly_summary BY werks arbpl.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV_DETAIL
*&---------------------------------------------------------------------*
FORM display_alv_detail.

  IF gt_output IS INITIAL.
    RETURN.
  ENDIF.

  DATA: lo_salv TYPE REF TO cl_salv_table.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_salv
        CHANGING  t_table      = gt_output ).

      lo_salv->get_functions( )->set_all( abap_true ).
      lo_salv->get_columns( )->set_optimize( abap_true ).
      lo_salv->display( ).

    CATCH cx_salv_msg.
      MESSAGE 'Error displaying ALV output' TYPE 'E'.
  ENDTRY.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV_MONTHLY
*&---------------------------------------------------------------------*
FORM display_alv_monthly.

  IF gt_monthly_summary IS INITIAL.
    RETURN.
  ENDIF.

  DATA: lo_salv TYPE REF TO cl_salv_table.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_salv
        CHANGING  t_table      = gt_monthly_summary ).

      lo_salv->get_functions( )->set_all( abap_true ).
      lo_salv->get_columns( )->set_optimize( abap_true ).
      lo_salv->display( ).

    CATCH cx_salv_msg.
      MESSAGE 'Error displaying ALV output' TYPE 'E'.
  ENDTRY.

ENDFORM.
