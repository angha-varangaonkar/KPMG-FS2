# WRICEF 166 – Overall Production Report (OEE in Adhesive)

ABAP implementation generated from the Functional Specification
`Copy of WRICEF ID 166-Overall production report for SFG FG and moulding sperately.xlsx`.

## Contents

- `zsrc/ZPP_OEE_ADHESIVE_REPORT.abap` – main report program (v2 - see header comment for what changed and why)
- `docs/field_mapping.md` – field-by-field source-to-target mapping, extracted from the "Detailed FS" tab
- `docs/assumptions.md` – remaining assumptions and open questions to confirm with the functional consultant before transport

## What the report does

Single selection screen with three mutually exclusive radio-button views:

1. **Moulding Report** – all confirmations, all routing types
2. **SFG and FG Production** – same logic, restricted to routing type `PLNTY = '2'`
3. **Monthly Summary** – workcenter-wise cumulative Capacity Utilization %

Selection fields: Plant (mandatory; no authorization check implemented yet - see
below), Material (range), Date (mandatory), Workcenter.

Key calculated fields: Total Tonnage, STD Qty, Manhours, Running Hours, A% / Q% / P%,
OEE% (`A% × Q% × P%`), Rejected Qty, Breakdown Time, Capacity Utilization %, Std Man Hours.

## v2-v9 changes (code review fixes)

This version corrects issues found reviewing v1 against the FS: bulk
(`FOR ALL ENTRIES`) data retrieval instead of a `SELECT SINGLE`/BAPI call
per confirmation line; routing base qty/machine time (`BMSCH`/`VGE04`) resolved
via `PLKO`+`PLPO` so the correct routing alternative *and* operation are used;
Manhours no longer skipped when the routing lookup fails; percentages expressed
on a 0-100 scale; Running Hours computed from full date+time timestamps so
overnight confirmations don't go negative; Start Date/End Date columns added;
UOM sourced from the field that actually exists on AFRU (`GMEIN`, not `MEINS`).
**v3 replaces the two guessed Z-structures with the real ones confirmed via
SE11**: workcenter exclusion now uses `ZPP_WORK_CENTER` with `LOEKZ = 'X'` as
the exclusion signal (there is no `ZPP_WORKCENTER_EXCLUDE` table, and
`ZPP_WORK_CENTER` has no dedicated exclude flag — `LOEKZ` was confirmed as the
right signal), and Rejected Qty now sums `AFRU-ZZRQUAN1..ZZRQUAN6` ("Reusable
Scrap Quantity 1-6", not `ZZQUAN1..6`). **v4 resolves R3's grouping**: it's a
plain per-workcenter cumulative sum, no calendar-month bucket. **v5 removes
the placeholder Plant `AUTHORITY-CHECK`** rather than shipping a guessed
object (`M_MATE_WRK` was a material-master object that didn't really fit a
confirmation report). **v6 closes out the three remaining business questions**:
STD QTY formula confirmed as the FS's literal text (algebraically equals Order
Qty, confirmed intended); `AFRU-ISERH` breakdown time now converted to hours
via `UNIT_CONVERSION_SIMPLE` using its own unit field `AFRU-ZEIER` (data
element `DZEIER`) instead of a hardcoded `/60`; and `AFKO-GLTRP`/`GSTRP`
start/end mapping confirmed as the FS states it. **v7 removes a redundant
validation**: `S_WERKS`/`S_DATUM` are already `OBLIGATORY`, so the manual
`IF ... IS INITIAL` + custom `MESSAGE` checks in `AT SELECTION-SCREEN`
duplicated behavior the selection-screen framework already provides, and
have been removed. **v8 restructures the optional-lookup checks in the
main loop**: each `READ TABLE` for an optional reference (work center,
material master/text, production version, order dates) is now followed
immediately by `IF sy-subrc = 0.` with the corresponding output field(s)
assigned right there, instead of a separate `IF sy-subrc <> 0. CLEAR ...`
followed by a big batched assignment block later - the `CLEAR` was dead
code anyway, since the work areas are already cleared at the top of each
loop iteration. Mandatory lookups (order header) still use the
`IF sy-subrc <> 0. CONTINUE.` guard-clause style, since that's the
clearer way to express "skip this record entirely." **v9 nests the
optional bulk-select dependencies**: the work center description
(`CRTX`) lookup now runs inside the same `IF lt_crhd IS NOT INITIAL`
block as the workcenter-exclusion lookup, since both depend on
`CRHD` data being found - it's never issued against an empty driver
table, matching the pattern already used for `PLPO` depending on
`PLKO`.
Full detail is in the report's header comment and in `docs/assumptions.md`.

## Before deploying

This is still a **code-level** fix, not a fully system-tested one. Before transport:

1. **Add a Plant `AUTHORITY-CHECK`.** None is implemented right now — confirm the
   correct object with your security team (check for an existing custom Z auth
   object first, or trace a comparable transaction like `CO11N`/`COOIS` with
   `STAUTHTRACE`/SU24) and add it in `AT SELECTION-SCREEN`.
2. Add text elements (001, 002) via SE38 → Goto → Text Elements.
3. Run SE38 syntax check / ATC and unit-test against real confirmations before wider
   rollout — in particular, verify `AFRU-ZEIER` exists under that name in your system
   and that `UNIT_CONVERSION_SIMPLE`'s exception handling behaves as expected.

See `docs/assumptions.md` for the full list.
