# WRICEF 166 – Overall Production Report (OEE in Adhesive) — S/4HANA 2022

S/4HANA 2022-compatible ABAP implementation, generated from the Functional
Specification `Copy of WRICEF ID 166-Overall production report for SFG FG and
moulding sperately.xlsx`. Same business logic as the earlier version; syntax
modernized to current ABAP style.

## What changed vs. the classic version

- **No `TABLES` statement.** Obsolete in modern ABAP — select-options
  reference DDIC fields directly via `TYPE`.
- **Modern Open SQL** — `SELECT ... INTO TABLE @DATA(...)` / `SELECT SINGLE
  ... INTO @DATA(...)` with `@` host-variable escaping and explicit field
  lists instead of `SELECT *`.
- **Inline declarations** (`DATA(...)`) throughout instead of upfront `DATA:`
  blocks for local work areas.
- **Constructor expressions** — `VALUE #( ... )` to build structures in one
  statement instead of field-by-field `MOVE`.
- **Encapsulated in a local class** (`lcl_report`) rather than `PERFORM`
  subroutines — subroutines (`FORM`/`PERFORM`) are still supported but
  discouraged in new S/4HANA code per the ABAP style guide.
- **`NEW`** instead of `CREATE OBJECT`.
- Table-expression lookups (`itab[ key = value ]`) instead of `READ TABLE ...
  INTO` for the monthly-summary accumulation.

## Contents

- `zsrc/ZPP_OEE_ADHESIVE_REPORT.abap` – main report program (S/4HANA 2022 syntax)
- `docs/field_mapping.md` – field-by-field source-to-target mapping (unchanged logic)
- `docs/assumptions.md` – open items to confirm before transport (unchanged)

## Still worth doing before deploying

Same open items as the classic version — none of the business-logic
ambiguities changed with the syntax rewrite:

1. Confirm `ZPP_WORKCENTER_EXCLUDE` structure and un-comment the exclusion SELECT.
2. Confirm `AFRU-ZZQUAN1..ZZQUAN6` custom fields exist; un-comment the rejected-qty sum.
3. Resolve the STD QTY formula ambiguity flagged inline in the code.
4. Add text elements (001, 002) via SE38 → Goto → Text Elements.
5. This has not been syntax-checked against a live S/4HANA 2022 system —
   run it through ATC (ABAP Test Cockpit) and SE38 syntax check before
   transport; table field lists (e.g. which AFRU/CAUFV fields exist in your
   specific release) should be verified against your system's DDIC.

## Note on architecture

This stays a classic ABAP report with `cl_salv_table` for output, matching
the original FS's "Report" object type. If your team is standardizing on
CDS views + Fiori Elements / Analytics for new S/4HANA reporting, the
`docs/field_mapping.md` table still gives you the source-field lineage
needed to build this as a CDS-based analytical query instead — happy to
draft that version too if useful.
