*&---------------------------------------------------------------------*
*& Report ZWRICEF_ID_PROG
*&---------------------------------------------------------------------*
*&
*&---------------------------------------------------------------------*
REPORT zwricef_id_prog.

TYPES:BEGIN OF ty_output,
        werks      TYPE afru-werks,
        ersda      TYPE afru-ersda,
        matnr      TYPE mara-matnr,
        maktx      TYPE makt-maktx,
        arbpl      TYPE crhd-arbpl,
        ktext      TYPE crtx-ktext,
        aufnr      TYPE aufnr,
        auart      TYPE aufart,
        matkl      TYPE mara-matkl,
        ntgew      TYPE mara-ntgew,
        gamng      TYPE gamng,
        gmnga      TYPE gmnga,
        gmein      TYPE meins,
        tot_ton    TYPE p LENGTH 16 DECIMALS 3,
        std_qty    TYPE p LENGTH 16 DECIMALS 3,
        manhrs     TYPE p LENGTH 16 DECIMALS 2,
        isdd       TYPE afru-isdd,
        iedd       TYPE afru-iedd,
        isdz       TYPE afru-isdz,
        iedz       TYPE afru-iedz,
        runhrs     TYPE p LENGTH 16 DECIMALS 2,
        avail      TYPE p LENGTH 8 DECIMALS 2,
        qual       TYPE p LENGTH 8 DECIMALS 2,
        perf       TYPE p LENGTH 8 DECIMALS 2,
        oee        TYPE p LENGTH 8 DECIMALS 2,
        rej_qty    TYPE p LENGTH 16 DECIMALS 3,
        iserh      TYPE afru-iserh,
        cap_util   TYPE p LENGTH 8 DECIMALS 2,
        verid      TYPE verid,
        stlal      TYPE stlal,
        gstrp      TYPE afko-gstrp,
        gltrp      TYPE afko-gltrp,
        vornr      TYPE afvc-vornr,
        stzhl      TYPE afru-stzhl,
        stokz      TYPE afru-stokz,
        rueck      TYPE afru-rueck,
        rmzhl      TYPE afru-rmzhl,
        ism02      TYPE afru-ism02,
        std_manhrs TYPE p LENGTH 16 DECIMALS 2,

        bmsch      TYPE plpo-bmsch,
        vge04      TYPE plpo-vge04,
        ism04      TYPE afru-ism04,
      END OF ty_output.

TYPES:BEGIN OF ty_afru,
        werks TYPE afru-werks,
        ersda TYPE afru-ersda,
        aufnr TYPE afru-aufnr,
        arbid TYPE afru-arbid,
        rueck TYPE afru-rueck,
        rmzhl TYPE afru-rmzhl,
        vornr TYPE afru-vornr,
        gmnga TYPE afru-gmnga,
        gmein TYPE meins,
        ism02 TYPE afru-ism02,
        ism04 TYPE afru-ism04,
        isdd  TYPE afru-isdd,
        iedd  TYPE afru-iedd,
        isdz  TYPE afru-isdz,
        iedz  TYPE afru-iedz,
        iserh TYPE afru-iserh,
*        zzquan1 TYPE afru-zzquan1,
*        zzquan2 TYPE afru-zzquan2,
*        zzquan3 TYPE afru-zzquan3,
*        zzquan4 TYPE afru-zzquan4,
*        zzquan5 TYPE afru-zzquan5,
*        zzquan6 TYPE afru-zzquan6,
        stzhl TYPE afru-stzhl,
        stokz TYPE afru-stokz,
      END OF ty_afru.

TYPES:BEGIN OF ty_caufv,
        aufnr  TYPE caufv-aufnr,
        plnbez TYPE caufv-plnbez,
        gamng  TYPE caufv-gamng,
        auart  TYPE caufv-auart,
        plnty  TYPE caufv-plnty,
        plnnr  TYPE caufv-plnnr,
        plnal  TYPE caufv-plnal, "for BAPI
        stlal  TYPE caufv-stlal, "for BAPI
      END OF ty_caufv.

TYPES:BEGIN OF ty_crhd,
        objid TYPE crhd-objid,
        arbpl TYPE crhd-arbpl,
        werks TYPE crhd-werks,
      END OF ty_crhd.

TYPES:BEGIN OF ty_excl,
        werks TYPE crhd-werks,
        arbpl TYPE crhd-arbpl,
      END OF ty_excl.

TYPES:BEGIN OF ty_crtx,
        objid TYPE crtx-objid,
        ktext TYPE crtx-ktext,
      END OF ty_crtx.

TYPES:BEGIN OF ty_mara,
        matnr TYPE mara-matnr,
        matkl TYPE mara-matkl,
        ntgew TYPE mara-ntgew,
      END OF ty_mara.

TYPES:BEGIN OF ty_makt,
        matnr TYPE makt-matnr,
        maktx TYPE makt-maktx,
      END OF ty_makt.

TYPES:BEGIN OF ty_afpo,
        aufnr TYPE afpo-aufnr,
        verid TYPE afpo-verid,
      END OF ty_afpo.

TYPES:BEGIN OF ty_afko,
        aufnr TYPE afko-aufnr,
        gstrp TYPE afko-gstrp,
        gltrp TYPE afko-gltrp,
      END OF ty_afko.

TYPES:BEGIN OF ty_plpo,
        plnty TYPE plpo-plnty,
        plnnr TYPE plpo-plnnr,
*        plnal TYPE plpo-plnal,
        vornr TYPE plpo-vornr,
        bmsch TYPE plpo-bmsch,
        vge04 TYPE plpo-vge04,
      END OF ty_plpo.

TYPES:BEGIN OF ty_summary,
        werks    TYPE afru-werks,
        arbpl    TYPE crhd-arbpl,
        ktext    TYPE crtx-ktext,
        tot_ton  TYPE p LENGTH 16 DECIMALS 3,
        std_qty  TYPE p LENGTH 16 DECIMALS 3,
        manhrs   TYPE p LENGTH 16 DECIMALS 2,
        runhrs   TYPE p LENGTH 16 DECIMALS 2,
        rej_qty  TYPE p LENGTH 16 DECIMALS 3,
        avail    TYPE p LENGTH 8 DECIMALS 2,
        qual     TYPE p LENGTH 8 DECIMALS 2,
        perf     TYPE p LENGTH 8 DECIMALS 2,
        oee      TYPE p LENGTH 8 DECIMALS 2,
        cap_util TYPE p LENGTH 8 DECIMALS 2,
      END OF ty_summary.

DATA:gt_summary TYPE STANDARD TABLE OF ty_summary,
     gs_summary TYPE ty_summary.

DATA:gt_plpo TYPE STANDARD TABLE OF ty_plpo.

DATA:gt_afko TYPE STANDARD TABLE OF ty_afko.

DATA:gt_afpo TYPE STANDARD TABLE OF ty_afpo.

DATA:gt_makt TYPE STANDARD TABLE OF ty_makt.

DATA:gt_mara TYPE STANDARD TABLE OF ty_mara.

DATA:gt_crtx TYPE STANDARD TABLE OF ty_crtx.

DATA:gt_excl TYPE STANDARD TABLE OF ty_excl.

DATA:gt_crhd TYPE STANDARD TABLE OF ty_crhd.

DATA:gt_caufv TYPE STANDARD TABLE OF ty_caufv.

DATA gt_afru TYPE STANDARD TABLE OF ty_afru.

DATA:gt_output TYPE STANDARD TABLE OF ty_output,
     gs_output TYPE ty_output.

DATA: gv_werks TYPE afru-werks,
      gv_matnr TYPE mara-matnr,
      gv_ersda TYPE afru-ersda,
      gv_arbpl TYPE crhd-arbpl.


SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

  PARAMETERS:r_mld RADIOBUTTON GROUP rg1 DEFAULT 'X',
             r_sfg RADIOBUTTON GROUP rg1,
             r_sum RADIOBUTTON GROUP rg1.

  SELECTION-SCREEN SKIP.

  SELECT-OPTIONS:s_werks FOR gv_werks OBLIGATORY,
                 s_matnr FOR gv_matnr,
                 s_erdat FOR gv_ersda OBLIGATORY,
                 s_arbpl FOR gv_arbpl.

SELECTION-SCREEN END OF BLOCK b1.

AT SELECTION-SCREEN.

  LOOP AT s_werks.

    AUTHORITY-CHECK OBJECT 'M_MATE_WRK'
      ID 'WERKS' FIELD s_werks-low
      ID 'ACTVT' FIELD '03'.

    IF sy-subrc <> 0.
      MESSAGE 'You are not authorized for this Plant' TYPE 'E'.
    ENDIF.

  ENDLOOP.

START-OF-SELECTION.
  PERFORM get_data.
  PERFORM process_data.
  PERFORM display_data.
*&---------------------------------------------------------------------*
*& Form get_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM get_data .
  SELECT
  werks,
  ersda,
  aufnr,
  arbid,
  rueck,
  rmzhl,
  vornr,
  gmnga,
  gmein,
  ism02,
  ism04,
  isdd,
  iedd,
  isdz,
  iedz,
  iserh,
*  zzquan1,
*  zzquan2,
*  zzquan3,
*  zzquan4,
*  zzquan5,
*  zzquan6,
  stzhl,
  stokz
  FROM afru
  WHERE werks IN @s_werks
  AND ersda IN @s_erdat
  INTO CORRESPONDING FIELDS OF TABLE @gt_afru.

  IF gt_afru IS INITIAL.
    MESSAGE 'No data found' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  SELECT
aufnr,
plnbez,
gamng,
auart,
plnty,
plnnr,
plnal,
stlal
FROM caufv
FOR ALL ENTRIES IN @gt_afru
WHERE aufnr = @gt_afru-aufnr
INTO TABLE @gt_caufv.

  IF gt_caufv IS INITIAL.
    MESSAGE 'No production orders found.' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  IF r_sfg = 'X'.
    DELETE gt_caufv WHERE plnty <> '2'.
  ENDIF.

  IF gt_caufv IS INITIAL.
    MESSAGE 'No data found for SFG & FG.' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  IF s_matnr IS NOT INITIAL.
    DELETE gt_caufv WHERE plnbez NOT IN s_matnr.
  ENDIF.

  IF gt_caufv IS INITIAL.
    MESSAGE 'No data found for selected material.' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  SELECT
  objid,
  arbpl,
  werks
  FROM crhd
  FOR ALL ENTRIES IN @gt_afru
  WHERE objid = @gt_afru-arbid
  INTO TABLE @gt_crhd.

  IF gt_crhd IS INITIAL.
    MESSAGE 'No work center found.' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.


  IF s_arbpl IS NOT INITIAL.
    DELETE gt_crhd WHERE arbpl NOT IN s_arbpl.
  ENDIF.

  IF gt_crhd IS INITIAL.
    MESSAGE 'No work center found for selection.' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

*SELECT
*werks,
*arbpl
*FROM zpp_workcenter_exclude
*FOR ALL ENTRIES IN @gt_crhd
*WHERE werks = @gt_crhd-werks
*AND arbpl = @gt_crhd-arbpl
*INTO TABLE @gt_excl.

*  LOOP AT gt_excl INTO DATA(gs_excl).
*  DELETE gt_crhd WHERE werks = gs_excl-werks
*                  AND arbpl = gs_excl-arbpl.
*ENDLOOP.

  SELECT
  objid,
  ktext
  FROM crtx
  FOR ALL ENTRIES IN @gt_crhd
  WHERE objid = @gt_crhd-objid
  AND spras = @sy-langu
  INTO TABLE @gt_crtx.

  IF gt_crtx IS INITIAL.
    MESSAGE 'Work center description not found.' TYPE 'S'.
  ENDIF.

  SELECT
  matnr,
  matkl,
  ntgew
  FROM mara
  FOR ALL ENTRIES IN @gt_caufv
  WHERE matnr = @gt_caufv-plnbez
  INTO TABLE @gt_mara.

  IF gt_mara IS INITIAL.
    MESSAGE 'Material master data not found.' TYPE 'S'.
  ENDIF.

  SELECT
matnr,
maktx
FROM makt
FOR ALL ENTRIES IN @gt_caufv
WHERE matnr = @gt_caufv-plnbez
AND spras = @sy-langu
INTO TABLE @gt_makt.

  IF gt_makt IS INITIAL.
    MESSAGE 'Material description not found.' TYPE 'S'.
  ENDIF.

  SELECT
aufnr,
verid
FROM afpo
FOR ALL ENTRIES IN @gt_caufv
WHERE aufnr = @gt_caufv-aufnr
INTO TABLE @gt_afpo.

  IF gt_afpo IS INITIAL.
    MESSAGE 'Production version not found.' TYPE 'S'.
  ENDIF.

  SELECT
  aufnr,
  gstrp,
  gltrp
  FROM afko
  FOR ALL ENTRIES IN @gt_caufv
  WHERE aufnr = @gt_caufv-aufnr
  INTO TABLE @gt_afko.

  IF gt_afko IS INITIAL.
    MESSAGE 'Order dates not found.' TYPE 'S'.
  ENDIF.

* Using This instead BAPI for BMSCH/VGE04
  SELECT
plnty,
plnnr,
*plnal,
vornr,
bmsch,
vge04
FROM plpo
FOR ALL ENTRIES IN @gt_caufv
WHERE plnty = @gt_caufv-plnty
AND plnnr = @gt_caufv-plnnr
*AND plnal = @gt_caufv-plnal
INTO TABLE @gt_plpo.

  IF gt_plpo IS INITIAL.
    MESSAGE 'Routing data not found.' TYPE 'S'.
  ELSE.
    SORT gt_plpo BY plnty plnnr vornr. "plnal.
  ENDIF.



ENDFORM.
*&---------------------------------------------------------------------*
*& Form process_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM process_data .
  SORT gt_caufv BY aufnr.
  SORT gt_crhd BY objid.
  SORT gt_crtx BY objid.
  SORT gt_mara BY matnr.
  SORT gt_makt BY matnr.
  SORT gt_afpo BY aufnr.
  SORT gt_afko BY aufnr.

  LOOP AT gt_afru INTO DATA(gs_afru).

    CLEAR gs_output.

    gs_output-werks = gs_afru-werks.
    gs_output-ersda = gs_afru-ersda.
    gs_output-aufnr = gs_afru-aufnr.
    gs_output-gmnga = gs_afru-gmnga.
    gs_output-gmein = gs_afru-gmein.
    gs_output-isdd = gs_afru-isdd.
    gs_output-iedd = gs_afru-iedd.
    gs_output-isdz = gs_afru-isdz.
    gs_output-iedz = gs_afru-iedz.
    gs_output-iserh = gs_afru-iserh.
    gs_output-vornr = gs_afru-vornr.
    gs_output-rueck = gs_afru-rueck.
    gs_output-rmzhl = gs_afru-rmzhl.
    gs_output-stzhl = gs_afru-stzhl.
    gs_output-stokz = gs_afru-stokz.
    gs_output-ism02 = gs_afru-ism02.
    gs_output-ism04 = gs_afru-ism04.

    READ TABLE gt_caufv INTO DATA(gs_caufv)
    WITH KEY aufnr = gs_afru-aufnr
    BINARY SEARCH.

    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

    gs_output-matnr = gs_caufv-plnbez.
    gs_output-gamng = gs_caufv-gamng.
    gs_output-auart = gs_caufv-auart.
    gs_output-stlal = gs_caufv-stlal.

    READ TABLE gt_mara INTO DATA(gs_mara)
    WITH KEY matnr = gs_output-matnr
    BINARY SEARCH.

    IF sy-subrc = 0.

      gs_output-matkl = gs_mara-matkl.
      gs_output-ntgew = gs_mara-ntgew.

    ENDIF.

    READ TABLE gt_makt INTO DATA(gs_makt)
    WITH KEY matnr = gs_output-matnr
    BINARY SEARCH.

    IF sy-subrc = 0.
      gs_output-maktx = gs_makt-maktx.
    ENDIF.

    READ TABLE gt_crhd INTO DATA(gs_crhd)
    WITH KEY objid = gs_afru-arbid
    BINARY SEARCH.

    IF sy-subrc = 0.

      gs_output-arbpl = gs_crhd-arbpl.

    ENDIF.

    READ TABLE gt_crtx INTO DATA(gs_crtx)
    WITH KEY objid = gs_afru-arbid
    BINARY SEARCH.

    IF sy-subrc = 0.

      gs_output-ktext = gs_crtx-ktext.

    ENDIF.

    READ TABLE gt_afpo INTO DATA(gs_afpo)
    WITH KEY aufnr = gs_afru-aufnr
    BINARY SEARCH.

    IF sy-subrc = 0.

      gs_output-verid = gs_afpo-verid.

    ENDIF.

    READ TABLE gt_afko INTO DATA(gs_afko)
    WITH KEY aufnr = gs_afru-aufnr
    BINARY SEARCH.

    IF sy-subrc = 0.

      gs_output-gstrp = gs_afko-gstrp.
      gs_output-gltrp = gs_afko-gltrp.

    ENDIF.

    READ TABLE gt_plpo INTO DATA(gs_plpo)
    WITH KEY plnty = gs_caufv-plnty
             plnnr = gs_caufv-plnnr
*         plnal = gs_caufv-plnal
             vornr = gs_afru-vornr
    BINARY SEARCH.

    IF sy-subrc = 0.
      gs_output-bmsch = gs_plpo-bmsch.
      gs_output-vge04 = gs_plpo-vge04.
    ENDIF.

    gs_output-std_qty = gs_output-bmsch.
    gs_output-std_manhrs = gs_output-vge04.

    IF gs_output-gmnga IS NOT INITIAL AND gs_output-ntgew IS NOT INITIAL.
      gs_output-tot_ton = ( gs_output-gmnga * gs_output-ntgew ) / 1000.
    ENDIF.

    IF gs_output-ism02 IS NOT INITIAL OR gs_output-ism04 IS NOT INITIAL.
      gs_output-manhrs = gs_output-ism02 + gs_output-ism04.
    ENDIF.

    IF gs_output-ism02 IS NOT INITIAL
OR gs_output-ism04 IS NOT INITIAL.
      gs_output-runhrs = ( gs_output-ism02 + gs_output-ism04 ) / 60.
    ENDIF.

*  gs_output-rej_qty =
*    gs_afru-zzquan1 +
*    gs_afru-zzquan2 +
*    gs_afru-zzquan3 +
*    gs_afru-zzquan4 +
*    gs_afru-zzquan5 +
*    gs_afru-zzquan6.

    IF gs_output-runhrs > 0.
      gs_output-avail =
        ( ( gs_output-runhrs - gs_output-iserh ) / gs_output-runhrs ) * 100.
    ENDIF.

    DATA(lv_total_qty) = gs_output-gmnga + gs_output-rej_qty.

    IF lv_total_qty > 0.
      gs_output-qual =
        ( gs_output-gmnga / lv_total_qty ) * 100.
    ENDIF.

    DATA:lv_std_pc_min TYPE p LENGTH 16 DECIMALS 6,
         lv_act_pc_min TYPE p LENGTH 16 DECIMALS 6.

    IF gs_output-vge04 > 0.
      lv_std_pc_min = gs_output-bmsch / gs_output-vge04.
    ENDIF.

    IF gs_output-ism04 > 0.
      lv_act_pc_min = gs_output-gmnga / gs_output-ism04.
    ENDIF.

    IF lv_std_pc_min > 0.
      gs_output-perf =
        ( lv_act_pc_min / lv_std_pc_min ) * 100.
    ENDIF.

    gs_output-oee =
      ( gs_output-avail *
        gs_output-qual *
        gs_output-perf ) / 10000.

    IF gs_output-std_qty > 0.
      gs_output-cap_util =
        ( gs_output-gmnga / gs_output-std_qty ) * 100.
    ENDIF.

    APPEND gs_output TO gt_output.

  ENDLOOP.

  IF r_sum = 'X'.
    PERFORM monthly_summary.
  ENDIF.



ENDFORM.
*&---------------------------------------------------------------------*
*& Form display_data
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM display_data.

  IF gt_output IS INITIAL.
    MESSAGE 'No data available to display.' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  DATA:lo_alv     TYPE REF TO cl_salv_table,
       lo_columns TYPE REF TO cl_salv_columns_table,
       lo_column  TYPE REF TO cl_salv_column_table,
       lo_display TYPE REF TO cl_salv_display_settings.

  TRY.

      IF r_sum = 'X'.

        cl_salv_table=>factory(
          IMPORTING
            r_salv_table = lo_alv
          CHANGING
            t_table = gt_summary ).

      ELSE.

        cl_salv_table=>factory(
          IMPORTING
            r_salv_table = lo_alv
          CHANGING
            t_table = gt_output ).

      ENDIF.

      lo_alv->get_functions( )->set_all( abap_true ).

      lo_columns = lo_alv->get_columns( ).
      lo_columns->set_optimize( abap_true ).

      lo_display = lo_alv->get_display_settings( ).
      lo_display->set_striped_pattern( abap_true ).
      lo_display->set_list_header( 'Overall Production Report' ).

      TRY.

          lo_column ?= lo_columns->get_column( 'WERKS' ).
          lo_column->set_long_text( 'Plant Code' ).

          lo_column ?= lo_columns->get_column( 'ERSDA' ).
          lo_column->set_long_text( 'Date' ).

          lo_column ?= lo_columns->get_column( 'MATNR' ).
          lo_column->set_long_text( 'Material Code' ).

          lo_column ?= lo_columns->get_column( 'MAKTX' ).
          lo_column->set_long_text( 'Material Description' ).

          lo_column ?= lo_columns->get_column( 'ARBPL' ).
          lo_column->set_long_text( 'Work Centre Name' ).

          lo_column ?= lo_columns->get_column( 'KTEXT' ).
          lo_column->set_long_text( 'Work Centre Description' ).

          lo_column ?= lo_columns->get_column( 'AUFNR' ).
          lo_column->set_long_text( 'Production Order' ).

          lo_column ?= lo_columns->get_column( 'AUART' ).
          lo_column->set_long_text( 'Order Type' ).

          lo_column ?= lo_columns->get_column( 'MATKL' ).
          lo_column->set_long_text( 'Material Group' ).

          lo_column ?= lo_columns->get_column( 'NTGEW' ).
          lo_column->set_long_text( 'Net Weight' ).

          lo_column ?= lo_columns->get_column( 'GAMNG' ).
          lo_column->set_long_text( 'Order Qty' ).

          lo_column ?= lo_columns->get_column( 'GMNGA' ).
          lo_column->set_long_text( 'Confirmed Qty' ).

          lo_column ?= lo_columns->get_column( 'GMEIN' ).
          lo_column->set_long_text( 'UoM' ).

          lo_column ?= lo_columns->get_column( 'TOT_TON' ).
          lo_column->set_long_text( 'Total Tons' ).

          lo_column ?= lo_columns->get_column( 'STD_QTY' ).
          lo_column->set_long_text( 'Std Qty' ).

          lo_column ?= lo_columns->get_column( 'STD_MANHRS' ).
          lo_column->set_long_text( 'Man Hours' ).

          lo_column ?= lo_columns->get_column( 'ISDZ' ).
          lo_column->set_long_text( 'Start Time' ).

          lo_column ?= lo_columns->get_column( 'IEDZ' ).
          lo_column->set_long_text( 'End Time' ).

          lo_column ?= lo_columns->get_column( 'RUNHRS' ).
          lo_column->set_long_text( 'Running Hours' ).

          lo_column ?= lo_columns->get_column( 'AVAIL' ).
          lo_column->set_long_text( 'A%' ).

          lo_column ?= lo_columns->get_column( 'QUAL' ).
          lo_column->set_long_text( 'Q%' ).

          lo_column ?= lo_columns->get_column( 'PERF' ).
          lo_column->set_long_text( 'P%' ).

          lo_column ?= lo_columns->get_column( 'OEE' ).
          lo_column->set_long_text( 'OEE %' ).

          lo_column ?= lo_columns->get_column( 'REJ_QTY' ).
          lo_column->set_long_text( 'Rejected Qty' ).

          lo_column ?= lo_columns->get_column( 'ISERH' ).
          lo_column->set_long_text( 'Breakdown Time' ).

          lo_column ?= lo_columns->get_column( 'CAP_UTIL' ).
          lo_column->set_long_text( 'Capacity Utilization %' ).

          lo_column ?= lo_columns->get_column( 'VERID' ).
          lo_column->set_long_text( 'Production Version' ).

          lo_column ?= lo_columns->get_column( 'STLAL' ).
          lo_column->set_long_text( 'Alternative BOM' ).

          lo_column ?= lo_columns->get_column( 'GSTRP' ).
          lo_column->set_long_text( 'Order Start Date' ).

          lo_column ?= lo_columns->get_column( 'GLTRP' ).
          lo_column->set_long_text( 'Order End Date' ).

          lo_column ?= lo_columns->get_column( 'VORNR' ).
          lo_column->set_long_text( 'Phase/Operation' ).

          lo_column ?= lo_columns->get_column( 'ISDD' ).
          lo_column->set_long_text( 'Start Date' ).

          lo_column ?= lo_columns->get_column( 'IEDD' ).
          lo_column->set_long_text( 'End Date' ).

          lo_column ?= lo_columns->get_column( 'STZHL' ).
          lo_column->set_long_text( 'Cancelled' ).

          lo_column ?= lo_columns->get_column( 'STOKZ' ).
          lo_column->set_long_text( 'Reversed' ).

          lo_column ?= lo_columns->get_column( 'RUECK' ).
          lo_column->set_long_text( 'Confirmation Number' ).

          lo_column ?= lo_columns->get_column( 'RMZHL' ).
          lo_column->set_long_text( 'Confirmation Counter' ).

          lo_column ?= lo_columns->get_column( 'ISM02' ).
          lo_column->set_long_text( 'Setup Machine' ).

        CATCH cx_salv_not_found.
      ENDTRY.

      lo_alv->display( ).

    CATCH cx_salv_msg.
      MESSAGE 'Error displaying ALV' TYPE 'E'.
  ENDTRY.

ENDFORM.
*&---------------------------------------------------------------------*
*& Form monthly_summary
*&---------------------------------------------------------------------*
*& text
*&---------------------------------------------------------------------*
*& -->  p1        text
*& <--  p2        text
*&---------------------------------------------------------------------*
FORM monthly_summary.

  SORT gt_output BY werks arbpl.

  CLEAR gt_summary.

  LOOP AT gt_output INTO gs_output.

    AT NEW arbpl.

      CLEAR gs_summary.
      gs_summary-werks = gs_output-werks.
      gs_summary-arbpl = gs_output-arbpl.
      gs_summary-ktext = gs_output-ktext.

    ENDAT.

    gs_summary-tot_ton = gs_summary-tot_ton + gs_output-tot_ton.
    gs_summary-std_qty = gs_summary-std_qty + gs_output-std_qty.
    gs_summary-manhrs = gs_summary-manhrs + gs_output-manhrs.
    gs_summary-runhrs = gs_summary-runhrs + gs_output-runhrs.
    gs_summary-rej_qty = gs_summary-rej_qty + gs_output-rej_qty.

    AT END OF arbpl.

      IF gs_summary-runhrs IS NOT INITIAL.
        gs_summary-avail =
          ( ( gs_summary-runhrs - gs_output-iserh ) /
            gs_summary-runhrs ) * 100.
      ENDIF.

      APPEND gs_summary TO gt_summary.

    ENDAT.

  ENDLOOP.

  CLEAR gt_output.

ENDFORM.