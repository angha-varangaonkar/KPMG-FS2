# Assumptions & Open Questions — WRICEF 166

These need sign-off from the functional consultant before this program is
transported beyond a dev/unit-test client.

1. **STD QTY formula ambiguity.** The FS states two derivations and says to
   multiply them:
   - `val1 = BMSCH / VGE04`
   - `val2 = Order Qty × VGE04 / BMSCH`
   - `STD QTY = val1 × val2`

   Algebraically, `val1 × val2` simplifies to `Order Qty` regardless of the
   routing values, which suggests the FS intends something else (perhaps
   `val1 × Order Qty`, i.e. the standard rate applied to the order quantity).
   Implemented literally in the code, with a comment at the point of
   calculation. **Please confirm intended formula before go-live.**

2. **ZPP_WORKCENTER_EXCLUDE structure.** The FS names this Z-table but
   doesn't give its field list. The exclusion SELECT is commented out in the
   code pending confirmation of field names (assumed `WERKS` + `ARBPL`).

3. **AFRU-ZZQUAN1 through ZZQUAN6.** Assumed to be custom append/include
   fields on AFRU holding rejection-reason-coded quantities. Confirm these
   exist in the target system (they're not standard AFRU fields) and adjust
   the SELECT accordingly.

4. **Breakdown time unit.** FS says "Break time when user enter in CO11N" for
   `BREAKDOWN TIME`, mapped to `AFRU-ISERH`. Divided by 60 here assuming
   `ISERH` is stored in minutes; confirm the actual unit in your system
   (some configurations store it in seconds).

5. **Monthly Summary (R3) granularity.** The FS only says "Show workcenter
   wise cumulative sum of Capacity utilization" without specifying the time
   bucket. Implemented as calendar month (`YYYYMM` from confirmation date) —
   confirm this matches the intended "Monthly summary" behavior.

6. **Order dates.** FS lists `Order Start date` = `AFKO-GLTRP` and
   `Order end Date` = `AFKO-GSTRP`. Note these are basic-start/basic-finish
   fields in AFKO; naming in the FS ("start"/"end") is reversed relative to
   SAP's usual GSTRP=start / GLTRP=finish convention — mapped literally per
   the FS text, please double check against your actual requirement.

7. **Text elements** (001 "Selection Criteria", 002 "Report Type") must be
   maintained in SE38 before activation — placeholder names only in source.

8. **No authorization checks** beyond standard object/select-option
   authority (Plant "as an authorization object" per FS) — add an explicit
   `AUTHORITY-CHECK` against `M_BEST_WRK` or the relevant PP auth object if
   required by your security team.
