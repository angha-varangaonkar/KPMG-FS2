# Field Mapping — WRICEF 166

Source: "Detailed FS" tab of the original spreadsheet.

| Output Field | Source | Logic |
|---|---|---|
| PLANT CODE | AFRU-WERKS | Selection screen plant |
| DATE | AFRU-ERSDA | Confirmation entry date |
| MATERIAL CODE | CAUFV-PLNBEZ | Via AFRU-AUFNR → CAUFV-AUFNR |
| DESCRIPTION | MAKT-MAKTX | CAUFV-PLNBEZ → MARA/MAKT, language EN |
| WORKCENTRE NAME | CRHD-ARBPL | AFRU-ARBID → CRHD-OBJID; exclude rows matching ZPP_WORKCENTER_EXCLUDE |
| WORKCENTER DES | CRTX-KTEXT | CRHD-OBJID → CRTX-OBJID |
| PRODUCTION ORDER | AFRU-AUFNR | Direct |
| ORDER TYPE | CAUFV-AUART | Via CAUFV-AUFNR |
| MATERIAL GROUP | MARA-MATKL | Via CAUFV-PLNBEZ → MARA-MATNR |
| NET WEIGHT | MARA-NTGEW | Via CAUFV-PLNBEZ → MARA-MATNR |
| ORDER QTY | CAUFV-GAMNG | Via AFRU-AUFNR → CAUFV-AUFNR |
| CONFIRM QTY | AFRU-GMNGA | Direct |
| UOM | AFRU-MEINS | Direct |
| TOTAL TONNAGE | Calculated | Confirmed Qty × Net Weight / 1000 |
| STD QTY | BAPI CARO_ROUTING_READ (BMSCH, VGE04) | See assumptions.md — formula ambiguity flagged |
| MANHOURS | AFRU-ISM02 + AFRU-ISM04 | Sum / 60 |
| START TIME | AFRU-ISDZ | Direct |
| END TIME | AFRU-IEDZ | Direct |
| RUNNING HRS | End Time − Start Time | In hours |
| A% | Runtime, Breakdown Time | (Runtime − AFRU-ISERH) / Runtime |
| Q% | AFRU-GMNGA, ZZQUAN1-6 | Confirmed Qty / (Confirmed Qty + Rejected Qty) |
| P% | Actual vs Std PC/min | (Confirmed Qty / AFRU-ISM04) / (BMSCH / VGE04) |
| OEE % | Calculated | A% × Q% × P% |
| REJECTED QTY | AFRU-ZZQUAN1..ZZQUAN6 | Sum of custom append fields |
| BREAKDOWN TIME | AFRU-ISERH | / 60 (minutes → hours) |
| CAPACITY UTILIZATION % | Calculated | Confirmed Qty / STD Qty |
| Production version | AFPO-VERID | Via CAUFV-AUFNR → AFPO-AUFNR |
| Alternative BOM | CAUFV-STLAL | Direct |
| Order Start Date | AFKO-GLTRP | Via CAUFV-AUFNR → AFKO-AUFNR |
| Order End Date | AFKO-GSTRP | Via CAUFV-AUFNR → AFKO-AUFNR |
| Phases/Operation | AFRU-VORNR | Direct |
| Cancelled | AFRU-STZHL | Direct |
| Reversed | AFRU-STOKZ | Direct |
| Confirmation Number | AFRU-RUECK | Direct |
| Confirmation Counter | AFRU-RMZHL | Direct |
| Setup Machine | AFRU-ISM02 | Direct |
| Std Man Hours | Order Qty, AFRU-ISM04, BMSCH | Order Qty × ISM04 / BMSCH |

## Radio button variants

- **R1 – Moulding Report**: no routing-type restriction.
- **R2 – SFG and FG Production**: identical logic, filtered to `CAUFV-PLNTY = '2'` only
  (per FS note: "Only PLNTY=2, rest logic same").
- **R3 – Monthly Summary**: aggregates R1's output by Workcenter + Month, summing
  Capacity Utilization %.
