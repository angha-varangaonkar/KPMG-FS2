*&---------------------------------------------------------------------*
*& Report ZPP_OEE_ADHESIVE_REPORT
*&---------------------------------------------------------------------*
*& WRICEF ID  : 166
*& Object Name: Report for OEE in Adhesive
*& Module     : PP
*& Author     : Generated from Functional Specification
*&               "Overall production report for SFG FG and moulding
*&                separately"
*& Version    : 1
*&
*& Purpose:
*&   Single selection-screen driven report offering three mutually
*&   exclusive output views (radio buttons), per the FS:
*&     R1 - Moulding Report            (all routing types)
*&     R2 - SFG and FG Production      (routing type PLNTY = '2' only)
*&     R3 - Monthly Summary            (workcenter-wise cumulative
*&                                      Capacity Utilization %)
*&
*& NOTE: This program is a direct implementation of the logic
*&   described in the FS "Detailed FS" tab. Some source formulas in
*&   that tab were stated inconsistently across rows (e.g. STD QTY /
*&   MANHOURS are each described two different ways). Where that
*&   happened, the interpretation used here is called out in a
*&   comment at the relevant point - please confirm with the
*&   functional consultant (Yogesh Rathore) before transport to QA.
*&---------------------------------------------------------------------*
REPORT zpp_oee_adhesive_report.

*&---------------------------------------------------------------------*
*& Tables used (per FS "Selection parameters" table)
*&---------------------------------------------------------------------*
TABLES: afru,                       "Confirmations
        caufv,                     "Order header (view)
        afpo,                      "Order item
        mara,                      "Material master
        makt.                      "Material descriptions

*&---------------------------------------------------------------------*
*& Custom exclusion table (per FS seq 4)
*&   Assumption: table holds WERKS + ARBPL combinations to be excluded
*&   from output. Field names assumed; adjust to match actual DDIC.
*&---------------------------------------------------------------------*
* TABLES: zpp_workcenter_exclude.

*&---------------------------------------------------------------------*
*& Output structure - one line per Confirmation (AFRU-ERSDA/RUECK/RMZHL)
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_output,
         werks            TYPE afru-werks,           "Plant Code
         datum            TYPE afru-ersda,           "Confirmation entry date
         matnr            TYPE mara-matnr,           "Material Code
         maktx            TYPE makt-maktx,           "Description
         arbpl            TYPE crhd-arbpl,           "Workcentre Name
         ktext            TYPE crtx-ktext,           "Workcenter Description
         aufnr            TYPE afru-aufnr,           "Production Order
         auart            TYPE caufv-auart,          "Order Type
         matkl            TYPE mara-matkl,           "Material Group
         ntgew            TYPE mara-ntgew,           "Net Weight
         gamng            TYPE caufv-gamng,          "Order Qty
         gmnga            TYPE afru-gmnga,           "Confirm Qty
         meins            TYPE afru-meins,           "UOM
         tot_tonnage      TYPE p LENGTH 13 DECIMALS 3, "Total Tonnage
         std_qty          TYPE p LENGTH 13 DECIMALS 3, "Std Qty
         manhours         TYPE p LENGTH 13 DECIMALS 3, "Manhours
         start_time       TYPE afru-isdz,            "Start Time
         end_time         TYPE afru-iedz,            "End Time
         running_hrs      TYPE p LENGTH 9 DECIMALS 4,  "Running Hrs
         a_pct            TYPE p LENGTH 7 DECIMALS 4,  "Availability %
         q_pct            TYPE p LENGTH 7 DECIMALS 4,  "Quality %
         p_pct            TYPE p LENGTH 7 DECIMALS 4,  "Performance %
         oee_pct          TYPE p LENGTH 7 DECIMALS 4,  "OEE %
         rejected_qty     TYPE p LENGTH 13 DECIMALS 3, "Rejected Qty
         breakdown_time   TYPE p LENGTH 9 DECIMALS 4,  "Breakdown Time (hrs)
         cap_util_pct     TYPE p LENGTH 7 DECIMALS 4,  "Capacity Utilization %
         verid            TYPE afpo-verid,          "Production Version
         stlal            TYPE caufv-stlal,         "Alternative BOM
         order_start_date TYPE afko-gltrp,          "Order Start Date
         order_end_date   TYPE afko-gstrp,           "Order End Date
         vornr            TYPE afru-vornr,          "Phase / Operation
         cancelled        TYPE afru-stzhl,          "Cancelled
         reversed         TYPE afru-stokz,          "Reversed
         rueck            TYPE afru-rueck,          "Confirmation Number
         rmzhl            TYPE afru-rmzhl,          "Confirmation Counter
         setup_machine    TYPE afru-ism02,          "Setup Machine (confirmed)
         std_manhours     TYPE p LENGTH 13 DECIMALS 3, "Std Man Hours
       END OF ty_output.

DATA: gt_output TYPE STANDARD TABLE OF ty_output,
      gs_output TYPE ty_output.

DATA: gt_monthly TYPE STANDARD TABLE OF ty_output, "reused for R3 aggregation
      BEGIN OF gs_monthly,
        arbpl        TYPE crhd-arbpl,
        month        TYPE spmon,
        cap_util_sum TYPE p LENGTH 9 DECIMALS 4,
      END OF gs_monthly.

DATA: gt_monthly_summary LIKE STANDARD TABLE OF gs_monthly.

*&---------------------------------------------------------------------*
*& Selection Screen (per FS "Selection Screen" block)
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

SELECT-OPTIONS: s_werks FOR afru-werks OBLIGATORY,   "Plant Code - MANDATORY
                s_matnr FOR mara-matnr,               "Material Code - range
                s_datum FOR afru-ersda OBLIGATORY,    "Date - MANDATORY
                s_arbpl FOR afru-arbpl.               "Workcenter

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.

PARAMETERS: p_r1 RADIOBUTTON GROUP rb1 DEFAULT 'X' USER-COMMAND rbc, "Moulding Report
            p_r2 RADIOBUTTON GROUP rb1,                              "SFG and FG Production
            p_r3 RADIOBUTTON GROUP rb1.                              "Monthly Summary

SELECTION-SCREEN END OF BLOCK b2.

*&---------------------------------------------------------------------*
*& Text symbols (maintain via SE38 Goto > Text Elements):
*&   001 Selection Criteria
*&   002 Report Type
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& AT SELECTION-SCREEN - basic validation
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN.
  IF s_werks[] IS INITIAL.
    MESSAGE 'Plant is mandatory' TYPE 'E'.
  ENDIF.
  IF s_datum[] IS INITIAL.
    MESSAGE 'Date range is mandatory' TYPE 'E'.
  ENDIF.

*&---------------------------------------------------------------------*
*& START-OF-SELECTION
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  CASE 'X'.
    WHEN p_r1.
      PERFORM build_production_data USING space. "all routing types
    WHEN p_r2.
      PERFORM build_production_data USING '2'.   "PLNTY = '2' only (FS: SFG/FG)
    WHEN p_r3.
      PERFORM build_production_data USING space.
      PERFORM build_monthly_summary.
  ENDCASE.

*&---------------------------------------------------------------------*
*& END-OF-SELECTION - render ALV
*&---------------------------------------------------------------------*
END-OF-SELECTION.

  IF p_r3 = 'X'.
    PERFORM display_alv_monthly.
  ELSE.
    PERFORM display_alv_detail.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  BUILD_PRODUCTION_DATA
*&---------------------------------------------------------------------*
*&  Core extraction & derivation logic, per FS "Detailed FS" tab.
*&  IV_PLNTY_FILTER = '2' restricts routing type for the SFG/FG view
*&  (Radio Button 2); blank = no restriction (Moulding view / Radio 1).
*&---------------------------------------------------------------------*
FORM build_production_data USING iv_plnty_filter TYPE plnty.

  DATA: lt_afru  TYPE STANDARD TABLE OF afru,
        ls_afru  TYPE afru,
        ls_caufv TYPE caufv,
        ls_afpo  TYPE afpo,
        ls_afko  TYPE afko,
        ls_mara  TYPE mara,
        ls_makt  TYPE makt,
        ls_crhd  TYPE crhd,
        ls_crtx  TYPE crtx,
        lv_excluded TYPE abap_bool.

  DATA: lv_bmsch TYPE caufv_routing-bmsch, "routing base qty (BAPI return)
        lv_vge04 TYPE caufv_routing-vge04, "routing machine time (BAPI return)
        lv_val1  TYPE p LENGTH 13 DECIMALS 5,
        lv_val2  TYPE p LENGTH 13 DECIMALS 5,
        lv_rejected TYPE p LENGTH 13 DECIMALS 3.

  REFRESH gt_output.

* Step 1/2: Plant + Date from selection screen against AFRU-WERKS / ERSDA
  SELECT * FROM afru INTO TABLE lt_afru
    WHERE werks IN s_werks
      AND ersda IN s_datum
      AND arbpl IN s_arbpl.

  LOOP AT lt_afru INTO ls_afru.

    CLEAR gs_output.

*   --- Exclude workcenters listed in ZPP_WORKCENTER_EXCLUDE ---
*   Pass AFRU-ARBID to CRHD-OBJID, take CRHD-ARBPL; check against
*   ZPP_WORKCENTER_EXCLUDE-ARBPL / WERKS. If found, skip this record.
    CLEAR ls_crhd.
    SELECT SINGLE * FROM crhd INTO ls_crhd
      WHERE objid = ls_afru-arbid.

    lv_excluded = abap_false.
*   SELECT SINGLE @abap_true FROM zpp_workcenter_exclude INTO @lv_excluded
*     WHERE arbpl = @ls_crhd-arbpl
*       AND werks = @ls_afru-werks.
    IF lv_excluded = abap_true.
      CONTINUE.
    ENDIF.

*   --- Order header (CAUFV) via AFRU-AUFNR ---
    CLEAR ls_caufv.
    SELECT SINGLE * FROM caufv INTO ls_caufv
      WHERE aufnr = ls_afru-aufnr.

*   Radio Button 2 restriction: only routing type PLNTY = '2'
    IF iv_plnty_filter IS NOT INITIAL AND ls_caufv-plnty <> iv_plnty_filter.
      CONTINUE.
    ENDIF.

*   --- Material master / description ---
    CLEAR ls_mara.
    SELECT SINGLE * FROM mara INTO ls_mara
      WHERE matnr = ls_caufv-plnbez.

    CLEAR ls_makt.
    SELECT SINGLE * FROM makt INTO ls_makt
      WHERE matnr = ls_caufv-plnbez
        AND spras = sy-langu.

*   --- Workcenter description ---
    CLEAR ls_crtx.
    SELECT SINGLE * FROM crtx INTO ls_crtx
      WHERE objid = ls_crhd-objid
        AND spras = sy-langu.

*   --- Order item (production version) ---
    CLEAR ls_afpo.
    SELECT SINGLE * FROM afpo INTO ls_afpo
      WHERE aufnr = ls_caufv-aufnr.

*   --- Order dates ---
    CLEAR ls_afko.
    SELECT SINGLE * FROM afko INTO ls_afko
      WHERE aufnr = ls_caufv-aufnr.

*   --- Header fields ---
    gs_output-werks       = ls_afru-werks.
    gs_output-datum       = ls_afru-ersda.
    gs_output-matnr       = ls_caufv-plnbez.
    gs_output-maktx       = ls_makt-maktx.
    gs_output-arbpl       = ls_crhd-arbpl.
    gs_output-ktext       = ls_crtx-ktext.
    gs_output-aufnr       = ls_afru-aufnr.
    gs_output-auart       = ls_caufv-auart.
    gs_output-matkl       = ls_mara-matkl.
    gs_output-ntgew       = ls_mara-ntgew.
    gs_output-gamng       = ls_caufv-gamng.
    gs_output-gmnga       = ls_afru-gmnga.
    gs_output-meins       = ls_afru-meins.
    gs_output-verid       = ls_afpo-verid.
    gs_output-stlal       = ls_caufv-stlal.
    gs_output-order_start_date = ls_afko-gltrp.
    gs_output-order_end_date   = ls_afko-gstrp.
    gs_output-vornr       = ls_afru-vornr.
    gs_output-cancelled   = ls_afru-stzhl.
    gs_output-reversed    = ls_afru-stokz.
    gs_output-rueck       = ls_afru-rueck.
    gs_output-rmzhl       = ls_afru-rmzhl.
    gs_output-setup_machine = ls_afru-ism02.
    gs_output-start_time  = ls_afru-isdz.
    gs_output-end_time    = ls_afru-iedz.

*   --- Total tonnage = Confirmed Qty * Net Weight / 1000 (per FS) ---
    gs_output-tot_tonnage = ( gs_output-gmnga * gs_output-ntgew ) / 1000.

*   --- Running hours = end time - start time, expressed in hours ---
    gs_output-running_hrs = ( ls_afru-iedz - ls_afru-isdz ) / 3600.

*   --- Rejected Qty = sum of AFRU-ZZQUAN1 .. ZZQUAN6 ---
*   NOTE: ZZQUAN1-6 are assumed custom append fields on AFRU per the FS;
*   confirm exact field names in the target system before activation.
    lv_rejected = 0.
*   lv_rejected = ls_afru-zzquan1 + ls_afru-zzquan2 + ls_afru-zzquan3
*               + ls_afru-zzquan4 + ls_afru-zzquan5 + ls_afru-zzquan6.
    gs_output-rejected_qty = lv_rejected.

*   --- Breakdown time = AFRU-ISERH / 60 (minutes -> hours) ---
    gs_output-breakdown_time = ls_afru-iserh / 60.

*   --- STD QTY: call BAPI to read routing base qty / machine time ---
*   FS logic (as literally stated) is two derivations multiplied
*   together:
*     val1 = BMSCH / VGE04                       (base qty per machine time unit)
*     val2 = Order Qty * VGE04 / BMSCH            (machine time per order qty)
*     STD QTY = val1 * val2
*   Multiplying these two together algebraically returns Order Qty,
*   which looks like a documentation error in the FS rather than an
*   intentional formula - flagged here rather than silently "corrected".
*   Implemented literally; raise with functional consultant before go-live.
    CALL FUNCTION 'CARO_ROUTING_READ'
      EXPORTING
        plnty      = ls_caufv-plnty
        plnnr      = ls_caufv-plnnr
        plnal      = ls_caufv-plnal
        aennr      = space
      IMPORTING
        ex_bmsch   = lv_bmsch
        ex_vge04   = lv_vge04
      EXCEPTIONS
        OTHERS     = 1.

    IF sy-subrc = 0 AND lv_vge04 <> 0 AND lv_bmsch <> 0.
      lv_val1 = lv_bmsch / lv_vge04.
      lv_val2 = ( gs_output-gamng * lv_vge04 ) / lv_bmsch.
      gs_output-std_qty = lv_val1 * lv_val2.

*     --- Manhours = (ISM02 + ISM04) / 60 ---
      gs_output-manhours = ( ls_afru-ism02 + ls_afru-ism04 ) / 60.

*     --- Std Man Hours = Order Qty * ISM04 / BMSCH ---
      gs_output-std_manhours = ( gs_output-gamng * ls_afru-ism04 ) / lv_bmsch.

*     --- P% = Actual PC/min / Std PC/min ---
*         Actual PC/min = Confirmed Qty / ISM04 (confirmed machine time)
*         Std PC/min    = BMSCH / VGE04
      IF ls_afru-ism04 <> 0.
        gs_output-p_pct = ( gs_output-gmnga / ls_afru-ism04 ) / lv_val1.
      ENDIF.
    ENDIF.

*   --- A% = (Runtime - Breakdown) / Runtime ---
    IF gs_output-running_hrs <> 0.
      gs_output-a_pct = ( gs_output-running_hrs - gs_output-breakdown_time )
                        / gs_output-running_hrs.
    ENDIF.

*   --- Q% = Confirmed Qty / (Confirmed Qty + Rejected Qty) ---
    IF ( gs_output-gmnga + gs_output-rejected_qty ) <> 0.
      gs_output-q_pct = gs_output-gmnga
                        / ( gs_output-gmnga + gs_output-rejected_qty ).
    ENDIF.

*   --- OEE% = A% * Q% * P% ---
    gs_output-oee_pct = gs_output-a_pct * gs_output-q_pct * gs_output-p_pct.

*   --- Capacity Utilization % = Confirmed Qty / Std Qty ---
    IF gs_output-std_qty <> 0.
      gs_output-cap_util_pct = gs_output-gmnga / gs_output-std_qty.
    ENDIF.

    APPEND gs_output TO gt_output.

  ENDLOOP.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  BUILD_MONTHLY_SUMMARY
*&---------------------------------------------------------------------*
*&  Radio Button 3: "Show workcenter wise cumulative sum of Capacity
*&  Utilization" (per FS Detailed FS tab).
*&---------------------------------------------------------------------*
FORM build_monthly_summary.

  DATA: ls_summary LIKE LINE OF gt_monthly_summary,
        lv_month   TYPE spmon.

  REFRESH gt_monthly_summary.

  LOOP AT gt_output INTO gs_output.

    lv_month = gs_output-datum(6). "YYYYMM

    READ TABLE gt_monthly_summary INTO ls_summary
      WITH KEY arbpl = gs_output-arbpl
               month = lv_month.

    IF sy-subrc = 0.
      ls_summary-cap_util_sum = ls_summary-cap_util_sum
                                 + gs_output-cap_util_pct.
      MODIFY gt_monthly_summary FROM ls_summary
        INDEX sy-tabix.
    ELSE.
      CLEAR ls_summary.
      ls_summary-arbpl        = gs_output-arbpl.
      ls_summary-month        = lv_month.
      ls_summary-cap_util_sum = gs_output-cap_util_pct.
      APPEND ls_summary TO gt_monthly_summary.
    ENDIF.

  ENDLOOP.

  SORT gt_monthly_summary BY arbpl month.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV_DETAIL
*&---------------------------------------------------------------------*
FORM display_alv_detail.

  DATA: lo_salv TYPE REF TO cl_salv_table.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_salv
        CHANGING  t_table      = gt_output ).

      lo_salv->get_functions( )->set_all( abap_true ).
      lo_salv->get_columns( )->set_optimize( abap_true ).
      lo_salv->display( ).

    CATCH cx_salv_msg.
      MESSAGE 'Error displaying ALV output' TYPE 'E'.
  ENDTRY.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_ALV_MONTHLY
*&---------------------------------------------------------------------*
FORM display_alv_monthly.

  DATA: lo_salv TYPE REF TO cl_salv_table.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_salv
        CHANGING  t_table      = gt_monthly_summary ).

      lo_salv->get_functions( )->set_all( abap_true ).
      lo_salv->get_columns( )->set_optimize( abap_true ).
      lo_salv->display( ).

    CATCH cx_salv_msg.
      MESSAGE 'Error displaying ALV output' TYPE 'E'.
  ENDTRY.

ENDFORM.
