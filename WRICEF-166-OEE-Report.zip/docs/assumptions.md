# Assumptions & Open Questions — WRICEF 166 (v2)

Most items from v1 have been resolved in code. What's left below still
needs sign-off from the functional consultant / your security and Basis
teams before this program is transported beyond a dev/unit-test client.

## Resolved in v2 (see the report's header comment for detail)

- Workcenter exclusion (`ZPP_WORKCENTER_EXCLUDE`) and rejected-qty
  (`AFRU-ZZQUAN1..6`) logic are now active (uncommented). **The assumed
  field names are unchanged from v1 - confirm them in SE11 before
  transport** (see items 2 and 3 below - "resolved" means "wired up",
  not "field names verified against your system").
- BMSCH/VGE04 are now resolved via `PLKO` (to translate `CAUFV-PLNAL`
  into the internal group counter `ZAEHL`) + `PLPO` filtered by that
  counter and `AFRU-VORNR`, so the value used is tied to the correct
  routing alternative and the confirmed operation. v1's BAPI call never
  passed `VORNR`.
- MANHOURS no longer depends on the routing lookup succeeding.
- A%, Q%, P%, OEE%, and Capacity Utilization % are now on a 0-100 scale
  (v1 stored raw 0-1 ratios with no `*100`).
- RUNNING HRS now combines `ISDD+ISDZ` / `IEDD+IEDZ` into timestamps
  before subtracting, so a confirmation spanning midnight no longer
  produces a negative value.
- Added `AFRU-ISDD` / `AFRU-IEDD` as their own Start Date / End Date
  columns (the FS lists these separately from Start/End Time; v1 only
  had the time columns).
- UOM now sourced from `AFRU-GMEIN` — standard AFRU does not carry a
  `MEINS` field; `GMEIN` is the field tied to `GMNGA`. **Verify this
  against your system's DDIC** in case a custom append adds `MEINS`.
- Data retrieval is now bulk (`FOR ALL ENTRIES`) instead of one
  `SELECT SINGLE` (and one BAPI call) per confirmation line.
- Added an `AUTHORITY-CHECK` on Plant. **Confirm the correct
  authorization object with your security team** - `M_MATE_WRK` /
  `ACTVT 03` is a placeholder, not a confirmed requirement.

## Still open

1. **STD QTY formula ambiguity.** The FS states two derivations and says
   to multiply them:
   - `val1 = BMSCH / VGE04`
   - `val2 = Order Qty × VGE04 / BMSCH`
   - `STD QTY = val1 × val2`

   Algebraically, `val1 × val2` simplifies to `Order Qty` regardless of
   the routing values, which suggests the FS intends something else
   (perhaps `val1 × Order Qty`, i.e. the standard rate applied to the
   order quantity). Implemented literally in the code, with a comment
   at the point of calculation. **Please confirm intended formula
   before go-live** — this is a business-logic decision, not something
   that should be silently "corrected" in code.

2. **ZPP_WORKCENTER_EXCLUDE structure.** The FS names this Z-table but
   doesn't give its field list. The exclusion SELECT is now active,
   using the assumed field names `WERKS` + `ARBPL`. If your table uses
   different field names, only the `TYPES ... ty_excl` block and the
   SELECT's field list need to change.

3. **AFRU-ZZQUAN1 through ZZQUAN6.** Assumed to be custom append/include
   fields on AFRU holding rejection-reason-coded quantities. The sum is
   now active. If these fields don't exist under these names in your
   system, the program will fail to activate — confirm in SE11 first.

4. **Breakdown time unit.** FS says "Break time when user enter in CO11N"
   for `BREAKDOWN TIME`, mapped to `AFRU-ISERH`. Divided by 60 here
   assuming `ISERH` is stored in minutes; confirm the actual unit in
   your system (some configurations store it in seconds).

5. **Monthly Summary (R3) granularity.** The FS only says "Show
   workcenter wise cumulative sum of Capacity utilization" without
   specifying the time bucket. Implemented as calendar month (`YYYYMM`
   from confirmation date) — confirm this matches the intended "Monthly
   summary" behavior.

6. **Order dates.** FS lists `Order Start date` = `AFKO-GLTRP` and
   `Order end Date` = `AFKO-GSTRP`. Note these are basic-start/basic-finish
   fields in AFKO; naming in the FS ("start"/"end") is reversed relative to
   SAP's usual GSTRP=start / GLTRP=finish convention — mapped literally per
   the FS text, please double check against your actual requirement.

7. **Text elements** (001 "Selection Criteria", 002 "Report Type") must be
   maintained in SE38 before activation — placeholder names only in source.

8. **Not yet syntax-checked or unit-tested against a live system.** Run
   SE38 syntax check / ATC, and verify every assumed field name (in
   particular the ones flagged above) against your system's DDIC before
   transporting beyond a dev/unit-test client. This is a code review /
   correction pass, not a substitute for testing against real data.
