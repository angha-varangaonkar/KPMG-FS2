# WRICEF 166 – Overall Production Report (OEE in Adhesive)

ABAP implementation generated from the Functional Specification
`Copy of WRICEF ID 166-Overall production report for SFG FG and moulding sperately.xlsx`.

## Contents

- `zsrc/ZPP_OEE_ADHESIVE_REPORT.abap` – main report program (v2 - see header comment for what changed and why)
- `docs/field_mapping.md` – field-by-field source-to-target mapping, extracted from the "Detailed FS" tab
- `docs/assumptions.md` – remaining assumptions and open questions to confirm with the functional consultant before transport

## What the report does

Single selection screen with three mutually exclusive radio-button views:

1. **Moulding Report** – all confirmations, all routing types
2. **SFG and FG Production** – same logic, restricted to routing type `PLNTY = '2'`
3. **Monthly Summary** – workcenter-wise cumulative Capacity Utilization %

Selection fields: Plant (mandatory, with an authorization check), Material (range),
Date (mandatory), Workcenter.

Key calculated fields: Total Tonnage, STD Qty, Manhours, Running Hours, A% / Q% / P%,
OEE% (`A% × Q% × P%`), Rejected Qty, Breakdown Time, Capacity Utilization %, Std Man Hours.

## v2 changes (code review fixes)

This version corrects a round of issues found reviewing v1 against the FS:
bulk (`FOR ALL ENTRIES`) data retrieval instead of a `SELECT SINGLE`/BAPI call
per confirmation line; routing base qty/machine time (`BMSCH`/`VGE04`) resolved
via `PLKO`+`PLPO` so the correct routing alternative *and* operation are used;
Manhours no longer skipped when the routing lookup fails; percentages expressed
on a 0-100 scale; Running Hours computed from full date+time timestamps so
overnight confirmations don't go negative; Start Date/End Date columns added;
UOM sourced from the field that actually exists on AFRU (`GMEIN`, not `MEINS`);
workcenter-exclusion and rejected-qty logic activated; a Plant authorization
check added. Full detail is in the report's header comment and in
`docs/assumptions.md`.

## Before deploying

This is still a **code-level** fix, not a system-tested one. Before transport:

1. Confirm the `ZPP_WORKCENTER_EXCLUDE` table's actual field names in SE11 (assumed `WERKS`+`ARBPL`).
2. Confirm `AFRU-ZZQUAN1..ZZQUAN6` exist in your system under these names.
3. Get the functional consultant to confirm the intended STD QTY formula (the FS's own
   two-step formula algebraically cancels out to Order Qty — flagged inline, not silently changed).
4. Confirm the `ISERH` (breakdown time) unit, the R3 monthly-bucket granularity, and the
   `AFKO-GLTRP`/`GSTRP` start/end labeling — all flagged as FS ambiguities in `docs/assumptions.md`.
5. Confirm the Plant authorization object with your security team (`M_MATE_WRK`/`ACTVT 03` is a placeholder).
6. Add text elements (001, 002) via SE38 → Goto → Text Elements.
7. Run SE38 syntax check / ATC and unit-test against real confirmations before wider rollout.

See `docs/assumptions.md` for the full list.
