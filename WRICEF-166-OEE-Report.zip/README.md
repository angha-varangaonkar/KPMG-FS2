# WRICEF 166 – Overall Production Report (OEE in Adhesive)

ABAP implementation generated from the Functional Specification
`Copy of WRICEF ID 166-Overall production report for SFG FG and moulding sperately.xlsx`.

## Contents

- `zsrc/ZPP_OEE_ADHESIVE_REPORT.abap` – main report program
- `docs/field_mapping.md` – field-by-field source-to-target mapping, extracted from the "Detailed FS" tab
- `docs/assumptions.md` – assumptions and open questions to confirm with the functional consultant before transport

## What the report does

Single selection screen with three mutually exclusive radio-button views:

1. **Moulding Report** – all confirmations, all routing types
2. **SFG and FG Production** – same logic, restricted to routing type `PLNTY = '2'`
3. **Monthly Summary** – workcenter-wise cumulative Capacity Utilization %

Selection fields: Plant (mandatory), Material (range), Date (mandatory), Workcenter.

Key calculated fields: Total Tonnage, STD Qty, Manhours, Running Hours, A% / Q% / P%,
OEE% (`A% × Q% × P%`), Rejected Qty, Breakdown Time, Capacity Utilization %, Std Man Hours.

## Before deploying

This code is a direct, literal translation of the FS logic. It has **not** been tested
against a live SAP system and needs the following before it's transportable:

1. Confirm the `ZPP_WORKCENTER_EXCLUDE` table structure and un-comment the exclusion SELECT.
2. Confirm the `AFRU-ZZQUAN1..ZZQUAN6` custom append fields exist and un-comment the rejected-qty sum.
3. Resolve the STD QTY formula ambiguity flagged inline in the code (the FS's two stated
   derivations for STD QTY algebraically cancel out to Order Qty — likely a documentation
   error, implemented literally here rather than silently corrected).
4. Add text elements (001, 002) via SE38 → Goto → Text Elements.
5. Unit test formulas against a handful of real confirmations before wider rollout, per the
   xlsx skill's own guidance for any formula-bearing deliverable.

See `docs/assumptions.md` for the full list.
