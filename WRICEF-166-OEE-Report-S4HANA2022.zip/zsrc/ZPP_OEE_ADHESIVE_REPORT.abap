*&---------------------------------------------------------------------*
*& Report ZPP_OEE_ADHESIVE_REPORT
*&---------------------------------------------------------------------*
*& WRICEF ID  : 166
*& Object Name: Report for OEE in Adhesive
*& Module     : PP
*& Target     : S/4HANA (modern Open SQL, no obsolete statements -
*&               no TABLES, host variables via @, comma field lists).
*& Version    : 8
*&
*& Purpose:
*&   Single selection-screen driven report offering three mutually
*&   exclusive output views (radio buttons), per the FS:
*&     R1 - Moulding Report            (all routing types)
*&     R2 - SFG and FG Production      (routing type PLNTY = '2' only)
*&     R3 - Monthly Summary            (workcenter-wise cumulative
*&                                      Capacity Utilization %, no
*&                                      calendar-month bucket - see
*&                                      docs/assumptions.md #5)
*&
*& Design notes for this version:
*&   - All TYPES are declared first, in one block, followed by all
*&     DATA in a second block - no inline DATA(...) declarations
*&     scattered through the logic, so every variable's type is
*&     visible up front before it's ever used.
*&   - All bulk data retrieval (AFRU, CAUFV, CRHD, ZPP_WORK_CENTER,
*&     CRTX, MARA, MAKT, AFPO, AFKO, PLKO, PLPO) happens in
*&     GET_DATA, once, before any loop runs. PROCESS_DATA's loop over
*&     confirmations contains no SELECT statements at all - only
*&     READ TABLE ... BINARY SEARCH against the already-sorted
*&     internal tables built by GET_DATA.
*&   - Every READ TABLE and CALL FUNCTION is followed by an explicit
*&     SY-SUBRC check; nothing is assumed to have succeeded silently.
*&
*& Business logic confirmed with the functional team (see
*& docs/assumptions.md for full detail):
*&   - STD QTY = (BMSCH/VGE04) x (Order Qty x VGE04/BMSCH), resolved
*&     via PLKO (PLNAL -> internal counter ZAEHL) + PLPO filtered by
*&     that counter and the confirmed operation (AFRU-VORNR).
*&   - Breakdown time (AFRU-ISERH) is converted to hours using its
*&     own unit field AFRU-ZEIER (data element DZEIER) via
*&     UNIT_CONVERSION_SIMPLE, not a hardcoded /60.
*&   - AFKO-GLTRP = Order Start Date, AFKO-GSTRP = Order End Date
*&     (as the FS literally states, even though this is the reverse
*&     of SAP's usual GSTRP=start/GLTRP=finish convention).
*&   - Workcenter exclusion: ZPP_WORK_CENTER-LOEKZ = 'X' for that
*&     WERKS+ARBPL (there is no ZPP_WORKCENTER_EXCLUDE table).
*&   - Rejected Qty = sum of AFRU-ZZRQUAN1..ZZRQUAN6 ("Reusable Scrap
*&     Quantity 1-6").
*&   - R3 groups by WERKS+ARBPL only, no calendar-month bucket.
*&   - S_WERKS/S_DATUM are OBLIGATORY on the SELECT-OPTIONS, so no
*&     manual "is initial" re-check is done in AT SELECTION-SCREEN.
*&
*& Still open (see docs/assumptions.md for the full writeup):
*&   - Plant AUTHORITY-CHECK - not implemented; confirm the correct
*&     object with your security team (check for an existing custom
*&     Z object first, or trace CO11N/COOIS via STAUTHTRACE/SU24),
*&     then add an AUTHORITY-CHECK in AT SELECTION-SCREEN.
*&   - Not yet syntax-checked or unit-tested against a live system -
*&     run SE38 syntax check / ATC and verify AFRU-ZEIER exists under
*&     that name in your system before transport.
*&---------------------------------------------------------------------*
REPORT zpp_oee_adhesive_report.

*&---------------------------------------------------------------------*
*& TYPES - every structure and table type used by this report,
*& declared once, up front.
*&---------------------------------------------------------------------*
TYPES:
  "Output line - one row per confirmation (R1/R2)
  BEGIN OF ty_output,
    werks            TYPE afru-werks,           "Plant Code
    datum            TYPE afru-ersda,           "Confirmation entry date
    matnr            TYPE mara-matnr,           "Material Code
    maktx            TYPE makt-maktx,           "Description
    arbpl            TYPE crhd-arbpl,           "Workcentre Name
    ktext            TYPE crtx-ktext,           "Workcenter Description
    aufnr            TYPE afru-aufnr,           "Production Order
    auart            TYPE caufv-auart,          "Order Type
    matkl            TYPE mara-matkl,           "Material Group
    ntgew            TYPE mara-ntgew,           "Net Weight
    gamng            TYPE caufv-gamng,          "Order Qty
    gmnga            TYPE afru-gmnga,           "Confirm Qty
    meins            TYPE afru-gmein,           "UOM (AFRU-GMEIN)
    tot_tonnage      TYPE p LENGTH 13 DECIMALS 3, "Total Tonnage
    std_qty          TYPE p LENGTH 13 DECIMALS 3, "Std Qty
    manhours         TYPE p LENGTH 13 DECIMALS 3, "Manhours
    start_date       TYPE afru-isdd,            "Start Date
    end_date         TYPE afru-iedd,            "End Date
    start_time       TYPE afru-isdz,            "Start Time
    end_time         TYPE afru-iedz,            "End Time
    running_hrs      TYPE p LENGTH 9 DECIMALS 4,  "Running Hrs
    a_pct            TYPE p LENGTH 7 DECIMALS 2,  "Availability %
    q_pct            TYPE p LENGTH 7 DECIMALS 2,  "Quality %
    p_pct            TYPE p LENGTH 7 DECIMALS 2,  "Performance %
    oee_pct          TYPE p LENGTH 7 DECIMALS 2,  "OEE %
    rejected_qty     TYPE p LENGTH 13 DECIMALS 3, "Rejected Qty
    breakdown_time   TYPE p LENGTH 9 DECIMALS 4,  "Breakdown Time (hrs)
    cap_util_pct     TYPE p LENGTH 7 DECIMALS 2,  "Capacity Utilization %
    verid            TYPE afpo-verid,          "Production Version
    stlal            TYPE caufv-stlal,         "Alternative BOM
    order_start_date TYPE afko-gltrp,          "Order Start Date
    order_end_date   TYPE afko-gstrp,          "Order End Date
    vornr            TYPE afru-vornr,          "Phase / Operation
    cancelled        TYPE afru-stzhl,          "Cancelled
    reversed         TYPE afru-stokz,          "Reversed
    rueck            TYPE afru-rueck,          "Confirmation Number
    rmzhl            TYPE afru-rmzhl,          "Confirmation Counter
    setup_machine    TYPE afru-ism02,          "Setup Machine (confirmed)
    std_manhours     TYPE p LENGTH 13 DECIMALS 3, "Std Man Hours
  END OF ty_output,

  "R3 - workcenter-wise cumulative Capacity Utilization % (no month bucket)
  BEGIN OF ty_summary,
    werks        TYPE afru-werks,
    arbpl        TYPE crhd-arbpl,
    ktext        TYPE crtx-ktext,
    cap_util_sum TYPE p LENGTH 9 DECIMALS 4,
  END OF ty_summary,

  "Bulk-retrieval working types (GET_DATA populates these; PROCESS_DATA
  "only reads them via BINARY SEARCH - no SELECT in the confirmation loop)
  BEGIN OF ty_afru,
    werks    TYPE afru-werks,
    ersda    TYPE afru-ersda,
    aufnr    TYPE afru-aufnr,
    arbid    TYPE afru-arbid,
    rueck    TYPE afru-rueck,
    rmzhl    TYPE afru-rmzhl,
    vornr    TYPE afru-vornr,
    gmnga    TYPE afru-gmnga,
    gmein    TYPE afru-gmein,
    ism02    TYPE afru-ism02,
    ism04    TYPE afru-ism04,
    isdd     TYPE afru-isdd,
    iedd     TYPE afru-iedd,
    isdz     TYPE afru-isdz,
    iedz     TYPE afru-iedz,
    iserh    TYPE afru-iserh,
    zeier    TYPE afru-zeier,     "Unit for ISERH (data element DZEIER)
    zzrquan1 TYPE afru-zzrquan1,
    zzrquan2 TYPE afru-zzrquan2,
    zzrquan3 TYPE afru-zzrquan3,
    zzrquan4 TYPE afru-zzrquan4,
    zzrquan5 TYPE afru-zzrquan5,
    zzrquan6 TYPE afru-zzrquan6,
    stzhl    TYPE afru-stzhl,
    stokz    TYPE afru-stokz,
  END OF ty_afru,

  BEGIN OF ty_caufv,
    aufnr  TYPE caufv-aufnr,
    plnbez TYPE caufv-plnbez,
    gamng  TYPE caufv-gamng,
    auart  TYPE caufv-auart,
    plnty  TYPE caufv-plnty,
    plnnr  TYPE caufv-plnnr,
    plnal  TYPE caufv-plnal,
    stlal  TYPE caufv-stlal,
  END OF ty_caufv,

  BEGIN OF ty_crhd,
    objid TYPE crhd-objid,
    arbpl TYPE crhd-arbpl,
    werks TYPE crhd-werks,
  END OF ty_crhd,

  "Workcenter exclusion - ZPP_WORK_CENTER, not ZPP_WORKCENTER_EXCLUDE
  "(that table doesn't exist); excluded when LOEKZ = 'X'
  BEGIN OF ty_excl,
    werks TYPE zpp_work_center-werks,
    arbpl TYPE zpp_work_center-arbpl,
  END OF ty_excl,

  BEGIN OF ty_crtx,
    objid TYPE crtx-objid,
    ktext TYPE crtx-ktext,
  END OF ty_crtx,

  BEGIN OF ty_mara,
    matnr TYPE mara-matnr,
    matkl TYPE mara-matkl,
    ntgew TYPE mara-ntgew,
  END OF ty_mara,

  BEGIN OF ty_makt,
    matnr TYPE makt-matnr,
    maktx TYPE makt-maktx,
  END OF ty_makt,

  BEGIN OF ty_afpo,
    aufnr TYPE afpo-aufnr,
    verid TYPE afpo-verid,
  END OF ty_afpo,

  BEGIN OF ty_afko,
    aufnr TYPE afko-aufnr,
    gstrp TYPE afko-gstrp,
    gltrp TYPE afko-gltrp,
  END OF ty_afko,

  "Routing: PLNAL -> internal group counter ZAEHL (PLKO), then PLPO
  "filtered by ZAEHL + the confirmed operation (AFRU-VORNR)
  BEGIN OF ty_plko,
    plnty TYPE plko-plnty,
    plnnr TYPE plko-plnnr,
    plnal TYPE plko-plnal,
    zaehl TYPE plko-zaehl,
  END OF ty_plko,

  BEGIN OF ty_plpo,
    plnty TYPE plpo-plnty,
    plnnr TYPE plpo-plnnr,
    zaehl TYPE plpo-zaehl,
    vornr TYPE plpo-vornr,
    bmsch TYPE plpo-bmsch,
    vge04 TYPE plpo-vge04,
  END OF ty_plpo.

*&---------------------------------------------------------------------*
*& DATA - every variable used by this report, declared once, up
*& front, after the TYPES section above.
*&---------------------------------------------------------------------*
DATA:
  "Selection-screen helper variables (so SELECT-OPTIONS can reference
  "a DDIC type directly, without the obsolete TABLES statement)
  gv_werks TYPE afru-werks,
  gv_matnr TYPE mara-matnr,
  gv_ersda TYPE afru-ersda,
  gv_arbpl TYPE afru-arbpl,

  "Final output tables (filled by PROCESS_DATA / BUILD_SUMMARY,
  "displayed by DISPLAY_DETAIL / DISPLAY_SUMMARY) - each internal
  "table is declared directly as STANDARD TABLE OF the structure
  "type declared above, and each work area (in the FORMs below) is
  "declared as TYPE of that same structure.
  gt_output  TYPE STANDARD TABLE OF ty_output,
  gt_summary TYPE STANDARD TABLE OF ty_summary,

  "Bulk-retrieval working tables, populated once by GET_DATA
  gt_afru  TYPE STANDARD TABLE OF ty_afru,
  gt_caufv TYPE STANDARD TABLE OF ty_caufv,
  gt_crhd  TYPE STANDARD TABLE OF ty_crhd,
  gt_excl  TYPE STANDARD TABLE OF ty_excl,
  gt_crtx  TYPE STANDARD TABLE OF ty_crtx,
  gt_mara  TYPE STANDARD TABLE OF ty_mara,
  gt_makt  TYPE STANDARD TABLE OF ty_makt,
  gt_afpo  TYPE STANDARD TABLE OF ty_afpo,
  gt_afko  TYPE STANDARD TABLE OF ty_afko,
  gt_plko  TYPE STANDARD TABLE OF ty_plko,
  gt_plpo  TYPE STANDARD TABLE OF ty_plpo.

*&---------------------------------------------------------------------*
*& Selection Screen (per FS "Selection Screen" block)
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

SELECT-OPTIONS: s_werks FOR gv_werks OBLIGATORY,   "Plant Code - MANDATORY
                s_matnr FOR gv_matnr,               "Material Code - range
                s_datum FOR gv_ersda OBLIGATORY,    "Date - MANDATORY
                s_arbpl FOR gv_arbpl.               "Workcenter

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.

PARAMETERS: p_r1 RADIOBUTTON GROUP rb1 DEFAULT 'X' USER-COMMAND rbc, "Moulding Report
            p_r2 RADIOBUTTON GROUP rb1,                              "SFG and FG Production
            p_r3 RADIOBUTTON GROUP rb1.                              "Monthly Summary

SELECTION-SCREEN END OF BLOCK b2.

*&---------------------------------------------------------------------*
*& Text symbols (maintain via SE38 Goto > Text Elements):
*&   001 Selection Criteria
*&   002 Report Type
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& AT SELECTION-SCREEN
*&---------------------------------------------------------------------*
*& S_WERKS and S_DATUM are already OBLIGATORY on their SELECT-OPTIONS,
*& so the selection-screen framework already blocks execution and
*& shows its own error if either is left empty - no manual IS INITIAL
*& re-check is needed here.
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN.

* No AUTHORITY-CHECK on Plant is implemented here. The FS marks Plant
* as a mandatory authorization object, but the correct object/field to
* check depends on your system's authorization concept - confirm it
* with your security team (see docs/assumptions.md) and add an
* AUTHORITY-CHECK in this event block before transport.

*&---------------------------------------------------------------------*
*& START-OF-SELECTION
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  PERFORM get_data.

  CASE 'X'.
    WHEN p_r1.
      PERFORM process_data USING space.        "all routing types
    WHEN p_r2.
      PERFORM process_data USING '2'.          "PLNTY = '2' only (FS: SFG/FG)
    WHEN p_r3.
      PERFORM process_data USING space.
      PERFORM build_summary.
  ENDCASE.

*&---------------------------------------------------------------------*
*& END-OF-SELECTION - render ALV
*&---------------------------------------------------------------------*
END-OF-SELECTION.

  IF p_r3 = 'X'.
    PERFORM display_summary.
  ELSE.
    PERFORM display_detail.
  ENDIF.

*&---------------------------------------------------------------------*
*&      Form  GET_DATA
*&---------------------------------------------------------------------*
*&  Bulk retrieval only - every SELECT the report needs runs exactly
*&  once, here, before PROCESS_DATA's confirmation loop. No SELECT
*&  statement appears inside any loop in this program.
*&---------------------------------------------------------------------*
FORM get_data.

  SELECT werks, ersda, aufnr, arbid, rueck, rmzhl, vornr, gmnga, gmein,
         ism02, ism04, isdd, iedd, isdz, iedz, iserh, zeier,
         zzrquan1, zzrquan2, zzrquan3, zzrquan4, zzrquan5, zzrquan6,
         stzhl, stokz
    FROM afru
    WHERE werks IN @s_werks
      AND ersda IN @s_datum
      AND arbpl IN @s_arbpl
    INTO CORRESPONDING FIELDS OF TABLE @gt_afru.
  IF sy-subrc <> 0.
    MESSAGE 'No confirmations found for the selection' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  SELECT aufnr, plnbez, gamng, auart, plnty, plnnr, plnal, stlal
    FROM caufv
    FOR ALL ENTRIES IN @gt_afru
    WHERE aufnr = @gt_afru-aufnr
    INTO CORRESPONDING FIELDS OF TABLE @gt_caufv.
  IF sy-subrc <> 0.
    MESSAGE 'No production orders found for the confirmations' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  IF s_matnr[] IS NOT INITIAL.
    DELETE gt_caufv WHERE plnbez NOT IN s_matnr.
  ENDIF.

  IF gt_caufv IS INITIAL.
    MESSAGE 'No production orders match the material selection' TYPE 'S' DISPLAY LIKE 'E'.
    RETURN.
  ENDIF.

  SELECT objid, arbpl, werks
    FROM crhd
    FOR ALL ENTRIES IN @gt_afru
    WHERE objid = @gt_afru-arbid
    INTO CORRESPONDING FIELDS OF TABLE @gt_crhd.
  IF sy-subrc <> 0.
    MESSAGE 'No work centers found for the confirmations' TYPE 'S'.
  ENDIF.

* --- Workcenter exclusion: ZPP_WORK_CENTER is keyed by WERKS+ARBPL
*     (confirmed via SE11) but has no dedicated "exclude" flag - it
*     links a workcenter to a fixed asset (VERWE/ANLN1/ZANLN). Per
*     business confirmation, a workcenter is excluded when its
*     ZPP_WORK_CENTER-LOEKZ (deletion/blocked indicator) = 'X'. ---
  IF gt_crhd IS NOT INITIAL.
    SELECT werks, arbpl
      FROM zpp_work_center
      FOR ALL ENTRIES IN @gt_crhd
      WHERE werks = @gt_crhd-werks
        AND arbpl = @gt_crhd-arbpl
        AND loekz = 'X'
      INTO CORRESPONDING FIELDS OF TABLE @gt_excl.
    IF sy-subrc <> 0.
      CLEAR gt_excl.
    ENDIF.
  ENDIF.

  SELECT objid, ktext
    FROM crtx
    FOR ALL ENTRIES IN @gt_crhd
    WHERE objid = @gt_crhd-objid
      AND spras = @sy-langu
    INTO CORRESPONDING FIELDS OF TABLE @gt_crtx.
  IF sy-subrc <> 0.
    CLEAR gt_crtx.
  ENDIF.

  SELECT matnr, matkl, ntgew
    FROM mara
    FOR ALL ENTRIES IN @gt_caufv
    WHERE matnr = @gt_caufv-plnbez
    INTO CORRESPONDING FIELDS OF TABLE @gt_mara.
  IF sy-subrc <> 0.
    MESSAGE 'Material master data not found' TYPE 'S'.
  ENDIF.

  SELECT matnr, maktx
    FROM makt
    FOR ALL ENTRIES IN @gt_caufv
    WHERE matnr = @gt_caufv-plnbez
      AND spras = @sy-langu
    INTO CORRESPONDING FIELDS OF TABLE @gt_makt.
  IF sy-subrc <> 0.
    MESSAGE 'Material description not found' TYPE 'S'.
  ENDIF.

  SELECT aufnr, verid
    FROM afpo
    FOR ALL ENTRIES IN @gt_caufv
    WHERE aufnr = @gt_caufv-aufnr
    INTO CORRESPONDING FIELDS OF TABLE @gt_afpo.
  IF sy-subrc <> 0.
    MESSAGE 'Production version not found' TYPE 'S'.
  ENDIF.

  SELECT aufnr, gstrp, gltrp
    FROM afko
    FOR ALL ENTRIES IN @gt_caufv
    WHERE aufnr = @gt_caufv-aufnr
    INTO CORRESPONDING FIELDS OF TABLE @gt_afko.
  IF sy-subrc <> 0.
    MESSAGE 'Order dates not found' TYPE 'S'.
  ENDIF.

* --- Routing base qty (BMSCH) / machine time (VGE04): the FS says to
*     pass PLNTY, PLNNR, PLNAL and VORNR. PLNAL is not itself a field
*     on PLPO, so resolve it to PLKO's internal group counter (ZAEHL)
*     first, then read PLPO by that counter AND the confirmed
*     operation (AFRU-VORNR). ---
  SELECT plnty, plnnr, plnal, zaehl
    FROM plko
    FOR ALL ENTRIES IN @gt_caufv
    WHERE plnty = @gt_caufv-plnty
      AND plnnr = @gt_caufv-plnnr
      AND plnal = @gt_caufv-plnal
    INTO CORRESPONDING FIELDS OF TABLE @gt_plko.
  IF sy-subrc <> 0.
    MESSAGE 'Routing (PLKO) data not found' TYPE 'S'.
  ENDIF.

  IF gt_plko IS NOT INITIAL.
    SELECT plnty, plnnr, zaehl, vornr, bmsch, vge04
      FROM plpo
      FOR ALL ENTRIES IN @gt_plko
      WHERE plnty = @gt_plko-plnty
        AND plnnr = @gt_plko-plnnr
        AND zaehl = @gt_plko-zaehl
      INTO CORRESPONDING FIELDS OF TABLE @gt_plpo.
    IF sy-subrc <> 0.
      MESSAGE 'Routing (PLPO) data not found' TYPE 'S'.
    ENDIF.
  ENDIF.

  SORT gt_caufv BY aufnr.
  SORT gt_crhd  BY objid.
  SORT gt_crtx  BY objid.
  SORT gt_mara  BY matnr.
  SORT gt_makt  BY matnr.
  SORT gt_afpo  BY aufnr.
  SORT gt_afko  BY aufnr.
  SORT gt_plko  BY plnty plnnr plnal.
  SORT gt_plpo  BY plnty plnnr zaehl vornr.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  PROCESS_DATA
*&---------------------------------------------------------------------*
*&  Core extraction & derivation logic, per FS "Detailed FS" tab.
*&  IV_PLNTY_FILTER = '2' restricts routing type for the SFG/FG view
*&  (Radio Button 2); blank = no restriction (Moulding view / Radio 1).
*&
*&  No SELECT statements below - every lookup is a READ TABLE with
*&  BINARY SEARCH against a table GET_DATA already sorted, and every
*&  READ TABLE / CALL FUNCTION result is checked via SY-SUBRC.
*&---------------------------------------------------------------------*
FORM process_data USING iv_plnty_filter TYPE plnty.

  DATA: gs_output TYPE ty_output,
        gs_afru   TYPE ty_afru,
        gs_caufv  TYPE ty_caufv,
        gs_crhd   TYPE ty_crhd,
        gs_crtx   TYPE ty_crtx,
        gs_mara   TYPE ty_mara,
        gs_makt   TYPE ty_makt,
        gs_afpo   TYPE ty_afpo,
        gs_afko   TYPE ty_afko,
        gs_plko   TYPE ty_plko,
        gs_plpo   TYPE ty_plpo.

  DATA: gv_excluded    TYPE abap_bool,
        gv_a_ratio     TYPE p LENGTH 13 DECIMALS 6,
        gv_q_ratio     TYPE p LENGTH 13 DECIMALS 6,
        gv_p_ratio     TYPE p LENGTH 13 DECIMALS 6,
        gv_val1        TYPE p LENGTH 13 DECIMALS 6,
        gv_val2        TYPE p LENGTH 13 DECIMALS 6,
        gv_start_ts    TYPE timestamp,
        gv_end_ts      TYPE timestamp,
        gv_seconds     TYPE p LENGTH 8 DECIMALS 0,
        gv_iserh_hrs   TYPE p LENGTH 9 DECIMALS 4.

  REFRESH gt_output.

  LOOP AT gt_afru INTO gs_afru.

    CLEAR: gs_output, gs_crhd, gs_crtx, gs_caufv, gs_mara, gs_makt,
           gs_afpo, gs_afko, gs_plko, gs_plpo,
           gv_a_ratio, gv_q_ratio, gv_p_ratio, gv_val1, gv_val2.

*   --- Header fields sourced directly from the confirmation itself -
*       always available, since GS_AFRU is the loop line ---
    gs_output-werks         = gs_afru-werks.
    gs_output-datum         = gs_afru-ersda.
    gs_output-aufnr         = gs_afru-aufnr.
    gs_output-gmnga         = gs_afru-gmnga.
    gs_output-meins         = gs_afru-gmein.
    gs_output-vornr         = gs_afru-vornr.
    gs_output-cancelled     = gs_afru-stzhl.
    gs_output-reversed      = gs_afru-stokz.
    gs_output-rueck         = gs_afru-rueck.
    gs_output-rmzhl         = gs_afru-rmzhl.
    gs_output-setup_machine = gs_afru-ism02.
    gs_output-start_date    = gs_afru-isdd.
    gs_output-end_date      = gs_afru-iedd.
    gs_output-start_time    = gs_afru-isdz.
    gs_output-end_time      = gs_afru-iedz.

    READ TABLE gt_crhd INTO gs_crhd WITH KEY objid = gs_afru-arbid BINARY SEARCH.
    IF sy-subrc = 0.
      gs_output-arbpl = gs_crhd-arbpl.
    ENDIF.

*   --- Exclude workcenters where ZPP_WORK_CENTER-LOEKZ = 'X' ---
    gv_excluded = abap_false.
    READ TABLE gt_excl TRANSPORTING NO FIELDS
      WITH KEY werks = gs_crhd-werks
               arbpl = gs_crhd-arbpl.
    IF sy-subrc = 0.
      gv_excluded = abap_true.
    ENDIF.
    IF gv_excluded = abap_true.
      CONTINUE.
    ENDIF.

*   --- Order header (CAUFV) via AFRU-AUFNR - mandatory: without it we
*       have no material/order-type/qty to report, so skip the line.
*       The PLNTY filter (R2) and material-range filter were already
*       applied to GT_CAUFV in GET_DATA. ---
    READ TABLE gt_caufv INTO gs_caufv WITH KEY aufnr = gs_afru-aufnr BINARY SEARCH.
    IF sy-subrc <> 0.
      CONTINUE.
    ENDIF.

    IF iv_plnty_filter IS NOT INITIAL AND gs_caufv-plnty <> iv_plnty_filter.
      CONTINUE.
    ENDIF.

    gs_output-matnr = gs_caufv-plnbez.
    gs_output-auart = gs_caufv-auart.
    gs_output-gamng = gs_caufv-gamng.
    gs_output-stlal = gs_caufv-stlal.

    READ TABLE gt_mara INTO gs_mara WITH KEY matnr = gs_caufv-plnbez BINARY SEARCH.
    IF sy-subrc = 0.
      gs_output-matkl = gs_mara-matkl.
      gs_output-ntgew = gs_mara-ntgew.
    ENDIF.

    READ TABLE gt_makt INTO gs_makt WITH KEY matnr = gs_caufv-plnbez BINARY SEARCH.
    IF sy-subrc = 0.
      gs_output-maktx = gs_makt-maktx.
    ENDIF.

    READ TABLE gt_crtx INTO gs_crtx WITH KEY objid = gs_crhd-objid BINARY SEARCH.
    IF sy-subrc = 0.
      gs_output-ktext = gs_crtx-ktext.
    ENDIF.

    READ TABLE gt_afpo INTO gs_afpo WITH KEY aufnr = gs_caufv-aufnr BINARY SEARCH.
    IF sy-subrc = 0.
      gs_output-verid = gs_afpo-verid.
    ENDIF.

    READ TABLE gt_afko INTO gs_afko WITH KEY aufnr = gs_caufv-aufnr BINARY SEARCH.
    IF sy-subrc = 0.
      gs_output-order_start_date = gs_afko-gltrp.
      gs_output-order_end_date   = gs_afko-gstrp.
    ENDIF.

*   --- Total tonnage = Confirmed Qty * Net Weight / 1000 (per FS) ---
    gs_output-tot_tonnage = ( gs_output-gmnga * gs_output-ntgew ) / 1000.

*   --- Running hours: combine date+time so a confirmation that runs
*       past midnight doesn't produce a negative duration ---
    CLEAR: gv_start_ts, gv_end_ts, gv_seconds.
    IF gs_afru-isdd IS NOT INITIAL AND gs_afru-iedd IS NOT INITIAL.
      CONVERT DATE gs_afru-isdd TIME gs_afru-isdz
        INTO TIME STAMP gv_start_ts TIME ZONE sy-zonlo.
      CONVERT DATE gs_afru-iedd TIME gs_afru-iedz
        INTO TIME STAMP gv_end_ts TIME ZONE sy-zonlo.
      TRY.
          cl_abap_tstmp=>subtract(
            EXPORTING tstmp1   = gv_end_ts
                      tstmp2   = gv_start_ts
            IMPORTING rseconds = gv_seconds ).
        CATCH cx_root.
          gv_seconds = 0.
      ENDTRY.
      gs_output-running_hrs = gv_seconds / 3600.
    ENDIF.

*   --- Manhours = (ISM02 + ISM04) / 60 - independent of routing data,
*       so it is calculated regardless of whether BMSCH/VGE04 resolve ---
    gs_output-manhours = ( gs_afru-ism02 + gs_afru-ism04 ) / 60.

*   --- Rejected Qty = sum of AFRU-ZZRQUAN1..ZZRQUAN6 (Reusable Scrap
*       Quantity 1-6) ---
    gs_output-rejected_qty = gs_afru-zzrquan1 + gs_afru-zzrquan2
                            + gs_afru-zzrquan3 + gs_afru-zzrquan4
                            + gs_afru-zzrquan5 + gs_afru-zzrquan6.

*   --- Breakdown time = AFRU-ISERH, converted to hours using its own
*       unit field AFRU-ZEIER (data element DZEIER) rather than a
*       hardcoded /60 ---
    CALL FUNCTION 'UNIT_CONVERSION_SIMPLE'
      EXPORTING
        input                = gs_afru-iserh
        unit_in              = gs_afru-zeier
        unit_out             = 'STD'
      IMPORTING
        output               = gv_iserh_hrs
      EXCEPTIONS
        conversion_not_found = 1
        division_by_zero     = 2
        input_invalid        = 3
        output_invalid       = 4
        overflow              = 5
        type_invalid          = 6
        units_missing         = 7
        unit_in_not_found     = 8
        unit_out_not_found    = 9
        OTHERS                = 10.

    IF sy-subrc = 0.
      gs_output-breakdown_time = gv_iserh_hrs.
    ELSE.
*     Unit missing/not found in T006 - fall back to the raw value
*     (treat as already hours) rather than silently show zero.
      gs_output-breakdown_time = gs_afru-iserh.
    ENDIF.

*   --- STD QTY / Std Man Hours / P%: need routing base qty (BMSCH)
*       and machine time (VGE04) for the confirmed operation. SY-SUBRC
*       is checked directly below - nothing between the READ TABLE
*       statements and their checks can overwrite it. ---
    READ TABLE gt_plko INTO gs_plko
      WITH KEY plnty = gs_caufv-plnty
               plnnr = gs_caufv-plnnr
               plnal = gs_caufv-plnal
      BINARY SEARCH.

    IF sy-subrc = 0.
      READ TABLE gt_plpo INTO gs_plpo
        WITH KEY plnty = gs_plko-plnty
                 plnnr = gs_plko-plnnr
                 zaehl = gs_plko-zaehl
                 vornr = gs_afru-vornr
        BINARY SEARCH.
    ELSE.
      CLEAR gs_plpo.
    ENDIF.

    IF sy-subrc = 0 AND gs_plpo-vge04 <> 0 AND gs_plpo-bmsch <> 0.

*     FS logic (confirmed with the functional team): two derivations
*     multiplied together - val1 = BMSCH/VGE04, val2 = Order Qty x
*     VGE04/BMSCH, STD QTY = val1 x val2. Algebraically this equals
*     Order Qty whenever BMSCH/VGE04 resolve and are nonzero - that is
*     the confirmed intended behavior, not a bug.
      gv_val1 = gs_plpo-bmsch / gs_plpo-vge04.
      gv_val2 = ( gs_output-gamng * gs_plpo-vge04 ) / gs_plpo-bmsch.
      gs_output-std_qty = gv_val1 * gv_val2.

*     --- Std Man Hours = Order Qty * ISM04 / BMSCH ---
      gs_output-std_manhours = ( gs_output-gamng * gs_afru-ism04 ) / gs_plpo-bmsch.

*     --- P% = Actual PC/min / Std PC/min ---
*         Actual PC/min = Confirmed Qty / ISM04 (confirmed machine time)
*         Std PC/min    = BMSCH / VGE04
      IF gs_afru-ism04 <> 0.
        gv_p_ratio = ( gs_output-gmnga / gs_afru-ism04 ) / gv_val1.
        gs_output-p_pct = gv_p_ratio * 100.
      ENDIF.
    ENDIF.

*   --- A% = (Runtime - Breakdown) / Runtime ---
    IF gs_output-running_hrs <> 0.
      gv_a_ratio = ( gs_output-running_hrs - gs_output-breakdown_time )
                   / gs_output-running_hrs.
      gs_output-a_pct = gv_a_ratio * 100.
    ENDIF.

*   --- Q% = Confirmed Qty / (Confirmed Qty + Rejected Qty) ---
    IF ( gs_output-gmnga + gs_output-rejected_qty ) <> 0.
      gv_q_ratio = gs_output-gmnga / ( gs_output-gmnga + gs_output-rejected_qty ).
      gs_output-q_pct = gv_q_ratio * 100.
    ENDIF.

*   --- OEE% = A% * Q% * P% (computed on the underlying ratios, then
*       scaled to a percentage once) ---
    gs_output-oee_pct = gv_a_ratio * gv_q_ratio * gv_p_ratio * 100.

*   --- Capacity Utilization % = Confirmed Qty / Std Qty ---
    IF gs_output-std_qty <> 0.
      gs_output-cap_util_pct = ( gs_output-gmnga / gs_output-std_qty ) * 100.
    ENDIF.

    APPEND gs_output TO gt_output.

  ENDLOOP.

  IF gt_output IS INITIAL.
    MESSAGE 'No data found for the selection' TYPE 'S' DISPLAY LIKE 'E'.
  ENDIF.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  BUILD_SUMMARY
*&---------------------------------------------------------------------*
*&  Radio Button 3: per the FS's literal Detailed-FS instruction -
*&  "Show workcenter wise Cumulative sum of Capacity utilization" -
*&  this is a straight per-workcenter (WERKS+ARBPL) cumulative sum of
*&  Capacity Utilization % across whatever date range was selected on
*&  the screen. "Monthly Summary" is only the radio button's label;
*&  the detailed logic line doesn't mention a month bucket at all, so
*&  no time-period grouping is applied - confirmed per business
*&  clarification, see docs/assumptions.md point 5.
*&---------------------------------------------------------------------*
FORM build_summary.

  DATA: gs_output  TYPE ty_output,
        gs_summary TYPE ty_summary.

  REFRESH gt_summary.

  LOOP AT gt_output INTO gs_output.

    READ TABLE gt_summary INTO gs_summary
      WITH KEY werks = gs_output-werks
               arbpl = gs_output-arbpl.

    IF sy-subrc = 0.
      gs_summary-cap_util_sum = gs_summary-cap_util_sum
                                 + gs_output-cap_util_pct.
      MODIFY gt_summary FROM gs_summary INDEX sy-tabix.
    ELSE.
      CLEAR gs_summary.
      gs_summary-werks        = gs_output-werks.
      gs_summary-arbpl        = gs_output-arbpl.
      gs_summary-ktext        = gs_output-ktext.
      gs_summary-cap_util_sum = gs_output-cap_util_pct.
      APPEND gs_summary TO gt_summary.
    ENDIF.

  ENDLOOP.

  SORT gt_summary BY werks arbpl.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_DETAIL
*&---------------------------------------------------------------------*
FORM display_detail.

  DATA: lo_salv TYPE REF TO cl_salv_table,
        lx_salv TYPE REF TO cx_salv_msg.

  IF gt_output IS INITIAL.
    RETURN.
  ENDIF.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_salv
        CHANGING  t_table      = gt_output ).

      lo_salv->get_functions( )->set_all( abap_true ).
      lo_salv->get_columns( )->set_optimize( abap_true ).
      lo_salv->display( ).

    CATCH cx_salv_msg INTO lx_salv.
      MESSAGE lx_salv->get_text( ) TYPE 'E'.
  ENDTRY.

ENDFORM.

*&---------------------------------------------------------------------*
*&      Form  DISPLAY_SUMMARY
*&---------------------------------------------------------------------*
FORM display_summary.

  DATA: lo_salv TYPE REF TO cl_salv_table,
        lx_salv TYPE REF TO cx_salv_msg.

  IF gt_summary IS INITIAL.
    RETURN.
  ENDIF.

  TRY.
      cl_salv_table=>factory(
        IMPORTING r_salv_table = lo_salv
        CHANGING  t_table      = gt_summary ).

      lo_salv->get_functions( )->set_all( abap_true ).
      lo_salv->get_columns( )->set_optimize( abap_true ).
      lo_salv->display( ).

    CATCH cx_salv_msg INTO lx_salv.
      MESSAGE lx_salv->get_text( ) TYPE 'E'.
  ENDTRY.

ENDFORM.
