*&---------------------------------------------------------------------*
*& Report ZPP_OEE_ADHESIVE_REPORT
*&---------------------------------------------------------------------*
*& WRICEF ID  : 166
*& Object Name: Report for OEE in Adhesive
*& Module     : PP
*& Target     : S/4HANA 2022 (ABAP 7.56 / modern syntax)
*&
*& Purpose:
*&   Single selection-screen driven report offering three mutually
*&   exclusive output views (radio buttons), per the FS:
*&     R1 - Moulding Report            (all routing types)
*&     R2 - SFG and FG Production      (routing type PLNTY = '2' only)
*&     R3 - Monthly Summary            (workcenter-wise cumulative
*&                                      Capacity Utilization %)
*&
*& S/4HANA 2022 conformance notes:
*&   - No TABLES statement (obsolete) - select-options reference DDIC
*&     fields directly via TYPE, no dictionary work areas declared.
*&   - Open SQL uses inline declarations (@DATA(...)), host variable
*&     escaping (@), and explicit field lists rather than SELECT *,
*&     per the ABAP style guide / ATC "obsolete statements" checks.
*&   - String templates, VALUE#/COND#/SWITCH# constructor operators,
*&     and NEW instead of CREATE OBJECT are used throughout.
*&   - CL_SALV_TABLE is unchanged (still the recommended simple ALV
*&     factory in S/4HANA 2022 for one-off reports; use ALV IDA / Fiori
*&     elements instead if this becomes an app rather than a report).
*&   - CAUFV is consumed as-is: in S/4HANA it remains available as a
*&     compatibility view over the order tables, so existing field
*&     names (AUFNR, PLNBEZ, GAMNG, AUART, STLAL, PLNTY/PLNNR/PLNAL)
*&     continue to work unchanged.
*&   - AMDP/CDS were intentionally NOT introduced here to keep this a
*&     drop-in, line-for-line match to the FS logic; if this report is
*&     rebuilt as a CDS-based analytical query later, the field mapping
*&     in docs/field_mapping.md still applies.
*&
*& Open items (see docs/assumptions.md):
*&   - STD QTY formula as literally stated in the FS is algebraically
*&     self-cancelling; implemented literally, flagged inline below.
*&   - ZPP_WORKCENTER_EXCLUDE / AFRU-ZZQUAN1..6 assumed structures,
*&     commented out pending confirmation - same as prior version.
*&---------------------------------------------------------------------*
REPORT zpp_oee_adhesive_report.

*&---------------------------------------------------------------------*
*& Output structure - one line per Confirmation (AFRU-ERSDA/RUECK/RMZHL)
*&---------------------------------------------------------------------*
TYPES: BEGIN OF ty_output,
         werks            TYPE afru-werks,            "Plant Code
         datum            TYPE afru-ersda,            "Confirmation entry date
         matnr            TYPE mara-matnr,             "Material Code
         maktx            TYPE makt-maktx,             "Description
         arbpl            TYPE crhd-arbpl,             "Workcentre Name
         ktext            TYPE crtx-ktext,             "Workcenter Description
         aufnr            TYPE afru-aufnr,             "Production Order
         auart            TYPE caufv-auart,            "Order Type
         matkl            TYPE mara-matkl,             "Material Group
         ntgew            TYPE mara-ntgew,             "Net Weight
         gamng            TYPE caufv-gamng,            "Order Qty
         gmnga            TYPE afru-gmnga,             "Confirm Qty
         meins            TYPE afru-meins,             "UOM
         tot_tonnage      TYPE p LENGTH 13 DECIMALS 3,  "Total Tonnage
         std_qty          TYPE p LENGTH 13 DECIMALS 3,  "Std Qty
         manhours         TYPE p LENGTH 13 DECIMALS 3,  "Manhours
         start_time       TYPE afru-isdz,              "Start Time
         end_time         TYPE afru-iedz,              "End Time
         running_hrs      TYPE p LENGTH 9 DECIMALS 4,   "Running Hrs
         a_pct            TYPE p LENGTH 7 DECIMALS 4,   "Availability %
         q_pct            TYPE p LENGTH 7 DECIMALS 4,   "Quality %
         p_pct            TYPE p LENGTH 7 DECIMALS 4,   "Performance %
         oee_pct          TYPE p LENGTH 7 DECIMALS 4,   "OEE %
         rejected_qty     TYPE p LENGTH 13 DECIMALS 3,  "Rejected Qty
         breakdown_time   TYPE p LENGTH 9 DECIMALS 4,   "Breakdown Time (hrs)
         cap_util_pct     TYPE p LENGTH 7 DECIMALS 4,   "Capacity Utilization %
         verid            TYPE afpo-verid,             "Production Version
         stlal            TYPE caufv-stlal,            "Alternative BOM
         order_start_date TYPE afko-gltrp,             "Order Start Date
         order_end_date   TYPE afko-gstrp,             "Order End Date
         vornr            TYPE afru-vornr,             "Phase / Operation
         cancelled        TYPE afru-stzhl,             "Cancelled
         reversed         TYPE afru-stokz,             "Reversed
         rueck            TYPE afru-rueck,             "Confirmation Number
         rmzhl            TYPE afru-rmzhl,             "Confirmation Counter
         setup_machine    TYPE afru-ism02,             "Setup Machine (confirmed)
         std_manhours     TYPE p LENGTH 13 DECIMALS 3,  "Std Man Hours
       END OF ty_output.

TYPES: ty_output_t TYPE STANDARD TABLE OF ty_output WITH EMPTY KEY.

TYPES: BEGIN OF ty_monthly,
         arbpl        TYPE crhd-arbpl,
         month        TYPE spmon,
         cap_util_sum TYPE p LENGTH 9 DECIMALS 4,
       END OF ty_monthly.

TYPES: ty_monthly_t TYPE STANDARD TABLE OF ty_monthly WITH EMPTY KEY.

DATA: gt_output         TYPE ty_output_t,
      gt_monthly_summary TYPE ty_monthly_t.

*&---------------------------------------------------------------------*
*& Local class definition - must precede its use in the event blocks
*& below; implementation is at the bottom of the program.
*&---------------------------------------------------------------------*
CLASS lcl_report DEFINITION.

  PUBLIC SECTION.
    METHODS: build_production_data
      IMPORTING iv_plnty_filter        TYPE plnty
      RETURNING VALUE(rt_output)       TYPE ty_output_t.

    METHODS: build_monthly_summary
      IMPORTING it_output              TYPE ty_output_t
      RETURNING VALUE(rt_monthly)      TYPE ty_monthly_t.

    CLASS-METHODS: display_alv
      CHANGING ct_table TYPE STANDARD TABLE.

ENDCLASS.

*&---------------------------------------------------------------------*
*& Selection Screen (per FS "Selection Screen" block)
*&---------------------------------------------------------------------*
SELECTION-SCREEN BEGIN OF BLOCK b1 WITH FRAME TITLE TEXT-001.

SELECT-OPTIONS: s_werks FOR afru-werks OBLIGATORY,     "Plant Code - MANDATORY
                s_matnr FOR mara-matnr,                 "Material Code - range
                s_datum FOR afru-ersda OBLIGATORY,      "Date - MANDATORY
                s_arbpl FOR afru-arbpl.                 "Workcenter

SELECTION-SCREEN END OF BLOCK b1.

SELECTION-SCREEN BEGIN OF BLOCK b2 WITH FRAME TITLE TEXT-002.

PARAMETERS: p_r1 RADIOBUTTON GROUP rb1 DEFAULT 'X' USER-COMMAND rbc, "Moulding Report
            p_r2 RADIOBUTTON GROUP rb1,                              "SFG and FG Production
            p_r3 RADIOBUTTON GROUP rb1.                              "Monthly Summary

SELECTION-SCREEN END OF BLOCK b2.

*&---------------------------------------------------------------------*
*& Text symbols (maintain via SE38 Goto > Text Elements):
*&   001 Selection Criteria
*&   002 Report Type
*&---------------------------------------------------------------------*

*&---------------------------------------------------------------------*
*& AT SELECTION-SCREEN - basic validation
*&---------------------------------------------------------------------*
AT SELECTION-SCREEN.
  IF s_werks[] IS INITIAL.
    MESSAGE 'Plant is mandatory' TYPE 'E'.
  ENDIF.
  IF s_datum[] IS INITIAL.
    MESSAGE 'Date range is mandatory' TYPE 'E'.
  ENDIF.

*&---------------------------------------------------------------------*
*& START-OF-SELECTION
*&---------------------------------------------------------------------*
START-OF-SELECTION.

  CASE abap_true.
    WHEN p_r1.
      gt_output = NEW lcl_report( )->build_production_data( iv_plnty_filter = space ).
    WHEN p_r2.
      gt_output = NEW lcl_report( )->build_production_data( iv_plnty_filter = '2' ).
    WHEN p_r3.
      gt_output = NEW lcl_report( )->build_production_data( iv_plnty_filter = space ).
      gt_monthly_summary = NEW lcl_report( )->build_monthly_summary( gt_output ).
  ENDCASE.

*&---------------------------------------------------------------------*
*& END-OF-SELECTION - render ALV
*&---------------------------------------------------------------------*
END-OF-SELECTION.

  IF p_r3 = abap_true.
    lcl_report=>display_alv( CHANGING ct_table = gt_monthly_summary ).
  ELSE.
    lcl_report=>display_alv( CHANGING ct_table = gt_output ).
  ENDIF.

*&---------------------------------------------------------------------*
*& Local class implementation - extraction / derivation / display logic
*&---------------------------------------------------------------------*
CLASS lcl_report IMPLEMENTATION.

  METHOD build_production_data.

    " Step 1/2: Plant + Date from selection screen against AFRU-WERKS / ERSDA
    SELECT werks, ersda, arbid, arbpl, aufnr, gmnga, meins, isdz, iedz,
           ism02, ism04, iserh, vornr, stzhl, stokz, rueck, rmzhl
      FROM afru
      WHERE werks IN @s_werks
        AND ersda IN @s_datum
        AND arbpl IN @s_arbpl
      INTO TABLE @DATA(lt_afru).

    LOOP AT lt_afru INTO DATA(ls_afru).

      "--- Exclude workcenters listed in ZPP_WORKCENTER_EXCLUDE ---
      " Pass AFRU-ARBID to CRHD-OBJID, take CRHD-ARBPL; check against
      " ZPP_WORKCENTER_EXCLUDE-ARBPL / WERKS. If found, skip this record.
      SELECT SINGLE objid, arbpl
        FROM crhd
        WHERE objid = @ls_afru-arbid
        INTO @DATA(ls_crhd).

      DATA(lv_excluded) = abap_false.
      " SELECT SINGLE @abap_true
      "   FROM zpp_workcenter_exclude
      "   WHERE arbpl = @ls_crhd-arbpl
      "     AND werks = @ls_afru-werks
      "   INTO @lv_excluded.
      IF lv_excluded = abap_true.
        CONTINUE.
      ENDIF.

      "--- Order header (CAUFV) via AFRU-AUFNR ---
      SELECT SINGLE aufnr, plnbez, auart, gamng, stlal, plnty, plnnr, plnal
        FROM caufv
        WHERE aufnr = @ls_afru-aufnr
        INTO @DATA(ls_caufv).

      " Radio Button 2 restriction: only routing type PLNTY = '2'
      IF iv_plnty_filter IS NOT INITIAL AND ls_caufv-plnty <> iv_plnty_filter.
        CONTINUE.
      ENDIF.

      "--- Material master / description ---
      SELECT SINGLE matnr, matkl, ntgew
        FROM mara
        WHERE matnr = @ls_caufv-plnbez
        INTO @DATA(ls_mara).

      SELECT SINGLE matnr, maktx
        FROM makt
        WHERE matnr = @ls_caufv-plnbez
          AND spras = @sy-langu
        INTO @DATA(ls_makt).

      "--- Workcenter description ---
      SELECT SINGLE objid, ktext
        FROM crtx
        WHERE objid = @ls_crhd-objid
          AND spras = @sy-langu
        INTO @DATA(ls_crtx).

      "--- Order item (production version) ---
      SELECT SINGLE aufnr, verid
        FROM afpo
        WHERE aufnr = @ls_caufv-aufnr
        INTO @DATA(ls_afpo).

      "--- Order dates ---
      SELECT SINGLE aufnr, gltrp, gstrp
        FROM afko
        WHERE aufnr = @ls_caufv-aufnr
        INTO @DATA(ls_afko).

      DATA(ls_output) = VALUE ty_output(
        werks            = ls_afru-werks
        datum            = ls_afru-ersda
        matnr            = ls_caufv-plnbez
        maktx            = ls_makt-maktx
        arbpl            = ls_crhd-arbpl
        ktext            = ls_crtx-ktext
        aufnr            = ls_afru-aufnr
        auart            = ls_caufv-auart
        matkl            = ls_mara-matkl
        ntgew            = ls_mara-ntgew
        gamng            = ls_caufv-gamng
        gmnga            = ls_afru-gmnga
        meins            = ls_afru-meins
        verid            = ls_afpo-verid
        stlal            = ls_caufv-stlal
        order_start_date = ls_afko-gltrp
        order_end_date   = ls_afko-gstrp
        vornr            = ls_afru-vornr
        cancelled        = ls_afru-stzhl
        reversed         = ls_afru-stokz
        rueck            = ls_afru-rueck
        rmzhl            = ls_afru-rmzhl
        setup_machine    = ls_afru-ism02
        start_time       = ls_afru-isdz
        end_time         = ls_afru-iedz ).

      "--- Total tonnage = Confirmed Qty * Net Weight / 1000 (per FS) ---
      ls_output-tot_tonnage = ( ls_output-gmnga * ls_output-ntgew ) / 1000.

      "--- Running hours = end time - start time, expressed in hours ---
      ls_output-running_hrs = ( ls_afru-iedz - ls_afru-isdz ) / 3600.

      "--- Rejected Qty = sum of AFRU-ZZQUAN1 .. ZZQUAN6 ---
      " NOTE: ZZQUAN1-6 are assumed custom append fields on AFRU per the FS;
      " confirm exact field names in the target system before activation.
      DATA(lv_rejected) = CONV p( 0 ).
      " lv_rejected = ls_afru-zzquan1 + ls_afru-zzquan2 + ls_afru-zzquan3
      "             + ls_afru-zzquan4 + ls_afru-zzquan5 + ls_afru-zzquan6.
      ls_output-rejected_qty = lv_rejected.

      "--- Breakdown time = AFRU-ISERH / 60 (minutes -> hours) ---
      ls_output-breakdown_time = ls_afru-iserh / 60.

      "--- STD QTY: call BAPI to read routing base qty / machine time ---
      " FS logic (as literally stated) is two derivations multiplied
      " together:
      "   val1 = BMSCH / VGE04                      (base qty per machine time unit)
      "   val2 = Order Qty * VGE04 / BMSCH           (machine time per order qty)
      "   STD QTY = val1 * val2
      " Multiplying these two together algebraically returns Order Qty,
      " which looks like a documentation error in the FS rather than an
      " intentional formula - flagged here rather than silently "corrected".
      " Implemented literally; raise with functional consultant before go-live.
      CALL FUNCTION 'CARO_ROUTING_READ'
        EXPORTING
          plnty    = ls_caufv-plnty
          plnnr    = ls_caufv-plnnr
          plnal    = ls_caufv-plnal
          aennr    = space
        IMPORTING
          ex_bmsch = DATA(lv_bmsch)
          ex_vge04 = DATA(lv_vge04)
        EXCEPTIONS
          OTHERS   = 1.

      IF sy-subrc = 0 AND lv_vge04 <> 0 AND lv_bmsch <> 0.
        DATA(lv_val1) = lv_bmsch / lv_vge04.
        DATA(lv_val2) = ( ls_output-gamng * lv_vge04 ) / lv_bmsch.
        ls_output-std_qty = lv_val1 * lv_val2.

        "--- Manhours = (ISM02 + ISM04) / 60 ---
        ls_output-manhours = ( ls_afru-ism02 + ls_afru-ism04 ) / 60.

        "--- Std Man Hours = Order Qty * ISM04 / BMSCH ---
        ls_output-std_manhours = ( ls_output-gamng * ls_afru-ism04 ) / lv_bmsch.

        "--- P% = Actual PC/min / Std PC/min ---
        "    Actual PC/min = Confirmed Qty / ISM04 (confirmed machine time)
        "    Std PC/min    = BMSCH / VGE04
        IF ls_afru-ism04 <> 0.
          ls_output-p_pct = ( ls_output-gmnga / ls_afru-ism04 ) / lv_val1.
        ENDIF.
      ENDIF.

      "--- A% = (Runtime - Breakdown) / Runtime ---
      IF ls_output-running_hrs <> 0.
        ls_output-a_pct = ( ls_output-running_hrs - ls_output-breakdown_time )
                          / ls_output-running_hrs.
      ENDIF.

      "--- Q% = Confirmed Qty / (Confirmed Qty + Rejected Qty) ---
      IF ( ls_output-gmnga + ls_output-rejected_qty ) <> 0.
        ls_output-q_pct = ls_output-gmnga
                          / ( ls_output-gmnga + ls_output-rejected_qty ).
      ENDIF.

      "--- OEE% = A% * Q% * P% ---
      ls_output-oee_pct = ls_output-a_pct * ls_output-q_pct * ls_output-p_pct.

      "--- Capacity Utilization % = Confirmed Qty / Std Qty ---
      IF ls_output-std_qty <> 0.
        ls_output-cap_util_pct = ls_output-gmnga / ls_output-std_qty.
      ENDIF.

      INSERT ls_output INTO TABLE rt_output.

    ENDLOOP.

  ENDMETHOD.

  METHOD build_monthly_summary.

    " Radio Button 3: "Show workcenter wise cumulative sum of Capacity
    " Utilization" (per FS Detailed FS tab). Monthly bucket = YYYYMM
    " derived from confirmation date - see docs/assumptions.md point 5.
    LOOP AT it_output INTO DATA(ls_output).

      DATA(lv_month) = CONV spmon( ls_output-datum(6) ).

      ASSIGN rt_monthly[ arbpl = ls_output-arbpl
                          month = lv_month ] TO FIELD-SYMBOL(<ls_summary>).

      IF sy-subrc = 0.
        <ls_summary>-cap_util_sum = <ls_summary>-cap_util_sum
                                     + ls_output-cap_util_pct.
      ELSE.
        INSERT VALUE ty_monthly(
          arbpl        = ls_output-arbpl
          month        = lv_month
          cap_util_sum = ls_output-cap_util_pct ) INTO TABLE rt_monthly.
      ENDIF.

    ENDLOOP.

    SORT rt_monthly BY arbpl month.

  ENDMETHOD.

  METHOD display_alv.

    TRY.
        cl_salv_table=>factory(
          IMPORTING r_salv_table = DATA(lo_salv)
          CHANGING  t_table      = ct_table ).

        lo_salv->get_functions( )->set_all( abap_true ).
        lo_salv->get_columns( )->set_optimize( abap_true ).
        lo_salv->display( ).

      CATCH cx_salv_msg INTO DATA(lx_salv).
        MESSAGE lx_salv->get_text( ) TYPE 'E'.
    ENDTRY.

  ENDMETHOD.

ENDCLASS.
