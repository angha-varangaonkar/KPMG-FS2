# WRICEF 166 – Overall Production Report (OEE in Adhesive) — S/4HANA

S/4HANA-compatible ABAP implementation, generated from the Functional
Specification `Copy of WRICEF ID 166-Overall production report for SFG FG and
moulding sperately.xlsx`. Same business logic as the classic-syntax version.

## v8 rewrite — explicit declarations, no obsolete statements

v8 restructures this package for readability, per direct feedback:

- **`TYPES` first, then `DATA`, in one block each, at the top of the
  program** — every variable's type is visible before it's ever used,
  instead of being declared inline in the middle of the logic.
- **No inline `DATA(...)` declarations anywhere** — every work area and
  helper variable is declared explicitly with a named `DATA:` statement.
- **No `SELECT` inside any loop.** `GET_DATA` runs every bulk `SELECT` /
  `FOR ALL ENTRIES` once, up front; `PROCESS_DATA`'s confirmation loop only
  does `READ TABLE ... BINARY SEARCH` against the already-sorted results.
- **`SY-SUBRC` is checked explicitly after every `READ TABLE` and `CALL
  FUNCTION`** — nothing is assumed to have succeeded silently.
- **`PERFORM`/`FORM` subroutines**, not a local class — still fully valid,
  fully supported S/4HANA syntax, just simpler to read top-to-bottom for
  procedural-style review.
- **No `TABLES` statement** (obsolete) — `SELECT-OPTIONS` reference DDIC
  types via helper variables (`GV_WERKS TYPE afru-werks`, etc.) instead.
- **Modern Open SQL** throughout — comma-separated field lists, `@`-escaped
  host variables, `FOR ALL ENTRIES` for every bulk lookup.

## v2-v12 changes (code review fixes — same as the classic version)

Bulk (`FOR ALL ENTRIES`) data retrieval instead of one `SELECT SINGLE`/BAPI
call per confirmation line; routing base qty/machine time (`BMSCH`/`VGE04`)
resolved via `PLKO`+`PLPO` so the correct routing alternative *and* operation
are used (v1's BAPI call never passed `VORNR`); Manhours no longer skipped
when the routing lookup fails; percentages expressed on a 0-100 scale;
Running Hours computed from full date+time timestamps so overnight
confirmations don't go negative; Start Date/End Date columns added; UOM
sourced from `AFRU-GMEIN` (not `MEINS`, which standard AFRU does not have).
**v3 replaces the two guessed Z-structures with the real ones confirmed via
SE11**: workcenter exclusion uses `ZPP_WORK_CENTER` with `LOEKZ = 'X'` as the
exclusion signal (there is no `ZPP_WORKCENTER_EXCLUDE` table), and Rejected
Qty sums `AFRU-ZZRQUAN1..ZZRQUAN6` (not `ZZQUAN1..6`). **v4 resolves R3's
grouping**: a plain per-workcenter cumulative sum, no calendar-month bucket.
**v5 removes the placeholder Plant `AUTHORITY-CHECK`** rather than shipping a
guessed object. **v6 closes out the three remaining business questions**: STD
QTY formula confirmed as the FS's literal text (algebraically equals Order
Qty, confirmed intended); `AFRU-ISERH` breakdown time now converted via
`UNIT_CONVERSION_SIMPLE` using its own unit field `AFRU-ZEIER` instead of a
hardcoded `/60`; and `AFKO-GLTRP`/`GSTRP` start/end mapping confirmed as the
FS states it. **v7 removes a redundant validation**: `S_WERKS`/`S_DATUM` are
already `OBLIGATORY`, so the manual `IF ... IS INITIAL` + custom `MESSAGE`
checks in `AT SELECTION-SCREEN` duplicated behavior the selection-screen
framework already provides, and have been removed. **v8/v9 restructure
declarations**: one `TYPES` block then one `DATA` block up front, no inline
`DATA(...)`, no `SELECT` in the confirmation loop, and internal
tables/work areas declared directly from their structure type (no
intermediate table-type indirection). **v10 restructures the optional-lookup
checks**: each `READ TABLE` for an optional reference is now followed
immediately by `IF sy-subrc = 0.` with the corresponding output field(s)
assigned right there, instead of clearing on failure and batch-assigning
later; the redundant `sy-subrc` capture variables for the routing/unit-
conversion lookups were also dropped in favor of checking `sy-subrc`
directly, since nothing intervenes between each call and its check.
Mandatory lookups (order header) still use `IF sy-subrc <> 0. CONTINUE.`,
since that's the clearer way to express "skip this record entirely."
**v11 restructures `GET_DATA`'s bulk selects**: every `IF sy-subrc <> 0.
MESSAGE ...` guard has been inverted to `IF sy-subrc = 0.`, with the
*dependent* `SELECT` nested inside that true branch instead of running
unconditionally afterward - `CAUFV` and `CRHD` both nest under `AFRU`'s
success (they're independent siblings, not chained to each other);
`MARA`/`MAKT`/`AFPO`/`AFKO`/`PLKO` nest under `CAUFV`'s success; `PLPO`
nests under `PLKO`'s; the exclusion check and `CRTX` nest under `CRHD`'s.
Each `SORT` moved to sit right after the `SELECT` that populates it,
instead of one disconnected block of `SORT`s at the end. The two
`CLEAR gt_excl`/`CLEAR gt_crtx` statements were also dropped - dead
code, since a `SELECT` that finds nothing simply leaves an
already-empty table empty; nothing needed clearing. The exclusion
`SELECT` itself also picked up the same treatment: a `SY-SUBRC` check
with a `SORT`, and its `READ TABLE` now uses `BINARY SEARCH`.
**v12 makes two further changes**: material master/description are now
read via the standard S/4HANA interface CDS views `I_PRODUCT`/
`I_PRODUCTTEXT` instead of `MARA`/`MAKT` directly - the field names used
(`PRODUCT`, `MATERIALGROUP`, `NETWEIGHT`, `PRODUCTDESCRIPTION`,
`LANGUAGE`) are the commonly documented ones for these views but could
not be verified against a live system from this environment (see
`docs/assumptions.md` #3 - confirm in SE11/ADT before activation). And
the display layer now uses the classic `REUSE_ALV_GRID_DISPLAY`
function module instead of `CL_SALV_TABLE`, with a hand-built field
catalog (`GT_OUTPUT`/`GT_SUMMARY` are local `TYPES`, not DDIC
structures, so `REUSE_ALV_FIELDCATALOG_MERGE` can't reliably derive
one) - this needs `TYPE-POOLS: SLIS`, the one genuinely older-style
statement in an otherwise obsolete-statement-free program.
Full detail is in the report's header comment and in `docs/assumptions.md`.

## Contents

- `zsrc/ZPP_OEE_ADHESIVE_REPORT.abap` – main report program (S/4HANA 2022 syntax)
- `docs/field_mapping.md` – field-by-field source-to-target mapping
- `docs/assumptions.md` – open items to confirm before transport

## Still worth doing before deploying

Same open item as the classic version:

1. **Add a Plant `AUTHORITY-CHECK`.** None is implemented right now —
   confirm the correct object with your security team (check for an
   existing custom Z auth object first, or trace a comparable transaction
   like `CO11N`/`COOIS` with `STAUTHTRACE`/SU24) and add it in
   `AT SELECTION-SCREEN`.
2. Add text elements (001, 002) via SE38 → Goto → Text Elements.
3. This has not been syntax-checked against a live S/4HANA 2022 system —
   run it through ATC (ABAP Test Cockpit) and SE38 syntax check before
   transport; table field lists (e.g. which AFRU/CAUFV fields exist in your
   specific release) should be verified against your system's DDIC.

## Note on architecture

This stays a classic ABAP report with `cl_salv_table` for output, matching
the original FS's "Report" object type. If your team is standardizing on
CDS views + Fiori Elements / Analytics for new S/4HANA reporting, the
`docs/field_mapping.md` table still gives you the source-field lineage
needed to build this as a CDS-based analytical query instead.
